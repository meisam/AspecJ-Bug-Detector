/* abc - The AspectBench Compiler
 * Copyright (C) 2008 Eric Bodden
 *
 * This compiler is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This compiler is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this compiler, in the file LESSER-GPL;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */
package abc.da.ast;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import polyglot.ast.Formal;
import polyglot.ast.Node;
import polyglot.ast.Term;
import polyglot.ast.TypeNode;
import polyglot.ext.jl.ast.Term_c;
import polyglot.types.SemanticException;
import polyglot.types.Type;
import polyglot.types.TypeSystem;
import polyglot.util.CodeWriter;
import polyglot.util.ErrorInfo;
import polyglot.util.Position;
import polyglot.visit.CFGBuilder;
import polyglot.visit.ContextVisitor;
import polyglot.visit.NodeVisitor;
import polyglot.visit.PrettyPrinter;
import polyglot.visit.TypeChecker;
import abc.aspectj.ast.AdviceDecl;
import abc.aspectj.types.AJContext;
import abc.aspectj.visit.ContainsAspectInfo;
import abc.da.HasDAInfo;
import abc.da.types.DAAspectType;
import abc.da.types.DAContext;
import abc.da.weaving.aspectinfo.DAInfo;
import abc.da.weaving.weaver.depadviceopt.ds.Bag;
import abc.da.weaving.weaver.depadviceopt.ds.HashBag;
import abc.main.Main;
import abc.weaving.aspectinfo.Aspect;
import abc.weaving.aspectinfo.GlobalAspectInfo;

/**
 * AST node for an advice depencency declaration.
 * 
 * @author Eric Bodden
 */
public class AdviceDependency_c extends Term_c implements AdviceDependency,
		ContainsAspectInfo {

	/** List of strong advice names (and their parameters). */
	protected List<AdviceNameAndParams> strongAdvice;
	/** List of weak advice names (and their parameters). */
	protected List<AdviceNameAndParams> weakAdvice;

	public AdviceDependency_c(final Position pos,
			final List<AdviceNameAndParams> strongAdvice,
			final List<AdviceNameAndParams> weakAdvice) {
		super(pos);
		this.strongAdvice = strongAdvice;
		this.weakAdvice = weakAdvice;
	}

	/**
	 * Performs the following type checks:
	 * <ul>
	 * <li> Every advice name that is mentioned must refer to an existing
	 * {@link AdviceDecl} with that name.
	 * <li> Every advice name must only occur once in this dependency
	 * declaration.
	 * <li> There must be at least one strong advice.
	 * </ul>
	 */
	@Override
	public Node typeCheck(final TypeChecker tc) throws SemanticException {
		final AJContext context = (AJContext) tc.context();
		final DAAspectType currentAspectType = (DAAspectType) context
				.currentAspect();
		final Set<AdviceName> aspectAdviceNames = currentAspectType
				.getAdviceNameToFormals().keySet();
		final List<AdviceNameAndParams> allAdviceNames = new LinkedList<AdviceNameAndParams>(
				strongAdvice);
		allAdviceNames.addAll(weakAdvice);
		// first give an error if we refer to an advice name that does not exist
		for (final AdviceNameAndParams adviceName : allAdviceNames) {
			final String name = adviceName.getName();
			boolean found = false;
			for (final AdviceName aspectAdviceName : aspectAdviceNames) {
				if (name.equals(aspectAdviceName.getName())) {
					found = true;
					break;
				}
			}
			if (!found) {
				throw new SemanticException("Dependent advice does not exist: "
						+ name, adviceName.position());
			}
		}

		// check that no advice name occurs twice
		final Set<String> occured = new HashSet<String>();
		for (final AdviceNameAndParams adviceName : allAdviceNames) {
			if (occured.contains(adviceName.getName())) {
				throw new SemanticException(
						"Advice name '"
								+ adviceName.getName()
								+ "' occurs multiple times in dependent advice declaration.",
						position());
			}
			occured.add(adviceName.getName());
		}

		// check for the presence of a strong advice
		if (strongAdvice.isEmpty()) {
			throw new SemanticException(
					"No strong advice present. Need to have at least one strong advice in an advice dependency.",
					position());
		}

		return super.typeCheck(tc);
	}

	/**
	 * {@inheritDoc}
	 */
	public Node typeCheckAdviceParams(final ContextVisitor visitor)
			throws SemanticException {
		// get declared advice names and their formals from the context
		final DAContext context = (DAContext) visitor.context();
		final DAAspectType currentAspect = (DAAspectType) context
				.currentAspect();
		final Map<AdviceName, List<Formal>> adviceNameToFormals = currentAspect
				.getAdviceNameToFormals();

		// get all advice references in this dependency declaration
		final List<AdviceNameAndParams> allAdviceNames = new LinkedList<AdviceNameAndParams>(
				strongAdvice);
		allAdviceNames.addAll(weakAdvice);

		final Map<String, Set<Type>> paramNameToPossibleTypes = new HashMap<String, Set<Type>>();
		for (final AdviceNameAndParams adviceNameAndParams : allAdviceNames) {
			final String referencedAdviceName = adviceNameAndParams.getName();
			for (final AdviceName declaredAdviceName : adviceNameToFormals
					.keySet()) {
				if (declaredAdviceName.getName().equals(referencedAdviceName)) {
					final List<Formal> formalsForThisAdviceName = adviceNameAndParams
							.findFormalsForAdviceName(adviceNameToFormals);
					// for all parameters declared in this dependency decl
					final List<String> params = adviceNameAndParams.getParams();
					if (formalsForThisAdviceName.size() != params.size()) {
						final String add = formalsForThisAdviceName.size() > params
								.size() ? " Did you maybe forget about a returning/throwing formal?"
								: "";
						throw new SemanticException("Advice with name '"
								+ referencedAdviceName + "' has "
								+ formalsForThisAdviceName.size()
								+ " formal parameter(s), but the dependency "
								+ "declaration states " + params.size()
								+ " parameter(s)." + add, adviceNameAndParams
								.position());
					}
					for (int paramIndex = 0; paramIndex < params.size(); paramIndex++) {
						final String paramName = params.get(paramIndex);
						final TypeNode paramType = formalsForThisAdviceName
								.get(paramIndex).type();
						Set<Type> possibleTypes = paramNameToPossibleTypes
								.get(paramName);
						if (possibleTypes == null) {
							possibleTypes = new HashSet<Type>();
							paramNameToPossibleTypes.put(paramName,
									possibleTypes);
						}
						possibleTypes.add(paramType.type());
					}
				}
			}
		}

		final TypeSystem ts = visitor.typeSystem();
		for (final Iterator<Map.Entry<String, Set<Type>>> entryIter = paramNameToPossibleTypes
				.entrySet().iterator(); entryIter.hasNext();) {
			final Map.Entry<String, Set<Type>> entry = entryIter.next();
			final Set<Type> types = entry.getValue();
			final String var = entry.getKey();
			for (final Type type1 : types) {
				for (final Type type2 : types) {
					if (!ts.isCastValid(type1, type2)
							|| !ts.isCastValid(type2, type1)) {
						throw new SemanticException(
								"Incompatible types for variable '" + var
										+ "': " + type1 + ", " + type2 + ".",
								position());
					}
				}
			}
		}

		final Bag<String> variableCount = new HashBag<String>();
		for (final AdviceNameAndParams adviceNameAndParams : allAdviceNames) {
			variableCount.addAll(adviceNameAndParams.getParams());
		}

		for (final AdviceNameAndParams adviceNameAndParams : allAdviceNames) {
			if (!adviceNameAndParams.hasInferredParams()) {
				for (final String var : adviceNameAndParams.getParams()) {
					if (!var.startsWith(AdviceDependency.WILDCARD)) {
						if (variableCount.countOf(var) == 1) {
							Main
									.v()
									.getAbcExtension()
									.reportError(
											ErrorInfo.WARNING,
											"Variable '"
													+ var
													+ "' only occurs once in this dependency. "
													+ "Hence, it will not actually induce any dependency. Consider using the wildcard '*' instead.",
											adviceNameAndParams.position());
						}
						final Set<Type> possibleTypes = paramNameToPossibleTypes
								.get(var);
						for (final Type type : possibleTypes) {
							if (type.isPrimitive()) {
								Main
										.v()
										.getAbcExtension()
										.reportError(
												ErrorInfo.WARNING,
												"Variable '"
														+ var
														+ "' is of primitive type. The dependency analysis will "
														+ "not take variables of primitive types into account.",
												adviceNameAndParams.position());
							}
							// it's enough to look at one parameter because the
							// other ones have to be primitive, too (we already
							// did a type check above)
							break;
						}
					}
				}
			}
		}

		return this;
	}

	/**
	 * {@inheritDoc}
	 */
	public void update(final GlobalAspectInfo gai, final Aspect current_aspect) {
		final DAInfo dai = ((HasDAInfo) Main.v().getAbcExtension())
				.getDependentAdviceInfo();

		final Map<String, List<String>> strongAdviceNameToVars = new HashMap<String, List<String>>();
		for (final AdviceNameAndParams anap : strongAdvice) {
			strongAdviceNameToVars.put(anap.getName(), anap.getParams());
		}

		final Map<String, List<String>> weakAdviceNameToVars = new HashMap<String, List<String>>();
		for (final AdviceNameAndParams anap : weakAdvice) {
			weakAdviceNameToVars.put(anap.getName(), anap.getParams());
		}

		final abc.da.weaving.aspectinfo.AdviceDependency ad = new abc.da.weaving.aspectinfo.AdviceDependency(
				strongAdviceNameToVars, weakAdviceNameToVars, current_aspect,
				position());

		dai.addAdviceDependency(ad);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void prettyPrint(final CodeWriter w, final PrettyPrinter pp) {
		w.begin(0);

		w.write("dependency {");
		w.allowBreak(4);

		w.begin(0);

		if (!strongAdvice.isEmpty()) {
			w.write("strong ");

			for (final Iterator<AdviceNameAndParams> i = strongAdvice
					.iterator(); i.hasNext();) {
				final AdviceNameAndParams anap = i.next();
				print(anap, w, pp);

				if (i.hasNext()) {
					w.write(",");
					w.allowBreak(0);
				}
			}
			w.write(";");
			w.allowBreak(0);
		}

		if (!weakAdvice.isEmpty()) {
			w.write("weak ");

			for (final Iterator<AdviceNameAndParams> i = weakAdvice.iterator(); i
					.hasNext();) {
				final AdviceNameAndParams anap = i.next();
				print(anap, w, pp);

				if (i.hasNext()) {
					w.write(",");
					w.allowBreak(0);
				}
			}
			w.write(";");
			w.allowBreak(0);
		}

		w.end();

		w.write("}");

		w.end();
	}

	public AdviceDependency_c reconstruct(
			final List<AdviceNameAndParams> strongAdvice,
			final List<AdviceNameAndParams> weakAdvice) {
		if (!strongAdvice.equals(this.strongAdvice)
				|| !weakAdvice.equals(this.weakAdvice)) {
			final AdviceDependency_c n = (AdviceDependency_c) copy();
			n.strongAdvice = strongAdvice;
			n.weakAdvice = weakAdvice;
			return n;
		}
		return this;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	@SuppressWarnings("unchecked")
	public Node visitChildren(final NodeVisitor v) {
		final List<AdviceNameAndParams> strongAdvice = visitList(
				this.strongAdvice, v);
		final List<AdviceNameAndParams> weakAdvice = visitList(this.weakAdvice,
				v);
		return reconstruct(strongAdvice, weakAdvice);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List acceptCFG(final CFGBuilder v, final List succs) {
		return succs;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Term entry() {
		return this;
	}

}
