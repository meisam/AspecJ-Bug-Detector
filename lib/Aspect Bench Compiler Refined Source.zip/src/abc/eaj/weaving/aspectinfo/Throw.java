/* abc - The AspectBench Compiler
 * Copyright (C) 2004 Julian Tibble
 *
 * This compiler is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This compiler is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this compiler, in the file LESSER-GPL;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

package abc.eaj.weaving.aspectinfo;

import polyglot.util.Position;
import soot.Type;
import abc.eaj.weaving.matching.ThrowShadowMatch;
import abc.weaving.aspectinfo.LocalPointcutVars;
import abc.weaving.aspectinfo.Pointcut;
import abc.weaving.aspectinfo.ShadowPointcut;
import abc.weaving.aspectinfo.TypePattern;
import abc.weaving.aspectinfo.Unification;
import abc.weaving.matching.ShadowMatch;
import abc.weaving.residues.AlwaysMatch;
import abc.weaving.residues.NeverMatch;
import abc.weaving.residues.Residue;

/**
 * Handler for <code>throw</code> shadow pointcut.
 * 
 * @author Julian Tibble
 */
public class Throw extends ShadowPointcut {
	private final TypePattern pattern;

	public Throw(final TypePattern pattern, final Position pos) {
		super(pos);
		this.pattern = pattern;
	}

	public TypePattern getPattern() {
		return pattern;
	}

	@Override
	protected Residue matchesAt(final ShadowMatch sm) {
		if (!(sm instanceof ThrowShadowMatch)) {
			return NeverMatch.v();
		}
		final Type throw_type = ((ThrowShadowMatch) sm).getThrowType();

		if (!getPattern().matchesType(throw_type)) {
			return NeverMatch.v();
		}
		return AlwaysMatch.v();
	}

	@Override
	public String toString() {
		return "throw(" + pattern + ")";
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see abc.weaving.aspectinfo.Pointcut#unify(abc.weaving.aspectinfo.Pointcut,
	 *      java.util.Hashtable, java.util.Hashtable,
	 *      abc.weaving.aspectinfo.Pointcut)
	 */
	@Override
	public boolean unify(final Pointcut otherpc, final Unification unification) {
		if (otherpc.getClass() == this.getClass()) {
			if (pattern.equivalent(((Throw) otherpc).getPattern())) {
				unification.setPointcut(this);
				return true;
			} else {
				return false;
			}
		} else {
			return LocalPointcutVars.unifyLocals(this, otherpc, unification);
		}
	}
}
