/* abc - The AspectBench Compiler
 * Copyright (C) 2005 Julian Tibble
 *
 * This compiler is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This compiler is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this compiler, in the file LESSER-GPL;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

package abc.eaj.weaving.aspectinfo;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import polyglot.util.Position;
import abc.eaj.weaving.residues.LetResidue;
import abc.weaving.aspectinfo.Aspect;
import abc.weaving.aspectinfo.If;
import abc.weaving.aspectinfo.MethodSig;
import abc.weaving.aspectinfo.Pointcut;
import abc.weaving.aspectinfo.Unification;
import abc.weaving.aspectinfo.Var;
import abc.weaving.matching.MatchingContext;
import abc.weaving.residues.AndResidue;
import abc.weaving.residues.Residue;
import abc.weaving.residues.WeavingVar;

/**
 * Handler for <code>let</code> condition pointcut.
 * 
 * @author Julian Tibble
 */
public class Let extends If {
	private final Var bound_var;

	public Let(final Var bound_var, final List vars, final MethodSig impl,
			final int jp, final int jpsp, final int ejp, final Position pos) {
		super(vars, impl, jp, jpsp, ejp, pos);
		this.bound_var = bound_var;
	}

	public Var getBoundVar() {
		return bound_var;
	}

	@Override
	public String toString() {
		return "let(...)";
	}

	@Override
	public void getFreeVars(final Set/* <String> */result) {
		result.add(bound_var.getName());
	}

	@Override
	public Pointcut inline(final Hashtable renameEnv, final Hashtable typeEnv,
			final Aspect context, final int cflowdepth) {
		final Var new_bound_var = bound_var.rename(renameEnv);
		final Iterator i = getVars().iterator();
		final List new_vars = new LinkedList();

		while (i.hasNext()) {
			new_vars.add(((Var) i.next()).rename(renameEnv));
		}

		return new Let(new_bound_var, new_vars, getImpl(), joinPointPos(),
				joinPointStaticPartPos(), enclosingJoinPointPos(),
				getPosition());
	}

	@Override
	public Residue matchesAt(final MatchingContext mc) {
		final WeavingVar bound_wvar = mc.getWeavingEnv().getWeavingVar(
				bound_var);
		final List/* <WeavingVar> */args = new LinkedList();

		final Residue getvars = getWeavingVars(getVars(), args, mc);
		final Residue let = LetResidue.construct(bound_wvar, getImpl()
				.getSootMethod(), args);

		return AndResidue.construct(getvars, let);
	}

	@Override
	public boolean unify(final Pointcut otherpc, final Unification unification) {
		return false;
	}
}
