/* abc - The AspectBench Compiler
 * Copyright (C) 2005 Ondrej Lhotak
 *
 * This compiler is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This compiler is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this compiler, in the file LESSER-GPL;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

package abc.eaj.weaving.aspectinfo;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import polyglot.util.Position;
import abc.eaj.weaving.residues.CflowDepthResidue;
import abc.weaving.aspectinfo.Aspect;
import abc.weaving.aspectinfo.Cflow;
import abc.weaving.aspectinfo.LocalPointcutVars;
import abc.weaving.aspectinfo.Pointcut;
import abc.weaving.aspectinfo.Unification;
import abc.weaving.aspectinfo.Var;
import abc.weaving.aspectinfo.VarBox;
import abc.weaving.matching.MatchingContext;
import abc.weaving.matching.WeavingEnv;
import abc.weaving.residues.Residue;
import abc.weaving.residues.WeavingVar;

/**
 * Handler for <code>cflowdepth</code> pointcut.
 * 
 * @author Ondrej Lhotak
 */
public class CflowDepth extends abc.weaving.aspectinfo.Cflow {
	private final Var depth_var;

	private CflowDepth(final Pointcut pc, final Position pos, final int depth,
			final Var depth_var) {
		super(pc, pos, depth);
		this.depth_var = depth_var;
	}

	public CflowDepth(final Pointcut pc, final Position pos, final Var depth_var) {
		super(pc, pos);
		this.depth_var = depth_var;
	}

	@Override
	public String toString() {
		return "cflowdepth(" + depth_var + ", " + getPointcut() + ")";
	}

	@Override
	public void getFreeVars(final Set result) {
		super.getFreeVars(result);
		result.add(depth_var.getName());
	}

	@Override
	public Residue matchesAt(final MatchingContext mc) {
		final WeavingEnv env = mc.getWeavingEnv();
		// final SootClass cls =
		mc.getSootClass();
		// final SootMethod method =
		mc.getSootMethod();
		// final ShadowMatch sm =
		mc.getShadowMatch();

		final List/* <Var> */actuals = getCfs().getActuals();
		// List of actuals for the Cflow setup advice
		// These are NOT necessarily the same as the actuals for
		// this (inlined) pointcut, but we have the renaming
		final List/* <WeavingVar> */weavingActuals = new LinkedList();
		final Iterator it = actuals.iterator();
		while (it.hasNext()) {
			final Var setupvar = (Var) it.next();
			final VarBox inlinedvar = (VarBox) getRenaming().get(setupvar);
			if (inlinedvar == null) {
				throw new RuntimeException(
						"Internal error: Could not find variable "
								+ setupvar.getName()
								+ " in cflow renaming from cflow:\n"
								+ getPointcut());
			}
			if (inlinedvar.hasVar()) {
				weavingActuals.add(env.getWeavingVar(inlinedvar.getVar()));
			} else {
				weavingActuals.add(null);
			}
		}
		final WeavingVar wv = env.getWeavingVar(depth_var);
		return new CflowDepthResidue(getCfs(), weavingActuals, wv);
	}

	@Override
	public Pointcut inline(final Hashtable renameEnv, final Hashtable typeEnv,
			final Aspect context, final int cflowdepth) {
		final Var depth_var = this.depth_var.rename(renameEnv);
		final Pointcut pc = this.getPointcut().inline(renameEnv, typeEnv,
				context, cflowdepth + 1);
		CflowDepth ret;
		if (pc == this.getPointcut()) {
			ret = this;
		} else {
			ret = new CflowDepth(pc, getPosition(), depth, depth_var);
		}
		if (depth == -1) {
			ret.depth = cflowdepth;
		}
		return ret;
	}

	@Override
	public DNF dnf() {
		final Cflow ret = new CflowDepth(getPointcut().dnf().makePointcut(
				getPointcut().getPosition()), getPosition(), depth, depth_var);
		return new DNF(ret);
	}

	@Override
	public boolean unify(final Pointcut otherpc, final Unification unification) {

		if (otherpc.getClass() == this.getClass()) {
			if (getPointcut().unify(((Cflow) otherpc).getPointcut(),
					unification)) {
				if (unification.getPointcut() == getPointcut()) {
					unification.setPointcut(this);
				} else {
					if (unification.unifyWithFirst()) {
						throw new RuntimeException(
								"Unfication error: restricted unification failed");
					}
					if (unification.getPointcut() == ((Cflow) otherpc)
							.getPointcut()) {
						unification.setPointcut(otherpc);
					} else {
						unification.setPointcut(new CflowDepth(getPointcut(),
								getPosition(), depth, depth_var));
					}
				}
				return true;
			} else {
				return false;
			}
		} else {
			return LocalPointcutVars.unifyLocals(this, otherpc, unification);
		}

	}

}
