/* abc - The AspectBench Compiler
 * Copyright (C) 2004 Ganesh Sittampalam
 * Copyright (C) 2004 Ondrej Lhotak
 * Copyright (C) 2004 Damien Sereni
 *
 * This compiler is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This compiler is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this compiler, in the file LESSER-GPL;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

package abc.eaj.weaving.residues;

import java.util.ArrayList;
import java.util.List;

import soot.IntType;
import soot.Local;
import soot.SootMethod;
import soot.jimple.Stmt;
import soot.util.Chain;
import abc.soot.util.LocalGeneratorEx;
import abc.weaving.aspectinfo.CflowSetup;
import abc.weaving.residues.CflowResidue;
import abc.weaving.residues.Residue;
import abc.weaving.residues.WeavingVar;
import abc.weaving.weaver.CflowCodeGenUtils;
import abc.weaving.weaver.ConstructorInliningMap;
import abc.weaving.weaver.WeavingContext;

/**
 * A dynamic residue for cflow and cflow below
 * 
 * @author Ganesh Sittampalam
 * @author Ondrej Lhotak
 * @author Damien Sereni
 */
public class CflowDepthResidue extends CflowResidue {
	protected WeavingVar depth;

	@Override
	public Residue inline(final ConstructorInliningMap cim) {
		return new CflowDepthResidue(setup, WeavingVar.inline(vars, cim), depth
				.inline(cim));
	}

	@Override
	public Residue optimize() {
		final ArrayList newVars = new ArrayList();
		newVars.addAll(vars);
		return new CflowDepthResidue(setup, newVars, depth);
	}

	public CflowDepthResidue(final CflowSetup setup, final List vars,
			final WeavingVar depth) {
		super(setup, vars);
		this.depth = depth;
	}

	@Override
	public Residue resetForReweaving() {
		super.resetForReweaving();
		depth.resetForReweaving();
		return this;
	}

	public static void debug(final String message) {
		if (abc.main.Debug.v().residueCodeGen) {
			System.err.println("RCG: " + message);
		}
	}

	@Override
	public Stmt codeGen(final SootMethod method,
			final LocalGeneratorEx localgen, final Chain units,
			final Stmt begin, final Stmt fail, boolean sense,
			final WeavingContext wc) {

		if (!sense) {
			return reverseSense(method, localgen, units, begin, fail, sense, wc);
		}
		Stmt last = super.codeGen(method, localgen, units, begin, fail, sense,
				wc);
		final CflowCodeGenUtils.CflowCodeGen codegen = setup.codeGen();
		final Local depthLocal = localgen.generateLocal(IntType.v(), "depth");
		final Local cflowLocal = (abc.main.options.OptionsParser.v()
				.cflow_share_thread_locals() ? setup.getMethodCflowThreadLocal(
				localgen, method) : localgen.generateLocal(setup.codeGen()
				.getCflowInstanceType(), "cflowThreadLocal"));

		final Chain isValidCheck = codegen.genDepth(localgen, cflowLocal,
				depthLocal);
		last = (Stmt) insertChainAfter(units, isValidCheck, last);
		last = depth.set(localgen, units, last, wc, depthLocal);

		return last;
	}

	@Override
	public String toString() {
		return "cflowdepth(" + setup.getPointcut() + ")";
	}

}
