/* abc - The AspectBench Compiler
 * Copyright (C) 2005 Julian Tibble
 *
 * This compiler is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This compiler is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this compiler, in the file LESSER-GPL;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

package abc.eaj.weaving.residues;

import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import soot.SootMethod;
import soot.jimple.InvokeExpr;
import soot.jimple.Jimple;
import soot.jimple.Stmt;
import soot.util.Chain;
import abc.soot.util.LocalGeneratorEx;
import abc.weaving.residues.Residue;
import abc.weaving.residues.WeavingVar;
import abc.weaving.weaver.ConstructorInliningMap;
import abc.weaving.weaver.WeavingContext;

/**
 * The dynamic residue of a let(...) pointcut
 * 
 * @author Julian Tibble
 */
public class LetResidue extends Residue {
	private final WeavingVar bound_var;
	private final SootMethod impl;
	private final List/* <WeavingVar> */args;

	private LetResidue(final WeavingVar bound_var, final SootMethod impl,
			final List args) {
		this.bound_var = bound_var;
		this.impl = impl;
		this.args = args;
	}

	@Override
	public Residue optimize() {
		return this;
	}

	@Override
	public Residue inline(final ConstructorInliningMap cim) {
		final WeavingVar inlined_bound_var = bound_var.inline(cim);
		final List inlined_args = WeavingVar.inline(args, cim);

		return LetResidue.construct(inlined_bound_var, impl, inlined_args);
	}

	@Override
	public Residue resetForReweaving() {
		bound_var.resetForReweaving();
		final Iterator i = args.iterator();

		while (i.hasNext()) {
			final WeavingVar arg = (WeavingVar) i.next();
			arg.resetForReweaving();
		}

		return this;
	}

	public static LetResidue construct(final WeavingVar bound_var,
			final SootMethod impl, final List args) {
		// FIXME: not sure this does is correct for
		// bound_var --- I've ignored boxing
		// stuff because I don't know what it
		// should do.

		return new LetResidue(bound_var, impl, args);
	}

	@Override
	public String toString() {
		return "bind(" + bound_var + ",...)";
	}

	@Override
	public Stmt codeGen(final SootMethod method,
			final LocalGeneratorEx localgen, final Chain units,
			final Stmt begin, final Stmt fail, final boolean sense,
			final WeavingContext wc) {
		final List actuals = new Vector(args.size());
		final Iterator i = args.iterator();

		// FIXME, I probably need it
		while (i.hasNext()) {
			final WeavingVar wv = (WeavingVar) i.next();
			actuals.add(wv.get());
		}

		final InvokeExpr letcall = Jimple.v().newStaticInvokeExpr(
				impl.makeRef(), actuals);

		return bound_var.set(localgen, units, begin, wc, letcall);
	}
}
