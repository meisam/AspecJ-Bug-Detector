/* abc - The AspectBench Compiler
 * Copyright (C) 2004 Julian Tibble
 *
 * This compiler is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This compiler is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this compiler, in the file LESSER-GPL;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

package abc.eaj.extension;

import java.util.List;

import polyglot.ast.Block;
import polyglot.types.Flags;
import polyglot.util.Position;
import abc.aspectj.ast.AdviceDecl_c;
import abc.aspectj.ast.AdviceSpec;
import abc.aspectj.ast.Pointcut;
import abc.eaj.visit.GlobalPointcuts;

/**
 * @author Julian Tibble
 */
public class EAJAdviceDecl_c extends AdviceDecl_c implements EAJAdviceDecl {
	public EAJAdviceDecl_c(final Position pos, final Flags flags,
			final AdviceSpec spec, final List throwTypes, final Pointcut pc,
			final Block body) {
		super(pos, flags, spec, throwTypes, pc, body);
	}

	public EAJAdviceDecl conjoinPointcutWith(final GlobalPointcuts visitor,
			final Pointcut global) {
		final EAJAdviceDecl_c n = (EAJAdviceDecl_c) this.copy();
		n.pc = visitor.conjoinPointcuts(pc, global);
		return n;
	}
}
