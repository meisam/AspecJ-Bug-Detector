/* abc - The AspectBench Compiler
 * Copyright (C) 2004 Julian Tibble
 *
 * This compiler is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This compiler is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this compiler, in the file LESSER-GPL;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

package abc.eaj.ast;

import java.util.HashSet;
import java.util.Set;

import polyglot.ast.Node;
import polyglot.ast.Precedence;
import polyglot.util.CodeWriter;
import polyglot.util.Position;
import polyglot.visit.NodeVisitor;
import polyglot.visit.PrettyPrinter;
import abc.aspectj.ast.Pointcut_c;
import abc.aspectj.ast.TypePatternExpr;

/**
 * @author Julian Tibble
 */
public class PCCast_c extends Pointcut_c implements PCCast {
	protected TypePatternExpr type_pattern;

	public PCCast_c(final Position pos, final TypePatternExpr type_pattern) {
		super(pos);
		this.type_pattern = type_pattern;
	}

	public Set pcRefs() {
		return new HashSet();
	}

	@Override
	public Precedence precedence() {
		return Precedence.LITERAL;
	}

	@Override
	public void prettyPrint(final CodeWriter w, final PrettyPrinter pp) {
		w.write("cast(");
		print(type_pattern, w, pp);
		w.write(")");
	}

	protected PCCast_c reconstruct(final TypePatternExpr type_pattern) {
		if (type_pattern != this.type_pattern) {
			final PCCast_c n = (PCCast_c) copy();
			n.type_pattern = type_pattern;
			return n;
		}
		return this;
	}

	@Override
	public Node visitChildren(final NodeVisitor v) {
		final TypePatternExpr type_pattern = (TypePatternExpr) visitChild(
				this.type_pattern, v);
		return reconstruct(type_pattern);
	}

	public boolean isDynamic() {
		return false;
	}

	public abc.weaving.aspectinfo.Pointcut makeAIPointcut() {
		return new abc.eaj.weaving.aspectinfo.Cast(type_pattern
				.makeAITypePattern(), position());
	}
}
