/* abc - The AspectBench Compiler
 * Copyright (C) 2005 Julian Tibble
 *
 * This compiler is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This compiler is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this compiler, in the file LESSER-GPL;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

package abc.eaj.ast;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import polyglot.ast.Block;
import polyglot.ast.Expr;
import polyglot.ast.Formal;
import polyglot.ast.Local;
import polyglot.ast.MethodDecl;
import polyglot.ast.Node;
import polyglot.ast.Return;
import polyglot.ast.TypeNode;
import polyglot.types.Flags;
import polyglot.types.MethodInstance;
import polyglot.types.ParsedClassType;
import polyglot.types.SemanticException;
import polyglot.types.Type;
import polyglot.types.TypeSystem;
import polyglot.util.CodeWriter;
import polyglot.util.Position;
import polyglot.util.UniqueID;
import polyglot.visit.AscriptionVisitor;
import polyglot.visit.NodeVisitor;
import polyglot.visit.PrettyPrinter;
import polyglot.visit.TypeChecker;
import abc.aspectj.ast.AJNodeFactory;
import abc.aspectj.ast.PCIf_c;
import abc.aspectj.types.AJTypeSystem;
import abc.aspectj.visit.AspectMethods;
import abc.weaving.aspectinfo.AbcFactory;
import abc.weaving.aspectinfo.MethodCategory;

/**
 * @author Julian Tibble
 */
public class PCLet_c extends PCIf_c implements PCLet {
	protected Local var;

	public PCLet_c(final Position pos, final Local var, final Expr expr) {
		super(pos, expr);
		this.var = var;
	}

	/**
	 * visit the children of the let
	 */
	@Override
	public Node visitChildren(final NodeVisitor v) {
		final Local var = (Local) visitChild(this.var, v);
		PCLet_c pcl = (PCLet_c) super.visitChildren(v);

		if (this.var != var) {
			pcl = (PCLet_c) pcl.copy();
			pcl.var = var;
		}

		return pcl;
	}

	@Override
	public void prettyPrint(final CodeWriter w, final PrettyPrinter tr) {
		w.write("let(");
		print(var, w, tr);
		w.write(", ");
		print(expr, w, tr);
		w.write(")");
	}

	@Override
	public Collection mayBind() throws SemanticException {
		return mustBind();
	}

	@Override
	public Collection mustBind() {
		final Collection mustbind = new HashSet();
		mustbind.add(var.name());
		return mustbind;
	}

	@Override
	public Node typeCheck(final TypeChecker tc) throws SemanticException {
		final Type var_type = var.type();
		final Type expr_type = expr.type();

		final TypeSystem ts = tc.typeSystem();

		if (!ts.isImplicitCastValid(expr_type, var_type)
				&& !ts.equals(expr_type, var_type)
				&& !ts.numericConversionValid(var_type, expr.constantValue())) {
			throw new SemanticException("Cannot bind " + expr_type + " to "
					+ var_type + ".", position());
		}

		return this;
	}

	@Override
	public Type childExpectedType(final Expr child, final AscriptionVisitor av) {
		final TypeSystem ts = av.typeSystem();

		if (child == expr) {
			return var.type();
		}

		return child.type();
	}

	@Override
	public MethodDecl exprMethod(final AJNodeFactory nf, final AJTypeSystem ts,
			final List formals, final ParsedClassType container) {
		final Return ret = nf.Return(position(), expr);
		final Block bl = nf.Block(position()).append(ret);
		final TypeNode retType = nf.CanonicalTypeNode(position(), var.type());

		final List args = new LinkedList();
		final List formaltypes = new ArrayList();

		// put formals into the list of args ignoring references
		// to the pointcut formal bound by this let
		Iterator i = formals.iterator();
		while (i.hasNext()) {
			final Formal f = (Formal) i.next();
			if (!f.name().equals(var.name())) {
				args.add(f);
				formaltypes.add(f.type().type());
			}
		}

		final List throwTypes = new LinkedList();
		i = expr.throwTypes(ts).iterator();
		while (i.hasNext()) {
			final Type t = (Type) i.next();
			final TypeNode tn = nf.CanonicalTypeNode(position(), t);
			throwTypes.add(tn);
		}

		addJoinPointFormals(nf, ts, args, formaltypes);

		methodName = UniqueID.newID("let");
		MethodDecl md = nf.MethodDecl(position(), Flags.STATIC.Public(),
				retType, methodName, args, throwTypes, bl);
		final MethodInstance mi = ts.methodInstance(position, container,
				Flags.STATIC.Public(), retType.type(), methodName,
				new ArrayList(formaltypes), new ArrayList(expr.del()
						.throwTypes(ts)));

		container.addMethod(mi);
		md = md.methodInstance(mi);
		methodDecl = md;
		return md;
	}

	@Override
	protected List calculateMethodParameters(final AspectMethods visitor,
			final AJNodeFactory nf, final AJTypeSystem ts) {
		final List formals = new ArrayList();
		final Iterator i = super.calculateMethodParameters(visitor, nf, ts)
				.iterator();

		while (i.hasNext()) {
			final Formal f = (Formal) i.next();
			if (!f.name().equals(var.name())) {
				formals.add(f);
			}
		}

		return formals;
	}

	@Override
	public abc.weaving.aspectinfo.Pointcut makeAIPointcut() {
		int lastpos = methodDecl.formals().size();
		int jp = -1, jpsp = -1, ejp = -1;
		if (hasEnclosingJoinPointStaticPart) {
			ejp = --lastpos;
		}
		if (hasJoinPoint) {
			jp = --lastpos;
		}
		if (hasJoinPointStaticPart) {
			jpsp = --lastpos;
		}

		MethodCategory.register(methodDecl, MethodCategory.IF_EXPR);

		final List vars = new ArrayList();
		final Iterator fi = methodDecl.formals().iterator();
		while (fi.hasNext()) {
			final Formal f = (Formal) fi.next();
			vars.add(new abc.weaving.aspectinfo.Var(f.name(), f.position()));
		}

		return new abc.eaj.weaving.aspectinfo.Let(
				new abc.weaving.aspectinfo.Var(var.name(), var.position()),
				vars, AbcFactory.MethodSig(methodDecl), jp, jpsp, ejp, position);
	}
}
