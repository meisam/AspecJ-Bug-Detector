/* abc - The AspectBench Compiler
 * Copyright (C) 2005 Ondrej Lhotak
 *
 * This compiler is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This compiler is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this compiler, in the file LESSER-GPL;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

package abc.eaj.ast;

import java.util.Collection;

import polyglot.ast.Local;
import polyglot.ast.Node;
import polyglot.types.Context;
import polyglot.types.SemanticException;
import polyglot.util.CodeWriter;
import polyglot.util.Position;
import polyglot.visit.NodeVisitor;
import polyglot.visit.PrettyPrinter;
import polyglot.visit.TypeChecker;
import abc.aspectj.ast.PCCflow_c;
import abc.aspectj.ast.Pointcut;
import abc.aspectj.types.AJContext;

/**
 * 
 * @author Ondrej Lhotak
 * 
 */
public class PCCflowDepth_c extends PCCflow_c implements PCCflowDepth {
	protected Local var;

	public PCCflowDepth_c(final Position pos, final Pointcut pc, final Local var) {
		super(pos, pc);
		this.var = var;
	}

	protected PCCflowDepth_c reconstruct(final Pointcut pc, final Local var) {
		if (pc != this.pc || var != this.var) {
			final PCCflowDepth_c ret = (PCCflowDepth_c) copy();
			ret.pc = pc;
			ret.var = var;
			return ret;
		}
		return this;
	}

	@Override
	public void prettyPrint(final CodeWriter w, final PrettyPrinter tr) {
		w.write("cflowdepth(" + var);
		w.write(", ");
		print(pc, w, tr);
		w.write(")");
	}

	@Override
	public abc.weaving.aspectinfo.Pointcut makeAIPointcut() {
		return new abc.eaj.weaving.aspectinfo.CflowDepth(pc.makeAIPointcut(),
				position(), new abc.weaving.aspectinfo.Var(var.name(), var
						.position()));
	}

	@Override
	public Collection mayBind() throws SemanticException {
		final Collection ret = super.mayBind();
		ret.add(var.name());
		return ret;
	}

	@Override
	public Collection mustBind() {
		final Collection ret = super.mustBind();
		ret.add(var.name());
		return ret;
	}

	@Override
	public String toString() {
		return "cflowdepth(" + var + ", " + pc + ")";
	}

	@Override
	public Node visitChildren(final NodeVisitor v) {
		final Pointcut pc = (Pointcut) visitChild(this.pc, v);
		final Local var = (Local) visitChild(this.var, v);
		return reconstruct(pc, var);
	}

	@Override
	public Context enterScope(final Context c) {
		final AJContext nc = (AJContext) super.enterScope(c);
		nc.getCflowMustBind().remove(var.name());
		return nc;
	}

	@Override
	public Node typeCheck(final TypeChecker tc) throws SemanticException {
		final Node ret = super.typeCheck(tc);
		if (!tc.typeSystem().Int().isImplicitCastValid(var.type())) {
			throw new SemanticException(
					"Parameter of cflowdepth must be of type int.");
		}
		return ret;
	}
}
