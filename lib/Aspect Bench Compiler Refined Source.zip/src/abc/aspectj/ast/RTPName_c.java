/* abc - The AspectBench Compiler
 * Copyright (C) 2004 Oege de Moor
 * Copyright (C) 2004 Aske Simon Christensen
 *
 * This compiler is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This compiler is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this compiler, in the file LESSER-GPL;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

package abc.aspectj.ast;

import polyglot.ast.Node;
import polyglot.ext.jl.ast.Node_c;
import polyglot.types.SemanticException;
import polyglot.util.CodeWriter;
import polyglot.util.Position;
import polyglot.visit.NodeVisitor;
import polyglot.visit.PrettyPrinter;
import abc.aspectj.visit.ContainsNamePattern;
import abc.aspectj.visit.PCNode;
import abc.aspectj.visit.PatternMatcher;

/**
 * 
 * @author Oege de Moor
 * @author Aske Simon Christensen
 */
public class RTPName_c extends Node_c implements RTPName, ContainsNamePattern {
	protected NamePattern pat;

	public RTPName_c(final Position pos, final NamePattern pat) {
		super(pos);
		this.pat = pat;
	}

	/** Reconstruct the pointcut call. */
	protected RTPName_c reconstruct(final NamePattern pat) {
		if (this.pat != pat) {
			final RTPName_c n = (RTPName_c) copy();
			n.pat = pat;
			return n;
		}
		return this;
	}

	/** Visit the children of the pointcut call. */
	@Override
	public Node visitChildren(final NodeVisitor v) {
		final NamePattern pat = (NamePattern) visitChild(this.pat, v);
		return reconstruct(pat);
	}

	@Override
	public void prettyPrint(final CodeWriter w, final PrettyPrinter tr) {
		print(pat, w, tr);
	}

	@Override
	public String toString() {
		return pat.toString();
	}

	public NamePattern getNamePattern() {
		return pat;
	}

	public boolean matchesClass(final PatternMatcher matcher, final PCNode cl) {
		return matcher.matchesName(pat, cl);
	}

	public boolean matchesArray(final PatternMatcher matcher) {
		return false;
	}

	public ClassnamePatternExpr transformToClassnamePattern(
			final AJNodeFactory nf) throws SemanticException {
		return nf.CPEName(position, pat);
	}

	public boolean equivalent(final RefTypePattern p) {
		if (p.getClass() == this.getClass()) {
			return (pat.equivalent(((RTPName) p).getNamePattern()));
		} else {
			return false;
		}
	}

}
