/* abc - The AspectBench Compiler
 * Copyright (C) 2004 Oege de Moor
 *
 * This compiler is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This compiler is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this compiler, in the file LESSER-GPL;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

package abc.aspectj.ast;

import java.util.Collection;
import java.util.Set;

import polyglot.ast.Node;
import polyglot.ast.Precedence;
import polyglot.types.Context;
import polyglot.types.SemanticException;
import polyglot.util.CodeWriter;
import polyglot.util.Position;
import polyglot.visit.NodeVisitor;
import polyglot.visit.PrettyPrinter;
import polyglot.visit.TypeChecker;
import abc.aspectj.types.AJContext;
import abc.main.Debug;

/**
 * 
 * @author Oege de Moor
 * 
 */
public class PCCflow_c extends Pointcut_c implements PCCflow {
	protected Pointcut pc;

	public PCCflow_c(final Position pos, final Pointcut pc) {
		super(pos);
		this.pc = pc;
	}

	@Override
	public Precedence precedence() {
		return Precedence.LITERAL;
	}

	public Set pcRefs() {
		return pc.pcRefs();
	}

	public boolean isDynamic() {
		return true;
	}

	/** Reconstruct the pointcut. */
	protected PCCflow_c reconstruct(final Pointcut pc) {
		if (pc != this.pc) {
			final PCCflow_c n = (PCCflow_c) copy();
			n.pc = pc;
			return n;
		}

		return this;
	}

	/** Visit the children of the pointcut. */
	@Override
	public Node visitChildren(final NodeVisitor v) {
		final Pointcut pc = (Pointcut) visitChild(this.pc, v);
		return reconstruct(pc);
	}

	@Override
	public Context enterScope(final Context c) {
		final Context nc = super.enterScope(c);
		return ((AJContext) nc).pushCflow(mustBind());
	}

	@Override
	public Node typeCheck(final TypeChecker tc) throws SemanticException {
		final AJContext c = (AJContext) tc.context();
		if (c.inDeclare() && !Debug.v().allowDynamicTests) {
			throw new SemanticException(
					"cflow(..) requires a dynamic test and cannot be used inside a \"declare\" statement",
					position());
		}
		return this;
	}

	@Override
	public void prettyPrint(final CodeWriter w, final PrettyPrinter tr) {
		w.write("cflow(");
		print(pc, w, tr);
		w.write(")");
	}

	@Override
	public Collection mayBind() throws SemanticException {
		return pc.mayBind();
	}

	@Override
	public Collection mustBind() {
		return pc.mustBind();
	}

	public abc.weaving.aspectinfo.Pointcut makeAIPointcut() {
		return new abc.weaving.aspectinfo.Cflow(pc.makeAIPointcut(), position());
	}
}
