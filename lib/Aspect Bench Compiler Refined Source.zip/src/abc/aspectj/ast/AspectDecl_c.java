/* abc - The AspectBench Compiler
 * Copyright (C) 2004 Oege de Moor
 * Copyright (C) 2004 Aske Simon Christensen
 *
 * This compiler is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This compiler is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this compiler, in the file LESSER-GPL;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

package abc.aspectj.ast;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.Stack;

import polyglot.ast.Block;
import polyglot.ast.ClassBody;
import polyglot.ast.Expr;
import polyglot.ast.MethodDecl;
import polyglot.ast.Node;
import polyglot.ast.NodeFactory;
import polyglot.ast.TypeNode;
import polyglot.types.ClassType;
import polyglot.types.Context;
import polyglot.types.Flags;
import polyglot.types.LocalInstance;
import polyglot.types.MethodInstance;
import polyglot.types.SemanticException;
import polyglot.types.TypeSystem;
import polyglot.util.CodeWriter;
import polyglot.util.CollectionUtil;
import polyglot.util.ErrorInfo;
import polyglot.util.Position;
import polyglot.util.TypedList;
import polyglot.visit.AddMemberVisitor;
import polyglot.visit.AmbiguityRemover;
import polyglot.visit.NodeVisitor;
import polyglot.visit.PrettyPrinter;
import polyglot.visit.TypeBuilder;
import polyglot.visit.TypeChecker;
import abc.aspectj.extension.AJClassDecl_c;
import abc.aspectj.types.AJContext;
import abc.aspectj.types.AJFlags;
import abc.aspectj.types.AJTypeSystem;
import abc.aspectj.types.AspectType;
import abc.aspectj.visit.AJTypeBuilder;
import abc.aspectj.visit.AspectMethods;
import abc.aspectj.visit.ContainsAspectInfo;
import abc.weaving.aspectinfo.AbcClass;
import abc.weaving.aspectinfo.AbcFactory;
import abc.weaving.aspectinfo.Aspect;
import abc.weaving.aspectinfo.Formal;
import abc.weaving.aspectinfo.GlobalAspectInfo;
import abc.weaving.aspectinfo.MethodCategory;
import abc.weaving.aspectinfo.MethodSig;
import abc.weaving.aspectinfo.Per;

/**
 * A <code>AspectDecl</code> is the definition of an aspect, abstract aspect,
 * or privileged. It may be a public or other top-level aspect, or an inner
 * named aspect.
 * 
 * @author Oege de Moor
 * @author Aske Simon Christensen
 */

public class AspectDecl_c extends AJClassDecl_c implements AspectDecl,
		ContainsAspectInfo, MakesAspectMethods {

	protected PerClause per;
	protected MethodInstance hasAspectInstance;
	protected MethodInstance aspectOfInstance;

	public AspectDecl_c(final Position pos, final boolean is_privileged,
			final Flags flags, final String name, final TypeNode superClass,
			final List interfaces, final PerClause per, final AspectBody body) {
		super(pos, AJFlags.aspectclass(is_privileged ? AJFlags
				.privilegedaspect(flags) : flags), name, superClass,
				interfaces, body);
		this.per = per;
	}

	/**
	 * construct a dummy aspectOf method that always returns null it potentially
	 * throws org.aspectj.lang.NoAspectBoundException, so that is loaded, if it
	 * is a per-object associated aspect, it takes one parameter of type Object,
	 * otherwise none
	 */

	private MethodDecl aspectOf(final NodeFactory nf, final AJTypeSystem ts) {
		final TypeNode tn = nf.CanonicalTypeNode(position(), type).type(type);
		final Expr nl = nf.NullLit(position()).type(type);
		final Block bl = nf.Block(position()).append(nf.Return(position(), nl));
		final TypeNode nab = nf.CanonicalTypeNode(position(),
				ts.NoAspectBound()).type(ts.NoAspectBound());
		final List thrws = new LinkedList();
		thrws.add(nab);
		final List args = new LinkedList();
		if (((AspectType) type()).perObject()) {
			final TypeNode obj = nf.CanonicalTypeNode(position(), ts.Object())
					.type(ts.Object());
			final LocalInstance li = ts.localInstance(position(), Flags.NONE,
					ts.Object(), "thisparam");
			final polyglot.ast.Formal f = nf.Formal(position(), Flags.NONE,
					obj, "thisparam").localInstance(li);
			args.add(f);
		}
		final MethodDecl md = nf.MethodDecl(position(), Flags.PUBLIC.Static(),
				tn, "aspectOf", args, thrws, bl).methodInstance(
				aspectOfInstance);
		return md;
	}

	/**
	 * construct a dummy hasAspect method that always returns true
	 */
	private MethodDecl hasAspect(final NodeFactory nf, final AJTypeSystem ts) {
		final TypeNode bool = nf.CanonicalTypeNode(position(), ts.Boolean())
				.type(ts.Boolean());
		final Expr b = nf.BooleanLit(position(), true).type(ts.Boolean());
		final Block bl = nf.Block(position()).append(nf.Return(position(), b));

		final List args = new LinkedList();
		if (((AspectType) type()).perObject()) {
			final TypeNode obj = nf.CanonicalTypeNode(position(), ts.Object())
					.type(ts.Object());
			final LocalInstance li = ts.localInstance(position(), Flags.NONE,
					ts.Object(), "thisparam");
			final polyglot.ast.Formal f = nf.Formal(position(), Flags.NONE,
					obj, "thisparam").localInstance(li);
			args.add(f);
		}
		final List thrws = new LinkedList();
		final MethodDecl md = nf.MethodDecl(position(), Flags.PUBLIC.Static(),
				bool, "hasAspect", args, thrws, bl).methodInstance(
				hasAspectInstance);
		return md;
	}

	/**
	 * add the aspectOf and hasAspect methods to the aspect class, but only if
	 * it is concrete
	 */

	public AspectDecl addAspectMembers(final NodeFactory nf,
			final AJTypeSystem ts) {
		if (!flags().isAbstract()) {
			final MethodDecl aspectOf = aspectOf(nf, ts);
			final MethodDecl hasAspect = hasAspect(nf, ts);
			return (AspectDecl) body(body().addMember(aspectOf).addMember(
					hasAspect));
		} else {
			return this;
		}
	}

	@Override
	public NodeVisitor buildTypesEnter(final TypeBuilder tb)
			throws SemanticException {
		AJTypeBuilder ajtb = (AJTypeBuilder) tb;
		ajtb = ajtb.pushAspect(position(), flags, name,
				(per == null ? AspectType.PER_NONE : per.kind()));

		final AspectType ct = (AspectType) ajtb.currentClass();

		// Member classes of interfaces are implicitly public and static.
		if (ct.isMember() && ct.outer().flags().isInterface()) {
			ct.flags(ct.flags().Public().Static());
		}

		// Member interfaces are implicitly static.
		if (ct.isMember() && ct.flags().isInterface()) {
			ct.flags(ct.flags().Static());
		}

		// Interfaces are implicitly abstract.
		if (ct.flags().isInterface()) {
			ct.flags(ct.flags().Abstract());
		}

		return ajtb;
	}

	@Override
	public NodeVisitor addMembersEnter(final AddMemberVisitor am) {
		if (!flags().isAbstract()) {
			final TypeSystem ts = am.typeSystem();
			final List hasAspectparams = new ArrayList();
			final List aspectOfparams = new ArrayList();
			if (((AspectType) type()).perObject()) {
				hasAspectparams.add(ts.Object());
				aspectOfparams.add(ts.Object());
			}
			final List aspectOfthrows = new ArrayList();
			aspectOfthrows.add(((AJTypeSystem) ts).NoAspectBound());
			hasAspectInstance = ts.methodInstance(position(), type,
					Flags.PUBLIC.Static(), ts.Boolean(), "hasAspect",
					hasAspectparams, new ArrayList());
			aspectOfInstance = ts
					.methodInstance(position(), type, Flags.PUBLIC.Static(),
							type, "aspectOf", aspectOfparams, aspectOfthrows);
			type.addMethod(hasAspectInstance);
			type.addMethod(aspectOfInstance);
		}
		return am;
	}

	@Override
	public NodeVisitor disambiguateEnter(final AmbiguityRemover ar)
			throws SemanticException {
		if (ar.kind() == AmbiguityRemover.SUPER) {
			final List noSuper = new ArrayList();
			noSuper.add(body);
			noSuper.add(per);
			return ar.bypass(noSuper);
		}

		if (ar.kind() == AmbiguityRemover.SIGNATURES) {
			return ar.bypass(per);
		}

		return ar;
	}

	protected AspectDecl_c reconstruct(final TypeNode superClass,
			final List interfaces, final PerClause per, final ClassBody body) {
		if (superClass != this.superClass
				|| !CollectionUtil.equals(interfaces, this.interfaces)
				|| per != this.per || body != this.body) {
			final AspectDecl_c n = (AspectDecl_c) copy();
			n.superClass = superClass;
			n.interfaces = TypedList.copyAndCheck(interfaces, TypeNode.class,
					true);
			n.per = per;
			n.body = body;
			return n;
		}

		return this;
	}

	@Override
	public Node visitChildren(final NodeVisitor v) {
		final TypeNode superClass = (TypeNode) visitChild(this.superClass, v);
		final List interfaces = visitList(this.interfaces, v);
		final PerClause per = (PerClause) visitChild(this.per, v);
		final ClassBody body = (ClassBody) visitChild(this.body, v);
		return reconstruct(superClass, interfaces, per, body);
	}

	@Override
	public Context enterScope(final Node child, Context c) {
		if (child == this.per) {
			// final TypeSystem ts =
			c.typeSystem();
			c = ((AJContext) c).pushAspect((AspectType) type);
			// c = c.pushClass(type, ts.staticTarget(type).toClass());
			return child.del().enterScope(c);
		}
		return super.enterScope(child, c);
	}

	@Override
	public Context enterScope(final Context c) {
		return ((AJContext) c).pushAspect((AspectType) type);
	}

	@Override
	public void prettyPrintHeader(final CodeWriter w, final PrettyPrinter tr) {

		// need to overwrite, because ClassDecl_c only knows of interfaces and
		// classes
		w.write(AJFlags.clearAspectclass(flags).translate());
		w.write("aspect ");

		w.write(name);

		if (superClass() != null) {
			w.write(" extends ");
			print(superClass(), w, tr);
		}

		if (!interfaces.isEmpty()) {
			if (flags.isInterface()) {
				w.write(" extends ");
			} else {
				w.write(" implements ");
			}

			for (final Iterator i = interfaces().iterator(); i.hasNext();) {
				final TypeNode tn = (TypeNode) i.next();
				print(tn, w, tr);

				if (i.hasNext()) {
					w.write(", ");
				}
			}
		}

		w.write(" {");
	}

	@Override
	public Node typeCheck(final TypeChecker tc) throws SemanticException {
		if (type().isNested() && !flags().isStatic()) {
			throw new SemanticException("Nested aspects must be static",
					position());
		}
		final AspectDecl t = (AspectDecl) super.typeCheck(tc);
		final TypeSystem ts = tc.typeSystem();
		final Stack s = new Stack();
		s.push(t.type());
		final Set visited = new HashSet();
		while (!s.isEmpty()) {
			final ClassType ct = (ClassType) s.pop();
			if (visited.contains(ct)) {
				continue;
			}
			visited.add(ct);
			if (ct.interfaces().contains(ts.Serializable())) {
				throw new SemanticException(
						"Aspects cannot implement Serializable", position());
			}
			if (ct.interfaces().contains(ts.Cloneable())) {
				throw new SemanticException(
						"Aspects cannot implement Cloneable", position());
			}
			if (ct.superType() != null) {
				s.push(ct.superType());
			}
			s.addAll(ct.interfaces());
		}
		if (superClass() != null && (superClass.type() instanceof AspectType)
				&& !superClass.type().toClass().flags().isAbstract()) {
			throw new SemanticException(
					"Only abstract aspects can be extended", superClass
							.position());
		}
		return t;
	}

	public void update(final GlobalAspectInfo gai, final Aspect current_aspect) {
		final Per p = (per == null ? null : per.makeAIPer());
		final AbcClass cl = AbcFactory.AbcClass(type());
		final Aspect a = new Aspect(cl, p, position());
		gai.addAspect(a);

		final List fl = new ArrayList();
		if (((AspectType) type()).perObject()) {
			fl.add(new Formal(AbcFactory.AbcType(soot.RefType
					.v("java.lang.Object")), "obj", position()));
		}

		final List el = new ArrayList();
		// FIXME: Do these methods declare any exceptions?
		if (!flags().isAbstract()) {

			final MethodSig aspectOf = new MethodSig(soot.Modifier.PUBLIC
					| soot.Modifier.STATIC, cl, AbcFactory.AbcType(type()),
					"aspectOf", fl, el, position());
			final MethodSig hasAspect = new MethodSig(soot.Modifier.PUBLIC
					| soot.Modifier.STATIC, cl, AbcFactory
					.AbcType(soot.BooleanType.v()), "hasAspect", fl, el,
					position());

			MethodCategory.register(aspectOf, MethodCategory.ASPECT_INSTANCE);
			MethodCategory.register(hasAspect, MethodCategory.ASPECT_INSTANCE);
		}
	}

	@Override
	public void aspectMethodsEnter(final AspectMethods visitor) {
		visitor.pushClass();
		visitor.pushContainer(type());
	}

	@Override
	public Node aspectMethodsLeave(final AspectMethods visitor,
			final AJNodeFactory nf, final AJTypeSystem ts) {
		AspectDecl_c cd = this;
		final List localMethods = visitor.methods();
		visitor.popClass();
		visitor.popContainer();

		for (final Iterator i = localMethods.iterator(); i.hasNext();) {
			final MethodDecl md = (MethodDecl) i.next();
			cd = (AspectDecl_c) this.body(cd.body().addMember(md));
		}

		cd.type().flags(cd.flags().Public());

		// add errors generaced by accessor methods to error queue
		for (final Iterator it = abc.main.Main.v().getAbcExtension()
				.getGlobalAspectInfo().getNonWeavableClassErrors().iterator(); it
				.hasNext();) {
			visitor.job().compiler().errorQueue()
					.enqueue((ErrorInfo) it.next());
		}
		abc.main.Main.v().getAbcExtension().getGlobalAspectInfo()
				.getNonWeavableClassErrors().clear();

		return cd.addAspectMembers(nf, ts).flags(cd.flags().Public());
	}
}
