/* abc - The AspectBench Compiler
 * Copyright (C) 2004 Oege de Moor
 * Copyright (C) 2004 Aske Simon Christensen
 *
 * This compiler is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This compiler is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this compiler, in the file LESSER-GPL;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

package abc.aspectj.ast;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import polyglot.ast.Node;
import polyglot.types.ClassType;
import polyglot.types.SemanticException;
import polyglot.util.CodeWriter;
import polyglot.util.CollectionUtil;
import polyglot.util.Position;
import polyglot.util.TypedList;
import polyglot.visit.NodeVisitor;
import polyglot.visit.PrettyPrinter;
import polyglot.visit.TypeChecker;
import abc.aspectj.types.AspectType;
import abc.aspectj.visit.ContainsAspectInfo;
import abc.aspectj.visit.PCStructure;
import abc.aspectj.visit.PatternMatcher;
import abc.weaving.aspectinfo.AbcClass;
import abc.weaving.aspectinfo.Aspect;
import abc.weaving.aspectinfo.GlobalAspectInfo;

/**
 * 
 * @author Oege de Moor
 * @author Aske Simon Christensen
 * 
 */
public class DeclarePrecedence_c extends DeclareDecl_c implements
		DeclarePrecedence, ContainsAspectInfo {

	TypedList pats;

	public DeclarePrecedence_c(final Position pos, final List pats) {
		super(pos);
		this.pats = TypedList.copyAndCheck(pats, ClassnamePatternExpr.class,
				true);
	}

	protected DeclarePrecedence_c reconstruct(final TypedList pats) {
		if (!CollectionUtil.equals(pats, this.pats)) {
			final DeclarePrecedence_c n = (DeclarePrecedence_c) copy();
			n.pats = TypedList.copyAndCheck(pats, ClassnamePatternExpr.class,
					true);
			return n;
		}
		return this;
	}

	@Override
	public Node visitChildren(final NodeVisitor v) {
		final TypedList pats = new TypedList(visitList(this.pats, v),
				ClassnamePatternExpr.class, true);
		return reconstruct(pats);
	}

	@Override
	public Node typeCheck(final TypeChecker tc) throws SemanticException {
		for (final Iterator patIt = pats.iterator(); patIt.hasNext();) {
			final ClassnamePatternExpr p = (ClassnamePatternExpr) patIt.next();
			if (p instanceof CPEName) {
				boolean matchedAspect = false;
				for (final Iterator wcs = abc.main.Main.v().getAbcExtension()
						.getGlobalAspectInfo().getWeavableClasses().iterator(); wcs
						.hasNext()
						&& !matchedAspect;) {
					final AbcClass abcc = (AbcClass) wcs.next();
					final ClassType ct = abcc.getPolyglotType();
					if (ct instanceof AspectType) {
						matchedAspect = p.matches(PatternMatcher.v(),
								PCStructure.v()
										.getClass(abcc.getPolyglotType()));
					}
				}
				if (!matchedAspect) {
					throw new SemanticException(
							"Class name "
									+ p
									+ " in precedence declaration matches no aspects (perhaps use +)",
							position());
				}
			}
		}
		return this;
	}

	@Override
	public void prettyPrint(final CodeWriter w, final PrettyPrinter tr) {
		w.write("declare precedence : ");
		for (final Iterator i = pats.iterator(); i.hasNext();) {
			final ClassnamePatternExpr en = (ClassnamePatternExpr) i.next();
			print(en, w, tr);

			if (i.hasNext()) {
				w.write(", ");
			}
		}
		w.write(";");
	}

	public List pats() {
		return pats;
	}

	public void update(final GlobalAspectInfo gai, final Aspect current_aspect) {
		final List cnpats = new ArrayList();
		final Iterator pi = pats.iterator();
		while (pi.hasNext()) {
			final ClassnamePatternExpr p = (ClassnamePatternExpr) pi.next();
			cnpats.add(p.makeAIClassnamePattern());
		}
		gai.addDeclarePrecedence(new abc.weaving.aspectinfo.DeclarePrecedence(
				cnpats, current_aspect, position()));
	}
}
