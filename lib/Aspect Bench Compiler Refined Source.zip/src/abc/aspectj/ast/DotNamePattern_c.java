/* abc - The AspectBench Compiler
 * Copyright (C) 2004 Oege de Moor
 * Copyright (C) 2004 Aske Simon Christensen
 *
 * This compiler is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This compiler is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this compiler, in the file LESSER-GPL;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

package abc.aspectj.ast;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.regex.Pattern;

import polyglot.util.CodeWriter;
import polyglot.util.Position;
import polyglot.visit.PrettyPrinter;
import abc.aspectj.visit.PCNode;
import abc.aspectj.visit.PatternMatcher;

/**
 * 
 * @author Oege de Moor
 * @author Aske Simon Christensen
 * 
 */
public class DotNamePattern_c extends NamePattern_c implements DotNamePattern {
	NamePattern init;
	SimpleNamePattern last;

	public DotNamePattern_c(final Position pos, final NamePattern init,
			final SimpleNamePattern last) {
		super(pos);
		this.init = init;
		this.last = last;
	}

	@Override
	public void prettyPrint(final CodeWriter w, final PrettyPrinter tr) {
		print(init, w, tr);
		w.write(".");
		print(last, w, tr);
	}

	@Override
	public String toString() {
		return init + "." + last;
	}

	public NamePattern getInit() {
		return init;
	}

	public SimpleNamePattern getLast() {
		return last;
	}

	public Set/* <PCNode> */match(final PCNode context,
			final Set/* <PCNode> */classes, final Set/* <PCNode> */packages) {
		final Set/* <PCNode> */init_matches = init.match(context, classes,
				packages);
		final Set/* <PCNode> */result = new HashSet();
		final Pattern lp = PatternMatcher.v().compileNamePattern(
				((SimpleNamePattern_c) last).pat);
		final Iterator imi = init_matches.iterator();
		while (imi.hasNext()) {
			final PCNode im = (PCNode) imi.next();
			result.addAll(im.matchClass(lp));
		}
		return result;
	}

	public boolean universal() {
		return false;
	}

	public boolean equivalent(final NamePattern p) {
		if (p.getClass() == this.getClass()) {
			final DotNamePattern dnp = (DotNamePattern) p;
			return (init.equivalent(dnp.getInit()) && last.equivalent(dnp
					.getLast()));
		} else {
			return false;
		}
	}

}
