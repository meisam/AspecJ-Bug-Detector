/* abc - The AspectBench Compiler
 * Copyright (C) 2004 Oege de Moor
 * Copyright (C) 2004 Aske Simon Christensen
 *
 * This compiler is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This compiler is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this compiler, in the file LESSER-GPL;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

package abc.aspectj.ast;

import polyglot.ast.Node;
import polyglot.ast.Precedence;
import polyglot.types.SemanticException;
import polyglot.util.CodeWriter;
import polyglot.util.Position;
import polyglot.visit.NodeVisitor;
import polyglot.visit.PrettyPrinter;
import abc.aspectj.visit.PCNode;
import abc.aspectj.visit.PatternMatcher;

/**
 * A type pattern expression for array types.
 * 
 * @author Oege de Moor
 * @author Aske Simon Christensen
 */
public class TPEArray_c extends TypePatternExpr_c implements TPEArray {
	protected TypePatternExpr base;
	protected int dims;

	public TypePatternExpr base() {
		return base;
	}

	public int dims() {
		return dims;
	}

	public TPEArray_c(final Position pos, final TypePatternExpr base,
			final int dims) {
		super(pos);
		this.base = base;
		this.dims = dims;
	}

	protected TPEArray_c reconstruct(final TypePatternExpr base) {
		if (base != this.base) {
			final TPEArray_c n = (TPEArray_c) copy();
			n.base = base;
			return n;
		}
		return this;
	}

	@Override
	public Node visitChildren(final NodeVisitor v) {
		final TypePatternExpr base = (TypePatternExpr) visitChild(this.base, v);
		return reconstruct(base);
	}

	@Override
	public Precedence precedence() {
		return Precedence.UNARY;
	}

	@Override
	public void prettyPrint(final CodeWriter w, final PrettyPrinter tr) {
		print(base, w, tr);
		for (int i = 0; i < dims; i++) {
			w.write("[]");
		}
	}

	@Override
	public String toString() {
		String s = base.toString();
		for (int i = 0; i < dims; i++) {
			s += "[]";
		}
		return s;
	}

	public boolean matchesClass(final PatternMatcher matcher, final PCNode cl) {
		return false;
	}

	public boolean matchesClassArray(final PatternMatcher matcher,
			final PCNode cl, final int dim) {
		if (dim == dims) {
			return base.matchesClass(matcher, cl);
		}
		if (dim > dims) {
			return base.matchesClassArray(matcher, cl, dim - dims);
		}
		return false;
	}

	public boolean matchesPrimitive(final PatternMatcher matcher,
			final String prim) {
		return false;
	}

	public boolean matchesPrimitiveArray(final PatternMatcher matcher,
			final String prim, final int dim) {
		if (dim == dims) {
			return base.matchesPrimitive(matcher, prim);
		}
		if (dim > dims) {
			return base.matchesPrimitiveArray(matcher, prim, dim - dims);
		}
		return false;
	}

	public ClassnamePatternExpr transformToClassnamePattern(
			final AJNodeFactory nf) throws SemanticException {
		throw new SemanticException("Array in classname attern");
	}

	public boolean equivalent(final TypePatternExpr t) {
		if (t.getClass() == this.getClass()) {
			final TPEArray tar = (TPEArray) t;
			return ((base.equivalent(tar.base())) && (dims == tar.dims()));
		} else {
			return false;
		}
	}

}
