/* abc - The AspectBench Compiler
 * Copyright (C) 2004 Oege de Moor
 * Copyright (C) 2004 Aske Simon Christensen
 *
 * This compiler is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This compiler is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this compiler, in the file LESSER-GPL;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

package abc.aspectj.ast;

import polyglot.ast.Node;
import polyglot.util.CodeWriter;
import polyglot.util.Position;
import polyglot.visit.NodeVisitor;
import polyglot.visit.PrettyPrinter;
import abc.aspectj.visit.ContainsAspectInfo;
import abc.weaving.aspectinfo.Aspect;
import abc.weaving.aspectinfo.DeclareMessage;
import abc.weaving.aspectinfo.GlobalAspectInfo;

/**
 * declare warning : <pointcut> : <message>;
 * 
 * @author Oege de Moor
 * @author Aske Simon Christensen
 * 
 */
public class DeclareWarning_c extends DeclareDecl_c implements DeclareWarning,
		ContainsAspectInfo {

	Pointcut pc;
	String text;

	public DeclareWarning_c(final Position pos, final Pointcut pc,
			final String text) {
		super(pos);
		this.pc = pc;
		this.text = text;
	}

	@Override
	public void prettyPrint(final CodeWriter w, final PrettyPrinter tr) {
		w.write("declare warning : ");
		print(pc, w, tr);
		w.write(" : ");
		w.write("\"" + text + "\"");
		w.write(";");
	}

	protected DeclareWarning_c reconstruct(final Pointcut pc) {
		if (pc != this.pc) {
			final DeclareWarning_c n = (DeclareWarning_c) copy();
			n.pc = pc;
			return n;
		}
		return this;
	}

	@Override
	public Node visitChildren(final NodeVisitor v) {
		final Pointcut pc = (Pointcut) visitChild(this.pc, v);
		return reconstruct(pc);
	}

	public void update(final GlobalAspectInfo gai, final Aspect current_aspect) {
		gai.addDeclareMessage(new DeclareMessage(DeclareMessage.WARNING, pc
				.makeAIPointcut(), text, current_aspect, position()));
	}
}
