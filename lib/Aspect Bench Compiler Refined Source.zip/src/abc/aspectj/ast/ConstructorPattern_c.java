/* abc - The AspectBench Compiler
 * Copyright (C) 2004 Oege de Moor
 * Copyright (C) 2004 Aske Simon Christensen
 *
 * This compiler is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This compiler is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this compiler, in the file LESSER-GPL;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

package abc.aspectj.ast;

import java.util.Iterator;
import java.util.List;

import polyglot.ast.Node;
import polyglot.ext.jl.ast.Node_c;
import polyglot.util.CodeWriter;
import polyglot.util.Position;
import polyglot.visit.NodeVisitor;
import polyglot.visit.PrettyPrinter;
import abc.aspectj.visit.PatternMatcher;

/**
 * patterns to capture constructor joinpoints.
 * 
 * @author Oege de Moor
 * @author Aske Simon Christensen
 */
public class ConstructorPattern_c extends Node_c implements ConstructorPattern {

	List modifiers; // of ModifierPattern
	ClassTypeDotNew name;
	List formals; // of FormalPattern
	List throwspats; // of ThrowsPattern

	public ConstructorPattern_c(final Position pos, final List modifiers,
			final ClassTypeDotNew name, final List formals,
			final List throwspats) {
		super(pos);
		this.modifiers = modifiers;
		this.name = name;
		this.formals = formals;
		this.throwspats = throwspats;
	}

	protected ConstructorPattern_c reconstruct(
			final List/* <ModifierPattern> */modifiers,
			final ClassTypeDotNew name, final List/* <FormalPattern> */formals,
			final List/* <ThrowsPattern> */throwspats) {
		if (modifiers != this.modifiers || name != this.name
				|| formals != this.formals || throwspats != this.throwspats) {

			final ConstructorPattern_c n = (ConstructorPattern_c) copy();
			n.modifiers = modifiers;
			n.name = name;
			n.formals = formals;
			n.throwspats = throwspats;
			return n;
		}
		return this;
	}

	@Override
	public Node visitChildren(final NodeVisitor v) {
		final List/* <ModifierPattern> */modifiers = visitList(this.modifiers, v);
		final ClassTypeDotNew name = (ClassTypeDotNew) visitChild(this.name, v);
		final List/* <FormalPattern> */formals = visitList(this.formals, v);
		final List/* <ThrowsPattern> */throwspats = visitList(this.throwspats, v);
		return reconstruct(modifiers, name, formals, throwspats);
	}

	@Override
	public void prettyPrint(final CodeWriter w, final PrettyPrinter tr) {

		for (final Iterator i = modifiers.iterator(); i.hasNext();) {
			final ModifierPattern f = (ModifierPattern) i.next();
			print(f, w, tr);
		}

		print(name, w, tr);

		w.write("(");
		w.begin(0);
		for (final Iterator i = formals.iterator(); i.hasNext();) {
			final FormalPattern f = (FormalPattern) i.next();
			print(f, w, tr);

			if (i.hasNext()) {
				w.write(",");
				w.allowBreak(0, " ");
			}
		}
		w.end();
		w.write(")");

		if (throwspats.size() != 0) {
			w.write(" throws ");
			for (final Iterator ti = throwspats.iterator(); ti.hasNext();) {
				final ThrowsPattern t = (ThrowsPattern) ti.next();
				print(t, w, tr);
				if (ti.hasNext()) {
					w.write(", ");
				}
			}
		}
	}

	@Override
	public String toString() {
		final StringBuffer sb = new StringBuffer();

		for (final Iterator i = modifiers.iterator(); i.hasNext();) {
			final ModifierPattern f = (ModifierPattern) i.next();
			sb.append(f);
		}

		sb.append(name);

		sb.append("(");
		for (final Iterator i = formals.iterator(); i.hasNext();) {
			final FormalPattern f = (FormalPattern) i.next();
			sb.append(f);

			if (i.hasNext()) {
				sb.append(",");
			}
		}
		sb.append(")");

		if (throwspats.size() != 0) {
			sb.append(" throws ");
			for (final Iterator ti = throwspats.iterator(); ti.hasNext();) {
				final ThrowsPattern t = (ThrowsPattern) ti.next();
				sb.append(t);
				if (ti.hasNext()) {
					sb.append(", ");
				}
			}
		}
		return sb.toString();
	}

	public List/* <ModifierPattern> */getModifiers() {
		return modifiers;
	}

	public ClassTypeDotNew getName() {
		return name;
	}

	public List/* <FormalPattern> */getFormals() {
		return formals;
	}

	public List/* <ThrowsPattern> */getThrowspats() {
		return throwspats;
	}

	public abc.weaving.aspectinfo.ConstructorPattern makeAIConstructorPattern() {
		return PatternMatcher.v().makeAIConstructorPattern(this);
	}

	public boolean equivalent(final ConstructorPattern p) {

		if (!name.equivalent(p.getName())) {
			return false;
		}

		// COMPARE MODIFIERS

		Iterator it1 = modifiers.iterator();
		Iterator it2 = p.getModifiers().iterator();

		while (it1.hasNext() && it2.hasNext()) {
			if (!((ModifierPattern) it1.next())
					.equivalent((ModifierPattern) it2.next())) {
				return false;
			}
		}
		if (it1.hasNext() || it2.hasNext()) {
			return false;
		}

		// COMPARE FORMALS

		it1 = formals.iterator();
		it2 = p.getFormals().iterator();

		while (it1.hasNext() && it2.hasNext()) {
			if (!((FormalPattern) it1.next()).equivalent((FormalPattern) it2
					.next())) {
				return false;
			}
		}
		if (it1.hasNext() || it2.hasNext()) {
			return false;
		}

		// COMPARE THROWSPATTERNS

		it1 = throwspats.iterator();
		it2 = p.getThrowspats().iterator();

		while (it1.hasNext() && it2.hasNext()) {
			if (!((ThrowsPattern) it1.next()).equivalent((ThrowsPattern) it2
					.next())) {
				return false;
			}
		}
		if (it1.hasNext() || it2.hasNext()) {
			return false;
		}

		return true;

	}

	public boolean canMatchEmptyArgumentList() {
		if (formals.size() == 0) {
			return true;
		}
		if (formals.size() > 1) {
			return false;
		}
		return (formals.get(0) instanceof DotDotFormalPattern);
	}

}
