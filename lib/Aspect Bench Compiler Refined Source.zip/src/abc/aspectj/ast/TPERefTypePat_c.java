/* abc - The AspectBench Compiler
 * Copyright (C) 2004 Oege de Moor
 * Copyright (C) 2004 Aske Simon Christensen
 *
 * This compiler is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This compiler is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this compiler, in the file LESSER-GPL;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

package abc.aspectj.ast;

import polyglot.ast.Node;
import polyglot.ast.Precedence;
import polyglot.types.SemanticException;
import polyglot.util.CodeWriter;
import polyglot.util.Position;
import polyglot.visit.NodeVisitor;
import polyglot.visit.PrettyPrinter;
import abc.aspectj.visit.PCNode;
import abc.aspectj.visit.PatternMatcher;

/**
 * A type pattern expression that is a reference type pattern.
 * 
 * @author Oege de Moor
 * @author Aske Simon Christensen
 */
public class TPERefTypePat_c extends TypePatternExpr_c implements TPERefTypePat {
	protected RefTypePattern pat;

	public RefTypePattern getPattern() {
		return pat;
	}

	public TPERefTypePat_c(final Position pos, final RefTypePattern pat) {
		super(pos);
		this.pat = pat;
	}

	@Override
	public Precedence precedence() {
		return Precedence.UNARY;
	}

	/** Reconstruct the pattern. */
	protected TPERefTypePat_c reconstruct(final RefTypePattern pat) {
		if (pat != this.pat) {
			final TPERefTypePat_c n = (TPERefTypePat_c) copy();
			n.pat = pat;
			return n;
		}

		return this;
	}

	/** Visit the children of the pattern. */
	@Override
	public Node visitChildren(final NodeVisitor v) {
		final RefTypePattern pat = (RefTypePattern) visitChild(this.pat, v);
		return reconstruct(pat);
	}

	@Override
	public void prettyPrint(final CodeWriter w, final PrettyPrinter tr) {
		print(pat, w, tr);
	}

	@Override
	public String toString() {
		return pat.toString();
	}

	public boolean matchesClass(final PatternMatcher matcher, final PCNode cl) {
		return pat.matchesClass(matcher, cl);
	}

	public boolean matchesClassArray(final PatternMatcher matcher,
			final PCNode cl, final int dim) {
		return pat.matchesArray(matcher);
	}

	public boolean matchesPrimitive(final PatternMatcher matcher,
			final String prim) {
		return false;
	}

	public boolean matchesPrimitiveArray(final PatternMatcher matcher,
			final String prim, final int dim) {
		return pat.matchesArray(matcher);
	}

	public ClassnamePatternExpr transformToClassnamePattern(
			final AJNodeFactory nf) throws SemanticException {
		return pat.transformToClassnamePattern(nf);
	}

	public boolean equivalent(final TypePatternExpr t) {
		if (t.getClass() == this.getClass()) {
			return (pat.equivalent(((TPERefTypePat) t).getPattern()));
		} else {
			return false;
		}
	}

}
