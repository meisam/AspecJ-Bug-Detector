/* abc - The AspectBench Compiler
 * Copyright (C) 2004 Oege de Moor
 * Copyright (C) 2004 Aske Simon Christensen
 *
 * This compiler is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This compiler is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this compiler, in the file LESSER-GPL;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

package abc.aspectj.ast;

import polyglot.ast.Node;
import polyglot.ext.jl.ast.Node_c;
import polyglot.util.CodeWriter;
import polyglot.util.Position;
import polyglot.visit.NodeVisitor;
import polyglot.visit.PrettyPrinter;

/**
 * represent ClassnamePatternExpr.SimpleNamePattern in pointcuts.
 * 
 * @author Oege de Moor
 * @author Aske Simon Christensen
 */
public class ClassTypeDotId_c extends Node_c implements ClassTypeDotId {
	protected ClassnamePatternExpr base;
	protected SimpleNamePattern name;

	public ClassTypeDotId_c(final Position pos,
			final ClassnamePatternExpr base, final SimpleNamePattern name) {
		super(pos);
		this.base = base;
		this.name = name;
	}

	protected ClassTypeDotId_c reconstruct(final ClassnamePatternExpr base,
			final SimpleNamePattern name) {
		if (base != this.base || name != this.name) {
			final ClassTypeDotId_c n = (ClassTypeDotId_c) copy();
			n.base = base;
			n.name = name;
			return n;
		}
		return this;
	}

	@Override
	public Node visitChildren(final NodeVisitor v) {
		final ClassnamePatternExpr base = (ClassnamePatternExpr) visitChild(
				this.base, v);
		final SimpleNamePattern name = (SimpleNamePattern) visitChild(
				this.name, v);
		return reconstruct(base, name);
	}

	public ClassnamePatternExpr base() {
		return base;
	}

	public SimpleNamePattern name() {
		return name;
	}

	@Override
	public void prettyPrint(final CodeWriter w, final PrettyPrinter tr) {
		if (name != null) {
			w.write("(");
		}
		print(base, w, tr);
		if (name != null) {
			w.write(").");
			print(name, w, tr);
		}
	}

	@Override
	public String toString() {
		String s = "";
		if (name != null) {
			s += "(";
		}
		s += base;
		if (name != null) {
			s += ")." + name;
		}
		return s;
	}

	public boolean equivalent(final ClassTypeDotId c) {
		return (base.equivalent(c.base()) && name.equivalent(c.name()));
	}

}
