/* abc - The AspectBench Compiler
 * Copyright (C) 2004 Oege de Moor
 * Copyright (C) 2004 Aske Simon Christensen
 *
 * This compiler is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This compiler is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this compiler, in the file LESSER-GPL;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

package abc.aspectj.ast;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import polyglot.ast.Block;
import polyglot.ast.Expr;
import polyglot.ast.Formal;
import polyglot.ast.Local;
import polyglot.ast.MethodDecl;
import polyglot.ast.Node;
import polyglot.ast.Precedence;
import polyglot.ast.Return;
import polyglot.ast.TypeNode;
import polyglot.types.ClassType;
import polyglot.types.Context;
import polyglot.types.Flags;
import polyglot.types.LocalInstance;
import polyglot.types.MethodInstance;
import polyglot.types.ParsedClassType;
import polyglot.types.SemanticException;
import polyglot.types.Type;
import polyglot.types.TypeSystem;
import polyglot.util.CodeWriter;
import polyglot.util.Position;
import polyglot.util.UniqueID;
import polyglot.visit.AscriptionVisitor;
import polyglot.visit.NodeVisitor;
import polyglot.visit.PrettyPrinter;
import polyglot.visit.TypeChecker;
import abc.aspectj.types.AJContext;
import abc.aspectj.types.AJTypeSystem;
import abc.aspectj.visit.AspectMethods;
import abc.aspectj.visit.AspectReflectionInspect;
import abc.aspectj.visit.AspectReflectionRewrite;
import abc.main.Debug;
import abc.weaving.aspectinfo.AbcFactory;
import abc.weaving.aspectinfo.MethodCategory;

/**
 * 
 * @author Oege de Moor
 * @author Aske Simon Christensen
 * 
 */
public class PCIf_c extends Pointcut_c implements PCIf, MakesAspectMethods {
	protected Expr expr;
	protected String methodName;
	protected MethodDecl methodDecl;

	public PCIf_c(final Position pos, final Expr expr) {
		super(pos);
		this.expr = expr;
	}

	@Override
	public Precedence precedence() {
		return Precedence.LITERAL;
	}

	public Set pcRefs() {
		return new HashSet();
	}

	public boolean isDynamic() {
		return true;
	}

	@Override
	public void prettyPrint(final CodeWriter w, final PrettyPrinter tr) {
		w.write("if(");
		print(expr, w, tr);
		w.write(")");
	}

	/** Reconstruct the pointcut. */
	protected PCIf_c reconstruct(final Expr expr) {
		if (expr != this.expr) {
			final PCIf_c n = (PCIf_c) copy();
			n.expr = expr;
			return n;
		}

		return this;
	}

	/** Visit the children of the pointcut. */
	@Override
	public Node visitChildren(final NodeVisitor v) {
		final Expr expr = (Expr) visitChild(this.expr, v);
		return reconstruct(expr);
	}

	/** Type check the pointcut. */
	@Override
	public Node typeCheck(final TypeChecker tc) throws SemanticException {
		final TypeSystem ts = tc.typeSystem();

		final AJContext c = (AJContext) tc.context();
		if (c.inDeclare() && !Debug.v().allowDynamicTests) {
			throw new SemanticException(
					"if(..) requires a dynamic test and cannot be used inside a \"declare\" statement",
					position());
		}

		if (!ts.equals(expr.type(), ts.Boolean())) {
			throw new SemanticException(
					"Condition of if pointcut must have boolean type.", expr
							.position());
		}

		return this;
	}

	@Override
	public Type childExpectedType(final Expr child, final AscriptionVisitor av) {
		final TypeSystem ts = av.typeSystem();

		if (child == expr) {
			return ts.Boolean();
		}

		return child.type();
	}

	protected boolean hasJoinPoint = false;
	protected boolean hasJoinPointStaticPart = false;
	protected boolean hasEnclosingJoinPointStaticPart = false;

	public boolean hasJoinPointStaticPart() {
		return hasJoinPointStaticPart;
	}

	public boolean hasJoinPoint() {
		return hasJoinPoint;
	}

	public boolean hasEnclosingJoinPointStaticPart() {
		return hasEnclosingJoinPointStaticPart;
	}

	public void joinpointFormals(final Local n) {
		hasJoinPoint = hasJoinPoint || (n.name().equals("thisJoinPoint"));
		hasJoinPointStaticPart = hasJoinPointStaticPart
				|| (n.name().equals("thisJoinPointStaticPart"));
		hasEnclosingJoinPointStaticPart = hasEnclosingJoinPointStaticPart
				|| (n.name().equals("thisEnclosingJoinPointStaticPart"));
	}

	protected LocalInstance thisJoinPointInstance = null;
	protected LocalInstance thisJoinPointStaticPartInstance = null;
	protected LocalInstance thisEnclosingJoinPointStaticPartInstance = null;

	private LocalInstance thisJoinPointInstance(final AJTypeSystem ts) {
		if (thisJoinPointInstance == null) {
			thisJoinPointInstance = ts.localInstance(position(), Flags.FINAL,
					ts.JoinPoint(), "thisJoinPoint");
		}
		return thisJoinPointInstance;
	}

	private LocalInstance thisJoinPointStaticPartInstance(final AJTypeSystem ts) {
		if (thisJoinPointStaticPartInstance == null) {
			thisJoinPointStaticPartInstance = ts.localInstance(position(),
					Flags.FINAL, ts.JoinPointStaticPart(),
					"thisJoinPointStaticPart");
		}
		return thisJoinPointStaticPartInstance;
	}

	private LocalInstance thisEnclosingJoinPointStaticPartInstance(
			final AJTypeSystem ts) {
		if (thisEnclosingJoinPointStaticPartInstance == null) {
			thisEnclosingJoinPointStaticPartInstance = ts.localInstance(
					position(), Flags.FINAL, ts.JoinPointStaticPart(),
					"thisEnclosingJoinPointStaticPart");
		}
		return thisEnclosingJoinPointStaticPartInstance;
	}

	protected boolean canRewriteThisJoinPoint = false;

	public MethodDecl exprMethod(final AJNodeFactory nf, final AJTypeSystem ts,
			final List formals, final ParsedClassType container) {
		final Return ret = nf.Return(position(), expr);
		final Block bl = nf.Block(position()).append(ret);
		final TypeNode retType = nf.CanonicalTypeNode(position(), ts.Boolean());
		final List args = new LinkedList(formals);
		final List throwTypes = new LinkedList();
		for (final Iterator i = expr.throwTypes(ts).iterator(); i.hasNext();) {
			final Type t = (Type) i.next();
			final TypeNode tn = nf.CanonicalTypeNode(position(), t);
			throwTypes.add(tn);
		}
		final List formaltypes = new ArrayList();
		final Iterator fi = formals.iterator();
		while (fi.hasNext()) {
			final Formal f = (Formal) fi.next();
			formaltypes.add(f.type().type());
		}

		addJoinPointFormals(nf, ts, args, formaltypes);

		methodName = UniqueID.newID("if");
		MethodDecl md = nf.MethodDecl(position(), Flags.STATIC.Public(),
				retType, methodName, args, throwTypes, bl);
		final MethodInstance mi = ts.methodInstance(position, container,
				Flags.STATIC.Public(), retType.type(), methodName,
				new ArrayList(formaltypes), new ArrayList(expr.del()
						.throwTypes(ts)));
		container.addMethod(mi);
		md = md.methodInstance(mi);
		methodDecl = md;
		return md;
	}

	protected void addJoinPointFormals(final AJNodeFactory nf,
			final AJTypeSystem ts, final List args, final List formaltypes) {
		if (hasJoinPointStaticPart()) {
			addJoinPointFormal(nf, ts, args, formaltypes, ts
					.JoinPointStaticPart(), "thisJoinPointStaticPart",
					thisJoinPointStaticPartInstance(ts));
		}
		if (hasJoinPoint()) {
			addJoinPointFormal(nf, ts, args, formaltypes, ts.JoinPoint(),
					"thisJoinPoint", thisJoinPointInstance(ts));
		}
		if (hasEnclosingJoinPointStaticPart()) {
			addJoinPointFormal(nf, ts, args, formaltypes, ts
					.JoinPointStaticPart(), "thisEnclosingJoinPointStaticPart",
					thisEnclosingJoinPointStaticPartInstance(ts));
		}
	}

	protected void addJoinPointFormal(final AJNodeFactory nf,
			final AJTypeSystem ts, final List args, final List formaltypes,
			final ClassType jpfType, final String name, final LocalInstance li) {
		final TypeNode tn = nf.CanonicalTypeNode(position(), jpfType);
		Formal jpf = nf.Formal(position(), Flags.FINAL, tn, name);
		jpf = jpf.localInstance(li);
		args.add(jpf);
		formaltypes.add(jpfType);
	}

	public PCIf liftMethod(final AJNodeFactory nf) {
		final Expr exp = nf.Call(position(), methodName);
		return reconstruct(exp);
	}

	public abc.weaving.aspectinfo.Pointcut makeAIPointcut() {
		int lastpos = methodDecl.formals().size();
		int jp = -1, jpsp = -1, ejp = -1;
		if (hasEnclosingJoinPointStaticPart) {
			ejp = --lastpos;
		}
		if (hasJoinPoint) {
			jp = --lastpos;
		}
		if (hasJoinPointStaticPart) {
			jpsp = --lastpos;
		}

		MethodCategory.register(methodDecl, MethodCategory.IF_EXPR);

		final List vars = new ArrayList();
		final Iterator fi = methodDecl.formals().iterator();
		while (fi.hasNext()) {
			final Formal f = (Formal) fi.next();
			vars.add(new abc.weaving.aspectinfo.Var(f.name(), f.position()));
		}
		return new abc.weaving.aspectinfo.If(vars, AbcFactory
				.MethodSig(methodDecl), jp, jpsp, ejp, position);
	}

	@Override
	public Context enterScope(final Context c) {
		final AJContext ajc = ((AJContext) c.pushStatic()).pushIf();
		final AJTypeSystem ts = (AJTypeSystem) ajc.typeSystem();
		final LocalInstance jp = thisJoinPointInstance(ts);
		ajc.addVariable(jp);
		final LocalInstance sjp = thisJoinPointStaticPartInstance(ts);
		ajc.addVariable(sjp);
		final LocalInstance ejpsp = thisEnclosingJoinPointStaticPartInstance(ts);
		ajc.addVariable(ejpsp);
		return ajc;
	}

	public void aspectMethodsEnter(final AspectMethods visitor) {
		visitor.pushPCIf(this);
	}

	public Node aspectMethodsLeave(final AspectMethods visitor,
			final AJNodeFactory nf, final AJTypeSystem ts) {
		final List formals = calculateMethodParameters(visitor, nf, ts);

		final MethodDecl md = exprMethod(nf, ts, formals, visitor.container());
		visitor.addMethod(md);
		visitor.popPCIf();
		return liftMethod(nf); // replace expression by method call
	}

	protected List calculateMethodParameters(final AspectMethods visitor,
			final AJNodeFactory nf, final AJTypeSystem ts) {
		// construct method for expression in if(..).
		// When the if(..) occurs inside a cflow, the parameters are only the
		// variables bound inside that cflow. Otherwise, the parameters are
		// exactly
		// the formals of the enclosing named pointcut or advice.
		final AJContext ajc = (AJContext) visitor.context();
		List formals = new ArrayList();
		if (ajc.inCflow()) {
			final Collection cflowVars = ajc.getCflowMustBind();
			for (final Iterator varit = cflowVars.iterator(); varit.hasNext();) {
				final String varName = (String) varit.next();
				final LocalInstance li = (LocalInstance) ajc
						.findVariableSilent(varName);
				final TypeNode tn = nf.CanonicalTypeNode(li.position(), li
						.type());
				final Formal vf = nf.Formal(li.position(), Flags.FINAL, tn,
						varName).localInstance(li);
				formals.add(vf);
			}
		} else {
			formals = visitor.formals();
		}

		return formals;
	}

	public void enterAspectReflectionInspect(final AspectReflectionInspect v,
			final Node parent) {
		v.enterAdvice();
	}

	public void leaveAspectReflectionInspect(final AspectReflectionInspect v) {
		canRewriteThisJoinPoint = v.leaveAdvice();
	}

	public void enterAspectReflectionRewrite(final AspectReflectionRewrite v,
			final AJTypeSystem ts) {
		v
				.enterAdvice(canRewriteThisJoinPoint ? thisJoinPointStaticPartInstance(ts)
						: null);
	}

	public Node leaveAspectReflectionRewrite(final AspectReflectionRewrite v,
			final AJNodeFactory nf) {
		v.leaveAdvice();
		return this;
	}
}
