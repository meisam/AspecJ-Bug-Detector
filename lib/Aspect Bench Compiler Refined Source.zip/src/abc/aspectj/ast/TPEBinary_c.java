/* abc - The AspectBench Compiler
 * Copyright (C) 2004 Oege de Moor
 * Copyright (C) 2004 Aske Simon Christensen
 *
 * This compiler is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This compiler is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this compiler, in the file LESSER-GPL;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

package abc.aspectj.ast;

import polyglot.ast.Node;
import polyglot.ast.Precedence;
import polyglot.types.SemanticException;
import polyglot.util.CodeWriter;
import polyglot.util.Position;
import polyglot.visit.NodeVisitor;
import polyglot.visit.PrettyPrinter;
import abc.aspectj.visit.PCNode;
import abc.aspectj.visit.PatternMatcher;

/**
 * binary operation (&&,||) on type pattern exprs.
 * 
 * @author Oege de Moor
 * @author Aske Simon Christensen
 */
public class TPEBinary_c extends TypePatternExpr_c implements TPEBinary {
	protected TypePatternExpr left;
	protected Operator op;
	protected TypePatternExpr right;
	protected Precedence precedence;

	public TPEBinary_c(final Position pos, final TypePatternExpr left,
			final Operator op, final TypePatternExpr right) {
		super(pos);
		this.left = left;
		this.op = op;
		this.right = right;
		this.precedence = op.precedence();
	}

	public TypePatternExpr left() {
		return left;
	}

	public TypePatternExpr right() {
		return right;
	}

	public Operator op() {
		return op;
	}

	protected TPEBinary_c reconstruct(final TypePatternExpr left,
			final TypePatternExpr right) {
		if (left != this.left || right != this.right) {
			final TPEBinary_c n = (TPEBinary_c) copy();
			n.left = left;
			n.right = right;
			return n;
		}
		return this;
	}

	@Override
	public Node visitChildren(final NodeVisitor v) {
		final TypePatternExpr left = (TypePatternExpr) visitChild(this.left, v);
		final TypePatternExpr right = (TypePatternExpr) visitChild(this.right,
				v);
		return reconstruct(left, right);
	}

	@Override
	public void prettyPrint(final CodeWriter w, final PrettyPrinter tr) {
		printSubExpr(left, true, w, tr);
		w.write(" ");
		w.write(op.toString());
		w.allowBreak(2, " ");
		printSubExpr(right, false, w, tr);
	}

	@Override
	public String toString() {
		return "(" + left + " " + op + " " + right + ")";
	}

	public boolean matchesClass(final PatternMatcher matcher, final PCNode cl) {
		if (op == TPEBinary.COND_OR) {
			return left.matchesClass(matcher, cl)
					|| right.matchesClass(matcher, cl);
		}
		if (op == TPEBinary.COND_AND) {
			return left.matchesClass(matcher, cl)
					&& right.matchesClass(matcher, cl);
		}
		throw new RuntimeException("Illegal TPE op");
	}

	public boolean matchesClassArray(final PatternMatcher matcher,
			final PCNode cl, final int dim) {
		if (op == TPEBinary.COND_OR) {
			return left.matchesClassArray(matcher, cl, dim)
					|| right.matchesClassArray(matcher, cl, dim);
		}
		if (op == TPEBinary.COND_AND) {
			return left.matchesClassArray(matcher, cl, dim)
					&& right.matchesClassArray(matcher, cl, dim);
		}
		throw new RuntimeException("Illegal TPE op");
	}

	public boolean matchesPrimitive(final PatternMatcher matcher,
			final String prim) {
		if (op == TPEBinary.COND_OR) {
			return left.matchesPrimitive(matcher, prim)
					|| right.matchesPrimitive(matcher, prim);
		}
		if (op == TPEBinary.COND_AND) {
			return left.matchesPrimitive(matcher, prim)
					&& right.matchesPrimitive(matcher, prim);
		}
		throw new RuntimeException("Illegal TPE op");
	}

	public boolean matchesPrimitiveArray(final PatternMatcher matcher,
			final String prim, final int dim) {
		if (op == TPEBinary.COND_OR) {
			return left.matchesPrimitiveArray(matcher, prim, dim)
					|| right.matchesPrimitiveArray(matcher, prim, dim);
		}
		if (op == TPEBinary.COND_AND) {
			return left.matchesPrimitiveArray(matcher, prim, dim)
					&& right.matchesPrimitiveArray(matcher, prim, dim);
		}
		throw new RuntimeException("Illegal TPE op");
	}

	public ClassnamePatternExpr transformToClassnamePattern(
			final AJNodeFactory nf) throws SemanticException {
		final ClassnamePatternExpr cpe1 = left.transformToClassnamePattern(nf);
		final ClassnamePatternExpr cpe2 = right.transformToClassnamePattern(nf);
		if (op == TPEBinary.COND_OR) {
			return nf.CPEBinary(position, cpe1, CPEBinary.COND_OR, cpe2);
		}
		if (op == TPEBinary.COND_AND) {
			return nf.CPEBinary(position, cpe1, CPEBinary.COND_AND, cpe2);
		}
		throw new RuntimeException("Illegal TPE op");
	}

	public boolean equivalent(final TypePatternExpr t) {
		if (t.getClass() == this.getClass()) {
			final TPEBinary tb = (TPEBinary) t;
			return (left.equivalent(tb.left()) && right.equivalent(tb.right()) && (op == tb
					.op()));
		} else {
			return false;
		}
	}

}
