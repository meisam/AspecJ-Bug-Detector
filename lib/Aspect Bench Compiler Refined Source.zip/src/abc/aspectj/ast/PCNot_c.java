/* abc - The AspectBench Compiler
 * Copyright (C) 2004 Oege de Moor
 *
 * This compiler is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This compiler is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this compiler, in the file LESSER-GPL;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

package abc.aspectj.ast;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import polyglot.ast.Node;
import polyglot.ast.Precedence;
import polyglot.types.SemanticException;
import polyglot.util.CodeWriter;
import polyglot.util.Position;
import polyglot.visit.NodeVisitor;
import polyglot.visit.PrettyPrinter;

/**
 * Negation of a pointcut.
 * 
 * @author Oege de Moor
 * 
 */
public class PCNot_c extends Pointcut_c implements PCNot {
	protected Pointcut pc;

	public PCNot_c(final Position pos, final Pointcut pc) {
		super(pos);
		this.pc = pc;
	}

	@Override
	public Precedence precedence() {
		return Precedence.UNARY;
	}

	@Override
	public void prettyPrint(final CodeWriter w, final PrettyPrinter tr) {
		w.write("!");
		printSubExpr(pc, true, w, tr);
	}

	public Set pcRefs() {
		return pc.pcRefs();
	}

	public boolean isDynamic() {
		return pc.isDynamic();
	}

	/** Reconstruct the pointcut. */
	protected PCNot_c reconstruct(final Pointcut pc) {
		if (pc != this.pc) {
			final PCNot_c n = (PCNot_c) copy();
			n.pc = pc;
			return n;
		}

		return this;
	}

	/** Visit the children of the pointcut. */
	@Override
	public Node visitChildren(final NodeVisitor v) {
		final Pointcut pc = (Pointcut) visitChild(this.pc, v);
		return reconstruct(pc);
	}

	@Override
	public Collection mayBind() throws SemanticException {
		final Collection result = new HashSet();
		final Collection pcmaybind = pc.mayBind();
		for (final Iterator i = pcmaybind.iterator(); i.hasNext();) {
			final String l = (String) i.next();
			throw new SemanticException("Cannot bind variable " + l
					+ " under negation", position());
		}
		return result;
	}

	@Override
	public Collection mustBind() {
		return new HashSet();
	}

	public abc.weaving.aspectinfo.Pointcut makeAIPointcut() {
		return abc.weaving.aspectinfo.NotPointcut.construct(
				pc.makeAIPointcut(), position());
	}
}
