/* abc - The AspectBench Compiler
 * Copyright (C) 2004 Oege de Moor
 * Copyright (C) 2004 Aske Simon Christensen
 *
 * This compiler is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This compiler is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this compiler, in the file LESSER-GPL;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

package abc.aspectj.ast;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import polyglot.ast.ArrayInit;
import polyglot.ast.Block;
import polyglot.ast.Call;
import polyglot.ast.Cast;
import polyglot.ast.Expr;
import polyglot.ast.Formal;
import polyglot.ast.Local;
import polyglot.ast.MethodDecl;
import polyglot.ast.Node;
import polyglot.ast.Return;
import polyglot.ast.Special;
import polyglot.ast.TypeNode;
import polyglot.ext.jl.ast.FieldDecl_c;
import polyglot.types.ArrayType;
import polyglot.types.ClassType;
import polyglot.types.Context;
import polyglot.types.FieldInstance;
import polyglot.types.Flags;
import polyglot.types.LocalInstance;
import polyglot.types.MethodInstance;
import polyglot.types.ParsedClassType;
import polyglot.types.ReferenceType;
import polyglot.types.SemanticException;
import polyglot.types.Type;
import polyglot.types.TypeSystem;
import polyglot.util.CodeWriter;
import polyglot.util.Position;
import polyglot.util.UniqueID;
import polyglot.visit.AddMemberVisitor;
import polyglot.visit.NodeVisitor;
import polyglot.visit.PrettyPrinter;
import polyglot.visit.TypeChecker;
import abc.aspectj.types.AJContext;
import abc.aspectj.types.AJTypeSystem;
import abc.aspectj.types.InterTypeFieldInstance;
import abc.aspectj.types.InterTypeFieldInstance_c;
import abc.aspectj.visit.AspectMethods;
import abc.aspectj.visit.ContainsAspectInfo;
import abc.weaving.aspectinfo.AbcFactory;
import abc.weaving.aspectinfo.MethodCategory;

/**
 * 
 * @author Oege de Moor
 * @author Aske Simon Christensen
 * 
 */
public class IntertypeFieldDecl_c extends FieldDecl_c implements
		IntertypeFieldDecl, ContainsAspectInfo, MakesAspectMethods {
	protected TypeNode host;
	protected InterTypeFieldInstance hostInstance;
	protected LocalInstance thisParamInstance;
	protected String identifier;
	protected String originalName;
	protected Flags originalFlags;

	protected MethodDecl initm;

	public IntertypeFieldDecl_c(final Position pos, final Flags flags,
			final TypeNode type, final TypeNode host, final String name,
			final Expr init) {
		super(pos, flags, type, name, init);
		this.host = host;
		this.identifier = UniqueID.newID("id");
		this.originalName = name;
		this.originalFlags = flags;
	}

	public TypeNode host() {
		return host;
	}

	protected IntertypeFieldDecl_c reconstruct(final TypeNode type,
			final Expr init, final TypeNode host) {
		if (host != this.host) {
			final IntertypeFieldDecl_c n = (IntertypeFieldDecl_c) copy();
			n.host = host;
			return (IntertypeFieldDecl_c) n.reconstruct(type, init);
		}
		return (IntertypeFieldDecl_c) super.reconstruct(type, init);
	}

	@Override
	public Node visitChildren(final NodeVisitor v) {
		final TypeNode type = (TypeNode) visitChild(type(), v);
		final Expr init = (Expr) visitChild(init(), v);
		final TypeNode host = (TypeNode) visitChild(this.host, v);
		return reconstruct(type, init, host);
	}

	@Override
	public Node typeCheck(final TypeChecker tc) throws SemanticException {
		if (flags().isProtected()) {
			throw new SemanticException("Intertype fields cannot be protected",
					position());
		}
		if (flags().isStatic() && host.type().toClass().flags().isInterface()) {
			throw new SemanticException(
					"Intertype fields on interfaces cannot be static");
		}
		if (host.type() instanceof ParsedClassType
				&& !abc.main.Main
						.v()
						.getAbcExtension()
						.getGlobalAspectInfo()
						.getWeavableClasses()
						.contains(
								abc.weaving.aspectinfo.AbcFactory
										.AbcClass((ParsedClassType) host.type()))) {
			throw new SemanticException(
					"Host of an intertype declaration must be a weavable class");
		}

		return super.typeCheck(tc);
	}

	/**
	 * @author Oege de Moor
	 * @author Aske Simon Christensen add intertype field declarations to host
	 *         types
	 */
	@Override
	public NodeVisitor addMembersEnter(final AddMemberVisitor am) {
		final Type ht = host.type();
		if (ht instanceof ParsedClassType) {
			// need to make a copy because the container has changed
			final AJTypeSystem ts = (AJTypeSystem) am.typeSystem();

			// System.out.println("add field "+name() + " to "+ ht + " from " +
			// fieldInstance().container());
			final InterTypeFieldInstance_c fi = (InterTypeFieldInstance_c) ts
					.interTypeFieldInstance(position(),
							identifier,
							(ClassType) fieldInstance().container(), // origin
							(ReferenceType) ht, fieldInstance().flags(),
							fieldInstance().type(), fieldInstance().name());
			IntertypeFieldDecl_c.overrideITDField((ParsedClassType) ht, fi);
			// ((ParsedClassType)ht).addField(fi); // add field for type
			// checking

			hostInstance = fi;

			/* record instance for "this" parameter */
			final String name = UniqueID.newID("this");
			thisParamInstance = ts.localInstance(position, Flags.NONE, host
					.type(), name);
		}
		return am.bypassChildren(this);
	}

	static List fieldsNamed(final ClassType ct, final String name) {
		final List result = new LinkedList();
		for (final Iterator fldit = ct.fields().iterator(); fldit.hasNext();) {
			final FieldInstance fi = (FieldInstance) fldit.next();
			if (fi.name().equals(name)) {
				result.add(fi);
			}
		}
		return result;
	}

	public static void overrideITDField(final ClassType pht,
			final FieldInstance fi) {
		final FieldInstance toInsert = fi; // .container(pht);
		boolean added = false;
		if (pht.fieldNamed(fi.name()) != null) {
			final List fis = IntertypeFieldDecl_c.fieldsNamed(pht, fi.name());

			for (final Iterator fisIt = fis.iterator(); fisIt.hasNext();) {
				final FieldInstance finst = (FieldInstance) fisIt.next();
				if (IntertypeFieldDecl_c.zaps(fi, finst) && !added) {
					pht.fields().remove(finst);
					pht.fields().add(toInsert);
					added = true;
				} else if (IntertypeFieldDecl_c.zaps(finst, fi)) {
					// skip
				} else if (!added) {
					pht.fields().add(toInsert);
					added = true;
				}
			}
		} else {
			pht.fields().add(toInsert);
			added = true;
		}
		if (added) {
			abc.main.Main.v().getAbcExtension().getGlobalAspectInfo()
					.registerWeave(AbcFactory.AbcClass(pht));
		}
	}

	// replace this by a call to the appropriate structure!
	static boolean precedes(final ClassType ct1, final ClassType ct2) {
		return ct1.descendsFrom(ct2);
	}

	static boolean zaps(final FieldInstance mi1, final FieldInstance mi2) {
		if (!(mi1 instanceof InterTypeFieldInstance_c && mi2 instanceof InterTypeFieldInstance_c)) {
			return false;
		}
		final InterTypeFieldInstance itmi1 = (InterTypeFieldInstance) mi1;
		final InterTypeFieldInstance itmi2 = (InterTypeFieldInstance) mi2;
		return IntertypeFieldDecl_c.precedes(itmi1.origin(), itmi2.origin());
	}

	/**
	 * create a reference to the "this" parameter
	 * 
	 * @author Oege de Moor
	 */
	public Expr thisReference(final AJNodeFactory nf, final AJTypeSystem ts) {
		Local x = nf.Local(position, thisParamInstance.name());
		x = (Local) x.localInstance(thisParamInstance).type(
				thisParamInstance.type());
		return x;
	}

	protected MethodInstance initmi;

	/**
	 * create a new method for the initialiser, that has "this" of host type as
	 * a parameter. TODO: If it is static, however, it does not have any
	 * parameters.
	 * 
	 * @author Oege de Moor
	 */
	public MethodDecl initMethod(final AJNodeFactory nf, final AJTypeSystem ts) {
		final String name = UniqueID.newID("init$" + name());

		final List formals = new LinkedList();

		if (!(flags().isStatic())) {
			// the "this" parameter:
			final TypeNode tn = nf.CanonicalTypeNode(position(),
					thisParamInstance.type());
			Formal thisParam = nf.Formal(position(), Flags.FINAL, tn,
					thisParamInstance.name());
			thisParam = thisParam.localInstance(thisParamInstance);
			formals.add(thisParam);
		}

		final List throwTypes = new LinkedList();
		for (final Iterator i = init().del().throwTypes(ts).iterator(); i
				.hasNext();) {
			final Type t = (Type) i.next();
			final TypeNode ttn = nf.CanonicalTypeNode(position(), t);
			throwTypes.add(ttn);
		}

		Expr initExpr = init();
		if (init() instanceof ArrayInit) {
			final ArrayType initType = (ArrayType) init().type();
			initExpr = nf.NewArray(position, type(), initType.dims(),
					(ArrayInit) init()).type(initType);
		}

		Cast cast = nf.Cast(position(), type(), initExpr);
		cast = (Cast) cast.type(type().type());

		final Return ret = nf.Return(init().position(), cast);
		final Block body = nf.Block(init().position(), ret);

		final TypeNode rettype = nf
				.CanonicalTypeNode(position(), type().type());

		final Flags fs = Flags.PUBLIC.set(Flags.STATIC);

		MethodDecl md = nf.MethodDecl(position(), fs, rettype, name, formals,
				throwTypes, body);

		final List argtypes = new LinkedList();
		if (!(flags().isStatic())) {
			argtypes.add(thisParamInstance.type());
		}
		final List exctypes = init().del().throwTypes(ts);
		initmi = ts.methodInstance(position(), fieldInstance().container(), fs,
				type().type(), name, argtypes, exctypes);
		md = md.methodInstance(initmi);

		initm = md;
		return md;
	}

	/**
	 * replace init by method call. Note: this methodcall occurs in the host,
	 * not in the originating aspect.
	 * 
	 * @author Oege de Moor
	 */
	public IntertypeFieldDecl liftInit(final AJNodeFactory nf,
			final AJTypeSystem ts) {
		final List args = new LinkedList();
		if (!(flags().isStatic())) {
			Special targetThisRef = nf.Special(position(), Special.THIS, host);
			targetThisRef = (Special) targetThisRef.type(host.type());
			args.add(targetThisRef);
		}
		Call c = nf.Call(position, host, initmi.name(), args);
		c = c.methodInstance(initmi);

		return (IntertypeFieldDecl) init(c);
	}

	@Override
	public void prettyPrint(final CodeWriter w, final PrettyPrinter tr) {
		w.write(flags().translate());
		print(type(), w, tr);
		w.write(" ");
		print(host, w, tr);
		w.write(".");
		w.write(name());

		if (init() != null) {
			w.write(" =");
			w.allowBreak(2, " ");
			print(init(), w, tr);
		}

		w.write(";");
	}

	/**
	 * @author Oege de Moor change private intertype field decl into public,
	 *         mangling the name.
	 */
	public IntertypeFieldDecl accessChange() {
		if (flags().isPrivate() || flags().isPackage()
				|| host.type().toClass().flags().isInterface()) {
			final ParsedClassType ht = (ParsedClassType) host.type();
			final InterTypeFieldInstance fi = hostInstance; // was
															// findFieldNamed...
			ht.fields().remove(fi); // remove old instance from host type
			final FieldInstance mi = fi.mangled(); // retrieve the mangled
													// instance
			ht.addField(mi); // add new instance to host type
			return (IntertypeFieldDecl) name(mi.name()).fieldInstance(mi)
					.flags(mi.flags());
		}
		return this;
	}

	/**
	 * @author Oege de Moor record the host type in the environment, for
	 *         checking of this and super. also add fields and methods of the
	 *         host that are visible from the aspect.
	 */

	@Override
	public Context enterScope(final Node n, final Context c) {
		final AJContext nc = (AJContext) super.enterScope(c);
		if (n == init()) {
			final TypeSystem ts = nc.typeSystem();
			final AJContext ncc = (AJContext) nc.pushHost(ts.staticTarget(
					host.type()).toClass(), flags().isStatic());
			return ncc.addITMembers(host.type().toClass());
		} else {
			return nc;
		}
	}

	public void update(final abc.weaving.aspectinfo.GlobalAspectInfo gai,
			final abc.weaving.aspectinfo.Aspect current_aspect) {
		if (init() != null) {
			MethodCategory.register(initm,
					MethodCategory.INTERTYPE_FIELD_INITIALIZER);
		}

		// System.out.println("IFD host: "+host.toString());
		final abc.weaving.aspectinfo.FieldSig fs = new abc.weaving.aspectinfo.FieldSig(
				AbcFactory.modifiers(flags()), AbcFactory
						.AbcClass((ClassType) host.type()), AbcFactory
						.AbcType(type().type()), name(), null);
		gai.registerRealNameAndClass(fs, AbcFactory.modifiers(originalFlags),
				originalName, AbcFactory.AbcClass((ClassType) host.type()));

		final Call c = (Call) init();
		abc.weaving.aspectinfo.MethodSig initSig;
		if (c != null) {
			final MethodInstance mi = c.methodInstance();
			initSig = AbcFactory.MethodSig(mi);
		} else {
			initSig = null;
		}
		final MethodInstance get = hostInstance.getGet();
		final MethodInstance set = hostInstance.getSet();
		final abc.weaving.aspectinfo.MethodSig getsig = get == null ? null
				: AbcFactory.MethodSig(get);
		final abc.weaving.aspectinfo.MethodSig setsig = set == null ? null
				: AbcFactory.MethodSig(set);
		final abc.weaving.aspectinfo.IntertypeFieldDecl ifd = new abc.weaving.aspectinfo.IntertypeFieldDecl(
				fs, current_aspect, initSig, getsig, setsig, position());
		gai.addIntertypeFieldDecl(ifd);

	}

	public void aspectMethodsEnter(final AspectMethods visitor) {
		visitor.pushIntertypeDecl(this);
	}

	public Node aspectMethodsLeave(final AspectMethods visitor,
			final AJNodeFactory nf, final AJTypeSystem ts) {
		IntertypeFieldDecl_c itfd = this;
		visitor.popIntertypeDecl();

		if (itfd.init() != null) {
			final MethodDecl md = itfd.initMethod(nf, ts);
			visitor.addMethod(md);
			itfd = (IntertypeFieldDecl_c) itfd.liftInit(nf, ts);
		}
		return itfd.accessChange(); // mangle name if private
	}
}
