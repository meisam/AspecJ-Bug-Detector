/* abc - The AspectBench Compiler
 * Copyright (C) 2004 Oege de Moor
 *
 * This compiler is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This compiler is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this compiler, in the file LESSER-GPL;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

package abc.aspectj.ast;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

import polyglot.ast.Formal;
import polyglot.ast.Precedence;
import polyglot.ext.jl.ast.Node_c;
import polyglot.types.SemanticException;
import polyglot.util.CodeWriter;
import polyglot.util.Position;
import polyglot.visit.PrettyPrinter;

/**
 * 
 * @author Oege de Moor
 * 
 */
public abstract class Pointcut_c extends Node_c implements Pointcut {

	public Pointcut_c(final Position pos) {
		super(pos);
	}

	public Precedence precedence() {
		return Precedence.UNKNOWN;
	}

	public void printSubExpr(final Pointcut pc, boolean associative,
			final CodeWriter w, final PrettyPrinter pp) {
		if (!associative && precedence().equals(pc.precedence())
				|| precedence().isTighter(pc.precedence())) {
			w.write("(");
			printBlock(pc, w, pp);
			w.write(")");
		} else {
			printBlock(pc, w, pp);
		}
	}

	public Collection mayBind() throws SemanticException {
		return new HashSet();
	}

	public Collection mustBind() {
		return new HashSet();
	}

	public static String initialised;

	public void checkFormals(final List formals) throws SemanticException {

		final Collection maybind = mayBind(); // check for repeated bindings

		// now look for undefined formals
		final Collection mustbind = mustBind();

		for (final Iterator nb = formals.iterator(); nb.hasNext();) {
			final Formal l = (Formal) nb.next();
			if (!(mustbind.contains(l.name()))) {
				throw new SemanticException("Formal \"" + l.name()
						+ "\" may be unbound in pointcut.", position());
			}
		}
	}

}
