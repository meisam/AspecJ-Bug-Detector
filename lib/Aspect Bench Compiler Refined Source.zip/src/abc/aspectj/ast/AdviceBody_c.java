/* abc - The AspectBench Compiler
 * Copyright (C) 2004 Oege de Moor
 * Copyright (C) 2004 Aske Simon Christensen
 *
 * This compiler is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This compiler is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this compiler, in the file LESSER-GPL;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

package abc.aspectj.ast;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import polyglot.ast.Block;
import polyglot.ast.Expr;
import polyglot.ast.FloatLit;
import polyglot.ast.Formal;
import polyglot.ast.IntLit;
import polyglot.ast.Local;
import polyglot.ast.MethodDecl;
import polyglot.ast.Node;
import polyglot.ast.Return;
import polyglot.ast.Term;
import polyglot.ast.TypeNode;
import polyglot.ext.jl.ast.Term_c;
import polyglot.types.ClassType;
import polyglot.types.CodeInstance;
import polyglot.types.Context;
import polyglot.types.Flags;
import polyglot.types.LocalInstance;
import polyglot.types.MethodInstance;
import polyglot.types.ParsedClassType;
import polyglot.types.PrimitiveType;
import polyglot.types.ReferenceType;
import polyglot.types.SemanticException;
import polyglot.types.Type;
import polyglot.types.TypeSystem;
import polyglot.util.CodeWriter;
import polyglot.util.InternalCompilerError;
import polyglot.util.Position;
import polyglot.util.UniqueID;
import polyglot.visit.AmbiguityRemover;
import polyglot.visit.NodeVisitor;
import polyglot.visit.PrettyPrinter;
import polyglot.visit.TypeBuilder;
import polyglot.visit.TypeChecker;
import abc.aspectj.extension.AJMethodDecl_c;
import abc.aspectj.types.AJContext;
import abc.aspectj.types.AJTypeSystem;
import abc.aspectj.visit.AspectMethods;
import abc.aspectj.visit.AspectReflectionInspect;
import abc.aspectj.visit.AspectReflectionRewrite;
import abc.aspectj.visit.ContainsAspectInfo;

/**
 * An advice-body is similar to a normal method, but it can contain references
 * to special variables like <code>thisJoinPoint</code> and, if it is
 * around-advice, <code>proceed()</code>.
 * 
 * @author Oege de Moor
 * @author Aske Simon Christensen
 */
public abstract class AdviceBody_c extends AJMethodDecl_c implements
		AdviceDecl, ContainsAspectInfo, MakesAspectMethods {
	/**
	 * record whether <code> thisJoinPoint </code> occurs in the advice body.
	 * set by joinPointFormals(Local)
	 */
	protected boolean hasJoinPoint = false;
	/**
	 * record whether <code> thisJoinPointStaticPart </code> occurs in the
	 * advice body. set by joinPointFormals(Local)
	 */
	protected boolean hasJoinPointStaticPart = false;
	/**
	 * record whether <code> thisEnclosingJoinPointStaticPart </code> occurs in
	 * the advice body. set by joinPointFormals(Local)
	 */
	protected boolean hasEnclosingJoinPointStaticPart = false;

	protected LocalInstance thisJoinPointInstance = null;
	protected LocalInstance thisJoinPointStaticPartInstance = null;
	protected LocalInstance thisEnclosingJoinPointStaticPartInstance = null;

	protected boolean canRewriteThisJoinPoint = false;

	protected Set/* <CodeInstance> */methodsInAdvice;

	protected boolean isAroundAdvice;

	public AdviceBody_c(final Position pos, final Flags flags,
			final TypeNode return_type, final String name, final List formals,
			final List throwTypes, final Block body,
			final boolean isAroundAdvice) {
		super(pos, flags, return_type, name, formals, throwTypes, body);
		this.methodsInAdvice = new HashSet();
		this.isAroundAdvice = isAroundAdvice;
	}

	@Override
	public NodeVisitor disambiguateEnter(final AmbiguityRemover ar)
			throws SemanticException {
		if (ar.kind() == AmbiguityRemover.SUPER) {
			return ar.bypassChildren(this);
		} else if (ar.kind() == AmbiguityRemover.SIGNATURES && body != null) {
			return ar.bypass(body);
		}

		return ar;
	}

	protected Expr dummyVal(final AJNodeFactory nf, final Type t) {
		if (t instanceof ReferenceType) {
			return nf.NullLit(position());
		}
		if (t instanceof PrimitiveType) {
			final PrimitiveType pt = (PrimitiveType) t;
			if (pt.isChar()) {
				return nf.CharLit(position(), 'x');
			}
			if (pt.isBoolean()) {
				return nf.BooleanLit(position(), true);
			}
			if (pt.isByte()) {
				return nf.IntLit(position(), IntLit.INT, 0);
			}
			if (pt.isShort()) {
				return nf.IntLit(position(), IntLit.INT, 0);
			}
			if (pt.isInt()) {
				return nf.IntLit(position(), IntLit.INT, 0);
			}
			if (pt.isLong()) {
				return nf.IntLit(position(), IntLit.LONG, 0);
			}
			if (pt.isFloat()) {
				return nf.FloatLit(position(), FloatLit.FLOAT, 0.0);
			}
			if (pt.isDouble()) {
				return nf.FloatLit(position(), FloatLit.DOUBLE, 0.0);
			}
			if (pt.isVoid()) {
				throw new InternalCompilerError(
						"cannot create expression of void type");
			} else {
				return null;
			}
		} else {
			return null;
		}
	}

	public MethodDecl proceedDecl(final AJNodeFactory nf, final AJTypeSystem ts) {
		if (isAroundAdvice) {
			final TypeNode tn = (TypeNode) returnType().copy();
			final List formals = new LinkedList(formals());
			Return ret;

			if (tn.type() == ts.Void()) {
				ret = nf.Return(position());
			} else {
				final Expr dummy = dummyVal(nf, tn.type());
				ret = nf.Return(position(), dummy);
			}

			final Block bl = nf.Block(position()).append(ret);
			final List thrws = new LinkedList();
			final String name = UniqueID.newID("proceed");
			MethodDecl md = nf.MethodDecl(position(), Flags.PUBLIC.set(
					Flags.FINAL).Static(), tn, name, formals, thrws, bl);
			final MethodInstance mi = ts.methodInstance(position(),
					methodInstance().container(), Flags.PUBLIC.set(Flags.FINAL)
							.Static(), tn.type(), name, new ArrayList(
							methodInstance().formalTypes()), new ArrayList());
			((ParsedClassType) methodInstance().container()).addMethod(mi);
			md = md.methodInstance(mi);
			return md;
		} else {
			return null;
		}
	}

	public boolean hasJoinPointStaticPart() {
		return hasJoinPointStaticPart;
	}

	public boolean hasJoinPoint() {
		return hasJoinPoint;
	}

	public boolean hasEnclosingJoinPointStaticPart() {
		return hasEnclosingJoinPointStaticPart;
	}

	public void joinpointFormals(final Local n) {
		hasJoinPoint = hasJoinPoint || (n.name().equals("thisJoinPoint"));
		hasJoinPointStaticPart = hasJoinPointStaticPart
				|| (n.name().equals("thisJoinPointStaticPart"));
		hasEnclosingJoinPointStaticPart = hasEnclosingJoinPointStaticPart
				|| (n.name().equals("thisEnclosingJoinPointStaticPart"));
	}

	protected void addExtraFormals(final AJNodeFactory nf,
			final AJTypeSystem ts, final List formals, final List formalTypes) {
		// Add joinpoint parameters
		if (hasJoinPointStaticPart()) {
			final TypeNode tn = nf.CanonicalTypeNode(position(),
					ts.JoinPointStaticPart()).type(ts.JoinPointStaticPart());
			Formal jpsp = nf.Formal(position(), Flags.FINAL, tn,
					"thisJoinPointStaticPart");

			final LocalInstance li = thisJoinPointStaticPartInstance(ts);
			jpsp = jpsp.localInstance(li);
			formals.add(jpsp);
			formalTypes.add(ts.JoinPointStaticPart());
		}
		if (hasJoinPoint()) {
			final TypeNode tn = nf
					.CanonicalTypeNode(position(), ts.JoinPoint()).type(
							ts.JoinPoint());
			Formal jp = nf.Formal(position(), Flags.FINAL, tn, "thisJoinPoint");

			final LocalInstance li = thisJoinPointInstance(ts);
			jp = jp.localInstance(li);
			formals.add(jp);
			formalTypes.add(ts.JoinPoint());
		}
		if (hasEnclosingJoinPointStaticPart()) {
			final TypeNode tn = nf.CanonicalTypeNode(position(),
					ts.JoinPointStaticPart()).type(ts.JoinPointStaticPart());
			Formal jp = nf.Formal(position(), Flags.FINAL, tn,
					"thisEnclosingJoinPointStaticPart");

			final LocalInstance li = thisEnclosingJoinPointStaticPartInstance(ts);
			jp = jp.localInstance(li);
			formals.add(jp);
			formalTypes.add(ts.JoinPoint());
		}
	}

	public MethodDecl methodDecl(final AJNodeFactory nf, final AJTypeSystem ts) {
		final List newformals = new LinkedList(formals());
		final List newformalTypes = new LinkedList(formals());

		addExtraFormals(nf, ts, newformals, newformalTypes);

		final Flags f = this.flags().set(Flags.FINAL).set(Flags.PUBLIC);
		final MethodDecl md = reconstruct(returnType(), newformals,
				throwTypes(), body()).flags(f);
		final MethodInstance mi = md.methodInstance().formalTypes(
				newformalTypes).flags(f);
		return md.methodInstance(mi);
	}

	private LocalInstance thisJoinPointInstance(final AJTypeSystem ts) {
		if (thisJoinPointInstance == null) {
			thisJoinPointInstance = ts.localInstance(position(), Flags.FINAL,
					ts.JoinPoint(), "thisJoinPoint");
		}
		return thisJoinPointInstance;
	}

	private LocalInstance thisJoinPointStaticPartInstance(final AJTypeSystem ts) {
		if (thisJoinPointStaticPartInstance == null) {
			thisJoinPointStaticPartInstance = ts.localInstance(position(),
					Flags.FINAL, ts.JoinPointStaticPart(),
					"thisJoinPointStaticPart");
		}

		return thisJoinPointStaticPartInstance;
	}

	private LocalInstance thisEnclosingJoinPointStaticPartInstance(
			final AJTypeSystem ts) {
		if (thisEnclosingJoinPointStaticPartInstance == null) {
			thisEnclosingJoinPointStaticPartInstance = ts.localInstance(
					position(), Flags.FINAL, ts.JoinPointStaticPart(),
					"thisEnclosingJoinPointStaticPart");
		}

		return thisEnclosingJoinPointStaticPartInstance;
	}

	@Override
	public Context enterScope(final Context c) {
		final Context nc = super.enterScope(c);
		final AJContext nnc = ((AJContext) nc).pushAdvice(isAroundAdvice);
		return nnc;
	}

	@Override
	public Context enterScope(final Node child, final Context c) {
		if (child == body) {
			final AJContext ajc = (AJContext) child.del().enterScope(c);
			final AJTypeSystem ts = (AJTypeSystem) ajc.typeSystem();
			final LocalInstance jp = thisJoinPointInstance(ts);
			ajc.addVariable(jp);
			final LocalInstance sjp = thisJoinPointStaticPartInstance(ts);
			ajc.addVariable(sjp);
			final LocalInstance ejpsp = thisEnclosingJoinPointStaticPartInstance(ts);
			ajc.addVariable(ejpsp);

			return ajc;
		}

		return super.enterScope(child, c);
	}

	/**
	 * Type check the advice: first the usual method checks, then whether the
	 * "throwing" result is actually throwable
	 */
	@Override
	public Node typeCheck(final TypeChecker tc) throws SemanticException {
		super.typeCheck(tc);

		final AJTypeSystem ts = (AJTypeSystem) tc.typeSystem();
		try {
			ts.checkAdviceBodyFlags(flags());
		} catch (final SemanticException e) {
			throw new SemanticException(e.getMessage(), position());
		}
		return this;
	}

	protected abstract String adviceSignature();

	/**
	 * build the type; the spec is included in the advice instance to give
	 * intelligible error messages - see adviceInstance overrides
	 */
	@Override
	public Node buildTypes(final TypeBuilder tb) throws SemanticException {
		final TypeSystem ts = tb.typeSystem();

		final List l = new ArrayList(formals.size());
		for (int i = 0; i < formals.size(); i++) {
			l.add(ts.unknownType(position()));
		}

		final List m = new ArrayList(throwTypes().size());

		for (int i = 0; i < throwTypes().size(); i++) {
			m.add(ts.unknownType(position()));
		}

		final MethodInstance mi = ((AJTypeSystem) ts).adviceInstance(
				position(), ts.Object(), Flags.NONE,
				ts.unknownType(position()), name, l, m, adviceSignature());

		return methodInstance(mi);
	}

	@Override
	protected MethodInstance makeMethodInstance(final ClassType ct,
			final TypeSystem ts) throws SemanticException {
		final List argTypes = new LinkedList();
		final List excTypes = new LinkedList();

		for (final Iterator i = formals.iterator(); i.hasNext();) {
			final Formal f = (Formal) i.next();
			argTypes.add(f.declType());
		}

		for (final Iterator i = throwTypes().iterator(); i.hasNext();) {
			final TypeNode tn = (TypeNode) i.next();
			excTypes.add(tn.type());
		}

		Flags flags = this.flags;

		if (ct.flags().isInterface()) {
			flags = flags.Public().Abstract();
		}

		return ((AJTypeSystem) ts).adviceInstance(position(), ct, flags,
				returnType.type(), name, argTypes, excTypes, adviceSignature());
	}

	@Override
	public abstract void prettyPrint(CodeWriter w, PrettyPrinter tr);

	public void localMethod(final CodeInstance ci) {
		methodsInAdvice.add(ci);
	}

	public void aspectMethodsEnter(final AspectMethods visitor) {
		visitor.pushProceedFor(this);
		visitor.pushFormals(formals());
		visitor.pushAdvice(this);
	}

	public Node aspectMethodsLeave(final AspectMethods visitor,
			final AJNodeFactory nf, final AJTypeSystem ts) {
		final MethodDecl md = visitor.proceed();

		visitor.popAdvice();
		visitor.popFormals();
		visitor.popProceed();

		if (md != null) {
			visitor.addMethod(md);
		}

		return this.methodDecl(nf, ts);
	}

	public void enterAspectReflectionInspect(final AspectReflectionInspect v,
			final Node parent) {
		v.enterAdvice();
	}

	public void leaveAspectReflectionInspect(final AspectReflectionInspect v) {
		canRewriteThisJoinPoint = v.leaveAdvice();
	}

	public void enterAspectReflectionRewrite(final AspectReflectionRewrite v,
			final AJTypeSystem ts) {
		v
				.enterAdvice(canRewriteThisJoinPoint ? thisJoinPointStaticPartInstance(ts)
						: null);
	}

	public Node leaveAspectReflectionRewrite(final AspectReflectionRewrite v,
			final AJNodeFactory nf) {
		v.leaveAdvice();
		return this;
	}

	@Override
	public Term entry() {
		return Term_c.listEntry(formals(), body() == null ? this : body()
				.entry());
	}

	/**
	 * @inheritDoc
	 */
	public Formal getReturnThrowsFormal() {
		return null;
	}
}
