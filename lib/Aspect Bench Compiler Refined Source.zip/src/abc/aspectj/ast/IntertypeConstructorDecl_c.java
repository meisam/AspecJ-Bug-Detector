/* abc - The AspectBench Compiler
 * Copyright (C) 2004 Aske Simon Christensen
 * Copyright (C) 2004 Oege de Moor
 *
 * This compiler is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This compiler is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this compiler, in the file LESSER-GPL;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

package abc.aspectj.ast;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import polyglot.ast.Block;
import polyglot.ast.Call;
import polyglot.ast.ConstructorCall;
import polyglot.ast.Expr;
import polyglot.ast.Formal;
import polyglot.ast.Local;
import polyglot.ast.MethodDecl;
import polyglot.ast.Node;
import polyglot.ast.Return;
import polyglot.ast.Stmt;
import polyglot.ast.TypeNode;
import polyglot.ext.jl.ast.ConstructorDecl_c;
import polyglot.types.ClassType;
import polyglot.types.ConstructorInstance;
import polyglot.types.Context;
import polyglot.types.Flags;
import polyglot.types.LocalInstance;
import polyglot.types.MethodInstance;
import polyglot.types.ParsedClassType;
import polyglot.types.ReferenceType;
import polyglot.types.SemanticException;
import polyglot.types.Type;
import polyglot.types.TypeSystem;
import polyglot.util.CodeWriter;
import polyglot.util.Position;
import polyglot.util.UniqueID;
import polyglot.visit.AddMemberVisitor;
import polyglot.visit.NodeVisitor;
import polyglot.visit.PrettyPrinter;
import polyglot.visit.TypeChecker;
import abc.aspectj.types.AJContext;
import abc.aspectj.types.AJTypeSystem;
import abc.aspectj.types.AspectType;
import abc.aspectj.types.InterTypeConstructorInstance;
import abc.aspectj.types.InterTypeConstructorInstance_c;
import abc.aspectj.visit.AspectMethods;
import abc.aspectj.visit.ContainsAspectInfo;
import abc.weaving.aspectinfo.AbcFactory;
import abc.weaving.aspectinfo.MethodCategory;

/**
 * 
 * @author Oege de Moor
 * @author Aske Simon Christensen
 * 
 */
public class IntertypeConstructorDecl_c extends ConstructorDecl_c implements
		IntertypeConstructorDecl, ContainsAspectInfo, MakesAspectMethods {
	protected TypeNode host;
	protected LocalInstance thisParamInstance;
	protected String identifier;
	protected Flags originalFlags;

	public IntertypeConstructorDecl_c(final Position pos, final Flags flags,
			final TypeNode host, final String name, final List formals,
			final List throwTypes, final Block body) {
		super(pos, flags, name, formals, throwTypes, body);
		this.host = host;
		this.identifier = UniqueID.newID("id");
		this.originalFlags = flags;
	}

	public TypeNode host() {
		return host;
	}

	protected IntertypeConstructorDecl_c reconstruct(final List formals,
			final List throwTypes, final Block body, final TypeNode host) {
		if (host != this.host) {
			final IntertypeConstructorDecl_c n = (IntertypeConstructorDecl_c) copy();
			n.host = host;
			return (IntertypeConstructorDecl_c) n.reconstruct(formals,
					throwTypes, body);
		}
		return (IntertypeConstructorDecl_c) super.reconstruct(formals,
				throwTypes, body);
	}

	@Override
	public Node visitChildren(final NodeVisitor v) {
		final List formals = visitList(this.formals, v);
		final List throwTypes = visitList(this.throwTypes, v);
		final Block body = (Block) visitChild(this.body, v);
		final TypeNode host = (TypeNode) visitChild(this.host, v);
		return reconstruct(formals, throwTypes, body, host);
	}

	protected InterTypeConstructorInstance_c itConstructorInstance;

	/**
	 * @author Aske Simon Christensen
	 * @author Oege de Moor add itd of methods to host types
	 */
	@Override
	public NodeVisitor addMembersEnter(final AddMemberVisitor am) {
		final Type ht = host.type();
		if (ht instanceof ParsedClassType) {
			final AJTypeSystem ts = (AJTypeSystem) am.typeSystem();
			final ConstructorInstance ci = ts.interTypeConstructorInstance(
					position(), identifier, (ClassType) constructorInstance()
							.container(), (ClassType) ht, constructorInstance()
							.flags(), constructorInstance().formalTypes(),
					constructorInstance().throwTypes());

			// ((ParsedClassType)ht).addConstructor(ci);
			IntertypeConstructorDecl_c.overrideITDconstructor(
					(ParsedClassType) ht, ci);
			itConstructorInstance = (InterTypeConstructorInstance_c) ci;

			/* record instance for "this" parameter */
			final String name = UniqueID.newID("this");
			thisParamInstance = ts.localInstance(position, Flags.NONE, host
					.type(), name);
		}
		return am.bypassChildren(this);
	}

	static boolean hasConstructor(final ClassType ct,
			final ConstructorInstance ci) {
		boolean res = false;
		for (final Iterator cit = ct.constructors().iterator(); !res
				&& cit.hasNext();) {
			final ConstructorInstance cj = (ConstructorInstance) cit.next();
			res = ci.hasFormals(cj.formalTypes());
		}
		return res;
	}

	static List constructors(final ClassType ct, final List formalTypes) {
		final List res = new ArrayList();
		for (final Iterator cit = ct.constructors().iterator(); cit.hasNext();) {
			final ConstructorInstance cj = (ConstructorInstance) cit.next();
			if (cj.hasFormals(formalTypes)) {
				res.add(cj);
			}
		}
		return res;
	}

	public static void overrideITDconstructor(final ClassType pht,
			final ConstructorInstance mi) {
		// System.out.println("attempting to add constructor "+mi+" to
		// "+pht);
		final InterTypeConstructorInstance_c itmic = (InterTypeConstructorInstance_c) mi;
		final InterTypeConstructorInstance_c toinsert = (InterTypeConstructorInstance_c) mi
				.container(pht).flags(itmic.origFlags());
		// System.out.println("instance to insert:"+ " origin=" +
		// toinsert.origin() +
		// " container=" + toinsert.container() +
		// " flags=" + toinsert.flags()) ;
		boolean added = false;
		if (IntertypeConstructorDecl_c.hasConstructor(pht, mi)) {
			// System.out.println("it has the constructor already");
			final List mis = IntertypeConstructorDecl_c.constructors(pht, mi
					.formalTypes());
			for (final Iterator misIt = mis.iterator(); misIt.hasNext();) {
				// System.out.println("try next instance");
				final ConstructorInstance minst = (ConstructorInstance) misIt
						.next();
				if (IntertypeConstructorDecl_c.zaps(mi, minst) && !added) {
					pht.methods().remove(minst);
					pht.methods().add(toinsert);
					// System.out.println("replaced");
					added = true;
				} else if (IntertypeConstructorDecl_c.zaps(minst, toinsert)) {
					// skip
					// System.out.println("skipped");
				} else if (!added) {
					pht.constructors().add(toinsert);
					added = true;
					// System.out.println("added");
				}
			}
		} else {
			pht.constructors().add(toinsert);
			added = true;
			// System.out.println("added");
		}
		// System.out.println("exit overrideITDconstructor");
		if (added) {
			abc.main.Main.v().getAbcExtension().getGlobalAspectInfo()
					.registerWeave(AbcFactory.AbcClass(pht));
		}
	}

	static boolean fromInterface(final ConstructorInstance mi) {
		return mi instanceof InterTypeConstructorInstance
				&& (((InterTypeConstructorInstance) mi).interfaceTarget() != null);
	}

	// replace this by a call to the appropriate structure!
	static boolean precedes(final ClassType ct1, final ClassType ct2) {
		return ct1.descendsFrom(ct2);
	}

	static boolean zaps(final ConstructorInstance mi1,
			final ConstructorInstance mi2) {
		if (!(mi1 instanceof InterTypeConstructorInstance && mi2 instanceof InterTypeConstructorInstance)) {
			return false;
		}
		final InterTypeConstructorInstance itmi1 = (InterTypeConstructorInstance) mi1;
		final InterTypeConstructorInstance itmi2 = (InterTypeConstructorInstance) mi2;
		return IntertypeConstructorDecl_c.precedes(itmi1.origin(), itmi2
				.origin());
	}

	/**
	 * @author Oege de Moor change private intertype constructor decl into
	 *         public, mangling by giving it an extra parameter
	 * 
	 */
	public IntertypeConstructorDecl accessChange(final AJNodeFactory nf,
			final AJTypeSystem ts) {
		if (flags().isPrivate() || flags().isPackage()) {
			final ParsedClassType ht = (ParsedClassType) host.type();
			ht.fields().remove(itConstructorInstance); // remove old instance
			// from host type
			final ConstructorInstance mmi = itConstructorInstance.mangled(); // retrieve
			// the
			// mangled
			// instance
			ht.addConstructor(mmi); // add new instance to host type
			final List newFormals = new LinkedList(formals());
			newFormals.add(itConstructorInstance.mangledFormal(nf, ts));
			return (IntertypeConstructorDecl) constructorInstance(mmi).flags(
					mmi.flags()).formals(newFormals);
		}
		return this;
	}

	/**
	 * create a reference to the "this" parameter
	 * 
	 * @author Oege de Moor
	 */
	public Expr thisReference(final AJNodeFactory nf, final AJTypeSystem ts) {
		Local x = nf.Local(position, thisParamInstance.name());
		x = (Local) x.localInstance(thisParamInstance).type(
				thisParamInstance.type());
		return x;
	}

	/**
	 * given an intertype constructor declaration of the form A.new(formal1,
	 * ...,formaln) { ccall(E1,E2,...,Ek); // optional call to super or this
	 * init; } we want to transform it into the following shape A.new(formal1,
	 * ..., formaln) { receiver.ccall(e1(formal1,...,formaln), ...,
	 * ek(formal1,...,formaln)); // no longer optional
	 * body(this,formal1,...,formaln); } where e1,...,ek and body are newly
	 * generated methods in the originating aspect.
	 * 
	 * We detect the special case that one of the original Ei is just a
	 * reference to a formal; in that case no method is lifted out.
	 * 
	 * The generated methods are appended onto the list that is the last
	 * parameter.
	 * 
	 * Because we aim not to override the Jimplifier behaviour, it is not
	 * possible to Jimplify the generated constructor: references to this and
	 * super would refer to the originating aspect, not the target. For that
	 * reason we record the following information, which is later stored in the
	 * AspectInfo structure:
	 *  - formal types: List<Type> aiFormalTypes - qualifier of the ccall
	 * ReferenceType aiQualifier // may be null - kind of the ccall
	 * ConstructorCall.Kind aiKind - list of ei method instances or parameter
	 * positions List<Integer | MethodInstance> aiEis - body method instance
	 * MethodInstance aiBody
	 * 
	 * Using this information, the weaver (more precisely, the
	 * IntertypeAdjuster) will generate code for the constructor in the target
	 * class.
	 * 
	 * @author Oege de Moor
	 */
	public IntertypeConstructorDecl liftMethods(final AJNodeFactory nf,
			final AJTypeSystem ts, final List methodDecls) {
		ConstructorCall ccall = findCCall();
		Block b = nf.Block(position);
		if (ccall != null) {
			final List Es = ccall.arguments();
			final List es = new LinkedList();
			for (final Iterator Eis = Es.iterator(); Eis.hasNext();) {
				final Expr Ei = (Expr) Eis.next();
				if (Ei instanceof Local) {
					es.add(Ei);
				} else {
					es.add(genArgMethod(nf, ts, Ei, methodDecls));
				}
			}
			ccall = (ConstructorCall) ccall.arguments(es); // replace the Ei by
			// ei
			b = b.append(ccall);
		} else { // create a call to super()
			ccall = nf.ConstructorCall(position(), ConstructorCall.SUPER,
					new LinkedList());
			final ConstructorInstance cci = ts.constructorInstance(position(),
					host().type().toClass(), Flags.PUBLIC, new LinkedList(),
					throwTypes());
			ccall = ccall.constructorInstance(cci);
		}
		setAspectInfoCCall(ccall);
		final List init = withoutCCall();
		final Call bodyCall = genBodyMethod(nf, ts, formals, init, methodDecls);
		setAspectInfoBody(bodyCall);
		b = b.append(nf.Eval(position, bodyCall));
		return (IntertypeConstructorDecl) body(b);
	}

	/**
	 * find the call to "super(..)" or "this(..)", if one exists. It must be the
	 * first statement of the body.
	 * 
	 * @author Oege de Moor
	 */
	private ConstructorCall findCCall() {
		final Block b = body();
		final Stmt stmt = (Stmt) b.statements().get(0);
		if (stmt instanceof ConstructorCall) {
			return (ConstructorCall) stmt;
		} else {
			return null;
		}
	}

	/**
	 * the statements in the constructor body, without the initial constructor
	 * call (if one exists)
	 * 
	 * @author Oege de Moor
	 */
	private List withoutCCall() {
		final List result = new LinkedList(body().statements());
		if (result.get(0) instanceof ConstructorCall) {
			result.remove(0);
		}
		return result;
	}

	/**
	 * generate a static method for the given expression, in the originating
	 * aspect, and return a call to that static method. The declaration of the
	 * generated method is appended onto the last parameter.
	 * 
	 * @author Oege de Moor
	 */
	private Expr genArgMethod(final AJNodeFactory nf, final AJTypeSystem ts,
			final Expr Ei, final List methodDecls) {
		final String name = UniqueID.newID("arg$" + name());

		// build the formals: just a copy of the existing formals
		final List newFormals = new LinkedList(formals);

		// build the body
		final Return ret = nf.Return(Ei.position(), Ei);
		final Block b = nf.Block(position, ret);

		// build the methodinstance
		final List argTypes = new LinkedList(constructorInstance()
				.formalTypes());
		final List excTypes = Ei.throwTypes(ts);
		final MethodInstance mi = ts.methodInstance(position,
				itConstructorInstance.origin(), flags, Ei.type(), name,
				argTypes, excTypes);

		// build the declaration
		final TypeNode rettype = nf
				.CanonicalTypeNode(position, mi.returnType());
		MethodDecl md = nf.MethodDecl(position, Flags.STATIC, rettype, name,
				newFormals, excTypes, b);
		md = md.methodInstance(mi);

		// record the method declaration
		methodDecls.add(md);

		// construct the call
		final List actuals = new LinkedList();
		for (final Iterator nfs = formals().iterator(); nfs.hasNext();) {
			final Formal f = (Formal) nfs.next();
			final Type t = f.type().type();
			Local a = nf.Local(f.position(), f.name()).localInstance(
					f.localInstance());
			a = (Local) a.type(t);
			actuals.add(a);
		}
		final TypeNode targetTypeNode = nf.CanonicalTypeNode(position,
				constructorInstance().container());
		Call c = nf.Call(position(), targetTypeNode, name, actuals);
		c = c.methodInstance(mi);

		return c;
	}

	private void buildATypes(final AJNodeFactory nf, final List newFormals,
			final List actuals, final List argTypes) {
		final Iterator nfs = newFormals.iterator();
		Formal f = (Formal) nfs.next();
		Type t = f.type().type();

		final TypeNode tn = nf.CanonicalTypeNode(position, t);
		Expr a = nf.This(position, tn);
		a = a.type(t);

		actuals.add(a);
		argTypes.add(t);
		while (nfs.hasNext()) {
			f = (Formal) nfs.next();
			t = f.type().type();
			a = nf.Local(f.position(), f.name()).localInstance(
					f.localInstance());
			a = a.type(t);
			actuals.add(a);
			argTypes.add(t);
		}
	}

	private List buildFormals(final AJNodeFactory nf) {
		List newFormals;
		newFormals = new LinkedList(formals);

		final LocalInstance thisInstance = thisParamInstance; // fishy? same
		// instance for
		// multiple
		// methods...
		TypeNode tn = nf.CanonicalTypeNode(position, host.type());
		tn = tn.type(host.type());
		Formal thisp = nf
				.Formal(position, Flags.FINAL, tn, thisInstance.name());
		thisp = thisp.localInstance(thisInstance);
		newFormals.add(0, thisp);

		return newFormals;
	}

	/**
	 * generate a static method for the body, in the originating aspect.
	 */
	private Call genBodyMethod(final AJNodeFactory nf, final AJTypeSystem ts,
			final List formals, final List stmts, final List methodDecls) {
		final String name = UniqueID.newID("new$" + name());
		final List newFormals = buildFormals(nf);

		// build the body
		final Block b = nf.Block(position, stmts);

		// build the methodinstance
		final List actuals = new LinkedList();
		final List argTypes = new LinkedList();
		buildATypes(nf, newFormals, actuals, argTypes);
		final List excTypes = throwTypes(ts);
		final MethodInstance mi = ts.methodInstance(position,
				itConstructorInstance.origin(), flags, ts.Void(), name,
				argTypes, excTypes);

		// build the declaration
		final TypeNode rettype = nf
				.CanonicalTypeNode(position, mi.returnType());
		MethodDecl md = nf.MethodDecl(position, Flags.STATIC, rettype, name,
				newFormals, excTypes, b);
		md = md.methodInstance(mi);

		// record the method declaration
		methodDecls.add(md);

		// construct the call
		final TypeNode targetTypeNode = nf.CanonicalTypeNode(position,
				constructorInstance().container());
		Call c = nf.Call(position(), targetTypeNode, name, actuals);
		c = c.methodInstance(mi);

		return c;
	}

	/**
	 * Duplicate most of the things for ConstructorDecl here to avoid comparing
	 * the name against the contaning class.
	 */
	@Override
	public Node typeCheck(final TypeChecker tc) throws SemanticException {
		final Context c = tc.context();
		final TypeSystem ts = tc.typeSystem();

		// hostClass in lieu of currentClass
		final ClassType ct = ((AJContext) c).hostClass();

		if (ct.flags().isInterface()) {
			throw new SemanticException(
					"Cannot declare an intertype constructor on an interface.",
					position());
		}

		if (flags().isProtected()) {
			throw new SemanticException(
					"Cannot declare a protected intertype constructor");
		}

		if (ct.isAnonymous()) {
			throw new SemanticException(
					"Cannot declare an intertype constructor on an anonymous class.",
					position());
		}

		/*
		 * String ctName = ct.name();
		 * 
		 * if (! ctName.equals(name)) { throw new SemanticException("Constructor
		 * name \"" + name + "\" does not match name of containing class \"" +
		 * ctName + "\".", position()); }
		 */

		try {
			ts.checkConstructorFlags(flags());
		} catch (final SemanticException e) {
			throw new SemanticException(e.getMessage(), position());
		}

		if (body == null && !flags().isNative()) {
			throw new SemanticException("Missing constructor body.", position());
		}

		if (body != null && flags().isNative()) {
			throw new SemanticException(
					"A native constructor cannot have a body.", position());
		}

		for (final Iterator i = throwTypes().iterator(); i.hasNext();) {
			final TypeNode tn = (TypeNode) i.next();
			final Type t = tn.type();
			if (!t.isThrowable()) {
				throw new SemanticException(
						"Type \"" + t + "\" is not a subclass of \""
								+ ts.Throwable() + "\".", tn.position());
			}
		}

		if ((ct instanceof AspectType)
				&& constructorInstance().formalTypes().size() > 0) {
			throw new SemanticException(
					"Aspects can only have nullary constructors", position());
		}

		return this;
	}

	@Override
	public void prettyPrint(final CodeWriter w, final PrettyPrinter tr) {
		w.begin(0);
		w.write(flags.translate());
		print(host, w, tr);
		w.write(".new(");

		w.begin(0);

		for (final Iterator i = formals.iterator(); i.hasNext();) {
			final Formal f = (Formal) i.next();
			print(f, w, tr);

			if (i.hasNext()) {
				w.write(",");
				w.allowBreak(0, " ");
			}
		}

		w.end();

		w.write(")");

		w.begin(0);

		if (!throwTypes().isEmpty()) {
			w.allowBreak(6);
			w.write("throws ");

			for (final Iterator i = throwTypes().iterator(); i.hasNext();) {
				final TypeNode tn = (TypeNode) i.next();
				print(tn, w, tr);

				if (i.hasNext()) {
					w.write(",");
					w.allowBreak(4, " ");
				}
			}
		}

		w.end();

		if (body != null) {
			printSubStmt(body, w, tr);
		} else {
			w.write(";");
		}

		w.end();

	}

	/**
	 * @author Oege de Moor record the host type in the environment, for
	 *         checking of this and super. also add fields and methods of the
	 *         host that are visible from the aspect.
	 */

	@Override
	public Context enterScope(final Context c) {
		final AJContext nc = (AJContext) super.enterScope(c);
		final TypeSystem ts = nc.typeSystem();
		final AJContext ncc = (AJContext) nc.pushHost(ts.staticTarget(
				host.type()).toClass(), flags.isStatic());
		return ncc.addITMembers(host.type().toClass());
	}

	private List /* <Type> */aiFormalTypes;
	private ReferenceType aiQualifier; // may be null
	private ConstructorCall.Kind aiKind;
	private List /* <Integer | MethodInstance> */aiEis;
	private MethodInstance aiBody;

	private void setAspectInfoCCall(final ConstructorCall cc) {
		aiQualifier = (cc.qualifier() != null ? cc.qualifier().type()
				.toReference() : null);
		aiKind = cc.kind();
		aiEis = new ArrayList();
		aiFormalTypes = new ArrayList(constructorInstance().formalTypes());
		for (final Iterator fs = cc.arguments().iterator(); fs.hasNext();) {
			final Expr e = (Expr) fs.next();
			if (e instanceof Local) {
				aiEis.add(new Integer(indexof((Local) e)));
			}
			if (e instanceof Call) {
				aiEis.add(((Call) e).methodInstance());
			}
		}
	}

	private int indexof(final Local e) {
		int index = 0;
		for (final Iterator fs = formals.iterator(); fs.hasNext();) {
			final Formal f = (Formal) fs.next();
			if (f.localInstance().equals(e.localInstance())) {
				return index;
			}
			index++;
		}
		return 0; // should not happen
	}

	private void setAspectInfoBody(final Call c) {
		aiBody = c.methodInstance();
	}

	public void update(final abc.weaving.aspectinfo.GlobalAspectInfo gai,
			final abc.weaving.aspectinfo.Aspect current_aspect) {
		// System.out.println("ICD host: "+host.toString());
		final abc.weaving.aspectinfo.AbcClass target = AbcFactory
				.AbcClass((ClassType) host.type());
		final int mod = AbcFactory.modifiers(flags());
		final int origmod = AbcFactory.modifiers(originalFlags);
		final List formalTypes = new ArrayList();
		final Iterator fi = aiFormalTypes.iterator();
		int index = 0;
		while (fi.hasNext()) {
			final Type f = (Type) fi.next();
			formalTypes.add(AbcFactory.AbcType(f));
			index++;
		}
		final List exc = new ArrayList();
		final Iterator ti = throwTypes().iterator();
		while (ti.hasNext()) {
			final TypeNode t = (TypeNode) ti.next();
			exc.add(t.type().toString());
		}
		final abc.weaving.aspectinfo.AbcClass qualifier = (aiQualifier == null ? null
				: AbcFactory.AbcClass((ClassType) aiQualifier));
		final int kind = (aiKind == ConstructorCall.SUPER ? abc.weaving.aspectinfo.IntertypeConstructorDecl.SUPER
				: abc.weaving.aspectinfo.IntertypeConstructorDecl.THIS);
		final List arguments = new ArrayList();
		for (final Iterator args = aiEis.iterator(); args.hasNext();) {
			final Object arg = args.next();
			if (arg instanceof Integer) {
				arguments.add(arg);
			}
			if (arg instanceof MethodInstance) {
				final MethodInstance mi = (MethodInstance) arg;
				final abc.weaving.aspectinfo.MethodSig sig = AbcFactory
						.MethodSig(mi);
				arguments.add(sig);
				MethodCategory.register(sig,
						MethodCategory.INTERTYPE_CONSTRUCTOR_SPECIAL_ARG);
			}
		}
		final abc.weaving.aspectinfo.MethodSig body = AbcFactory
				.MethodSig(aiBody);
		final abc.weaving.aspectinfo.IntertypeConstructorDecl icd = new abc.weaving.aspectinfo.IntertypeConstructorDecl(
				target, current_aspect, mod, origmod, originalFlags.isPrivate()
						|| originalFlags.isPackage(), formalTypes, exc,
				qualifier, kind, arguments, body, position());
		gai.addIntertypeConstructorDecl(icd);

		MethodCategory
				.register(body, MethodCategory.INTERTYPE_CONSTRUCTOR_BODY);
		// FIXME: First argument is this, right?
		MethodCategory.registerRealNameAndClass(body, AbcFactory
				.modifiers(originalFlags), "<init>", current_aspect
				.getInstanceClass(), 1, 0);
	}

	public void aspectMethodsEnter(final AspectMethods visitor) {
		visitor.pushIntertypeDecl(this);
	}

	public Node aspectMethodsLeave(final AspectMethods visitor,
			final AJNodeFactory nf, final AJTypeSystem ts) {
		visitor.popIntertypeDecl();
		final IntertypeConstructorDecl_c itcd = (IntertypeConstructorDecl_c) accessChange(
				nf, ts);
		return itcd.liftMethods(nf, ts, visitor.methods());
	}
}
