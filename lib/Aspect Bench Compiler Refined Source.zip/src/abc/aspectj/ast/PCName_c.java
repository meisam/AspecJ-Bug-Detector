/* abc - The AspectBench Compiler
 * Copyright (C) 2004 Oege de Moor
 * Copyright (C) 2004 Aske Simon Christensen
 *
 * This compiler is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This compiler is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this compiler, in the file LESSER-GPL;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

package abc.aspectj.ast;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import polyglot.ast.Expr;
import polyglot.ast.Local;
import polyglot.ast.Node;
import polyglot.ast.Precedence;
import polyglot.ast.Receiver;
import polyglot.ast.TypeNode;
import polyglot.ast.Typed;
import polyglot.types.ClassType;
import polyglot.types.Flags;
import polyglot.types.MethodInstance;
import polyglot.types.PrimitiveType;
import polyglot.types.ProcedureInstance;
import polyglot.types.ReferenceType;
import polyglot.types.SemanticException;
import polyglot.types.Type;
import polyglot.types.TypeSystem;
import polyglot.util.CodeWriter;
import polyglot.util.CollectionUtil;
import polyglot.util.Position;
import polyglot.visit.NodeVisitor;
import polyglot.visit.PrettyPrinter;
import polyglot.visit.TypeBuilder;
import polyglot.visit.TypeChecker;
import abc.aspectj.types.AJContext;
import abc.aspectj.types.AJTypeSystem;
import abc.aspectj.types.AspectType;
import abc.aspectj.types.PointcutInstance;
import abc.aspectj.types.PointcutInstance_c;
import abc.aspectj.visit.AspectInfoHarvester;
import abc.aspectj.visit.DependsCheck;
import abc.aspectj.visit.DependsChecker;
import abc.main.Debug;

/**
 * A reference to a named pointcut.
 * 
 * @author Oege de Moor
 * @author Aske Simon Christensen
 * 
 */
public class PCName_c extends Pointcut_c implements PCName, DependsCheck {
	protected Receiver target;
	protected String name;
	protected List args;
	protected MethodInstance mi;

	public PCName_c(final Position pos, final Receiver target,
			final String name, final List args) {
		super(pos);
		this.target = target;
		this.name = name;
		this.args = copyList(args); // here it is a list of TypeNode, Local,
		// ArgStar og ArgDotDot
	}

	private List copyList(final List xs) {
		return new LinkedList(xs);
	}

	@Override
	public Precedence precedence() {
		return Precedence.LITERAL;
	}

	public Set pcRefs() {
		final Set a = new HashSet();
		a.add(new PointcutInstance_c.PCRef(target != null,
				(PointcutInstance_c) mi));
		return a;
	}

	public boolean isDynamic() {
		return false;
	}

	/** Get the target type of the pointcut reference. */
	public Receiver target() {
		return this.target;
	}

	/** Set the target object of the pointcut reference. */
	public PCName target(final Receiver target) {
		final PCName_c n = (PCName_c) copy();
		n.target = target;
		return n;
	}

	/** Get the name of the pointcut reference. */
	public String name() {
		return this.name;
	}

	/** Set the name of the pointcut reference. */
	public PCName name(final String name) {
		final PCName_c n = (PCName_c) copy();
		n.name = name;
		return n;
	}

	public ProcedureInstance procedureInstance() {
		return pointcutInstance();
	}

	/** Get the pointcut instance of the reference. */
	public MethodInstance pointcutInstance() {
		return this.mi;
	}

	/** Set the pointcut instance of the reference. */
	public PCName pointcutInstance(final MethodInstance mi) {
		final PCName_c n = (PCName_c) copy();
		n.mi = mi;
		return n;
	}

	/** Get the actual arguments of the reference. */
	public List arguments() {
		return this.args;
	}

	/** Set the actual arguments of the reference. */
	public PCName arguments(final List arguments) {
		final PCName_c n = (PCName_c) copy();
		n.args = copyList(arguments);
		return n;
	}

	/** Reconstruct the pointcut call. */
	protected PCName_c reconstruct(final Receiver target, final List args) {
		if (target != this.target || !CollectionUtil.equals(args, this.args)) {
			final PCName_c n = (PCName_c) copy();
			n.target = (target == null ? null : (Receiver) target.copy());
			n.args = copyList(args); // may become a list of TypeNode, Local,
			// ArgStar or ArgDotDot
			return n;
		}
		return this;
	}

	/** Visit the children of the pointcut call. */
	@Override
	public Node visitChildren(final NodeVisitor v) {
		final Receiver target = (Receiver) visitChild(this.target, v);
		final List args = visitList(this.args, v);
		return reconstruct(target, args);
	}

	/** build the types */
	@Override
	public Node buildTypes(final TypeBuilder tb) throws SemanticException {
		final TypeSystem ts = tb.typeSystem();

		final List l = new ArrayList(args.size());
		final Iterator a = args.iterator(); // to pinpoint type errors to
		// the right place
		for (int i = 0; i < args.size(); i++) {
			final Node tn = (Node) a.next();
			l.add(ts.unknownType(tn.position()));
		}

		final MethodInstance mi = ((AJTypeSystem) ts).pointcutInstance(
				position(), ts.Object(), Flags.NONE,
				ts.unknownType(position()), name, l, Collections.EMPTY_LIST);
		return this.pointcutInstance(mi);
	}

	/** type check the pointcut reference */
	@Override
	public Node typeCheck(final TypeChecker tc) throws SemanticException {
		final AJTypeSystem ts = (AJTypeSystem) tc.typeSystem();
		final AJContext c = (AJContext) tc.context();

		ReferenceType targetType = null;

		if (target instanceof TypeNode) {
			final TypeNode tn = (TypeNode) target;
			final Type t = tn.type();

			if (t.isReference()) {
				targetType = t.toReference();
			} else {
				throw new SemanticException("Cannot reference pointcut  \""
						+ name + "\" in non-reference type " + t + ".", tn
						.position());
			}
		} else if (target instanceof Expr) {
			throw new SemanticException("Cannot reference pointcut \"" + name
					+ "\" in dynamic object \"" + target + "\".", target
					.position());
		} else if (target != null) {
			throw new SemanticException("Host of pointcut reference must be a "
					+ "reference type.", target.position());
		}

		// find nearest enclosing pointcut declaration of the right name, and
		// compute its type
		MethodInstance mi;
		ClassType ct;
		if (target == null) {
			ct = c.findPointcutScope(name);
		} else {
			ct = target.type().toClass(); // will return non-null because of above
			// checks
		}

		mi = ts.findPointCutNamed(ct, name);

		// get the formal types
		final List formalTypes = mi.formalTypes();

		// check the arguments, NullType matches anything
		if (args.size() != formalTypes.size()) {
			throw new SemanticException(
					"Wrong number of arguments to pointcut," + " expected "
							+ formalTypes.size() + ".", position());
		}

		final Iterator an = args.iterator(); // just to report the error in the
		// right place
		for (final Iterator b = formalTypes.iterator(); b.hasNext();) {
			final Node arg = (Node) an.next();
			final Type formaltype = (Type) b.next();
			if (arg instanceof Typed) {
				final Type argtype = ((Typed) arg).type();
				if (!(ts.isImplicitCastValid(formaltype, argtype) || (formaltype instanceof PrimitiveType && argtype
						.equals(ts.Object())))) {
					throw new SemanticException("Wrong argument type "
							+ argtype + " expected " + formaltype + ".", arg
							.position());
				}
			}
		}
		return this.pointcutInstance(mi);
	}

	public Node checkDepends(final DependsChecker dc) throws SemanticException {
		final AJContext c = (AJContext) dc.context();
		final PointcutInstance pci = (PointcutInstance) pointcutInstance();
		if (pci.checkAbstract(c) && !(c.currentClass().flags().isAbstract())
				&& (c.currentClass() instanceof AspectType)) {
			throw new SemanticException(
					"Cannot refer to an abstract pointcut inside a concrete aspect.",
					position());
		}
		if (pci.checkDynamic(c) && c.inDeclare()
				&& !Debug.v().allowDynamicTests) {
			throw new SemanticException(
					"Pointcut \""
							+ name()
							+ "\" requires a dynamic test and cannot be used inside a \"declare\" statement.",
					position());
		}
		return this;
	}

	@Override
	public void prettyPrint(final CodeWriter w, final PrettyPrinter tr) {
		w.write(name + "(");
		for (final Iterator i = args.iterator(); i.hasNext();) {
			final Node id = (Node) i.next();
			print(id, w, tr);

			if (i.hasNext()) {
				w.write(",");
				w.allowBreak(4, " ");
			}
		}
		w.write(")");
	}

	@Override
	public Collection mayBind() throws SemanticException {
		final Collection result = new HashSet();
		for (final Iterator i = args.iterator(); i.hasNext();) {
			final Node pat = (Node) i.next();
			if (pat instanceof Local) {
				final String l = ((Local) pat).name();
				if (result.contains(l)) {
					throw new SemanticException("repeated binding of \"" + l
							+ "\"", pat.position());
				} else if (l == Pointcut_c.initialised) {
					throw new SemanticException(
							"cannot explicitly bind local \"" + l + "\"", pat
									.position());
				} else {
					result.add(l);
				}
			}
		}
		return result;
	}

	@Override
	public Collection mustBind() {
		final Collection result = new HashSet();
		for (final Iterator i = args.iterator(); i.hasNext();) {
			final Node pat = (Node) i.next();
			if (pat instanceof Local) {
				result.add(((Local) pat).name());
			}
		}
		return result;
	}

	public abc.weaving.aspectinfo.Pointcut makeAIPointcut() {
		final Object pcd_key = mi; // Find the pointcut using the method instance
		// as key
		final Map decl_map = AspectInfoHarvester.pointcutDeclarationMap();
		final List args = AspectInfoHarvester.convertArgPatterns(this.args);
		return new abc.weaving.aspectinfo.PointcutRef(pcd_key, decl_map, args,
				position(), target != null);
	}
}
