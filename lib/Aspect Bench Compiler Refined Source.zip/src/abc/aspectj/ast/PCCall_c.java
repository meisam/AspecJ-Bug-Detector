/* abc - The AspectBench Compiler
 * Copyright (C) 2004 Oege de Moor
 *
 * This compiler is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This compiler is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this compiler, in the file LESSER-GPL;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

package abc.aspectj.ast;

import java.util.HashSet;
import java.util.Set;

import polyglot.ast.Node;
import polyglot.ast.Precedence;
import polyglot.util.CodeWriter;
import polyglot.util.Position;
import polyglot.visit.NodeVisitor;
import polyglot.visit.PrettyPrinter;

/**
 * 
 * @author Oege de Moor
 * 
 */
public class PCCall_c extends Pointcut_c implements PCCall {
	protected MethodConstructorPattern pat;

	public PCCall_c(final Position pos, final MethodConstructorPattern pat) {
		super(pos);
		this.pat = pat;
	}

	@Override
	public Precedence precedence() {
		return Precedence.LITERAL;
	}

	public Set pcRefs() {
		return new HashSet();
	}

	public boolean isDynamic() {
		return false;
	}

	protected PCCall_c reconstruct(final MethodConstructorPattern pat) {
		if (pat != this.pat) {
			final PCCall_c n = (PCCall_c) copy();
			n.pat = pat;
			return n;
		}
		return this;
	}

	@Override
	public Node visitChildren(final NodeVisitor v) {
		final MethodConstructorPattern pat = (MethodConstructorPattern) visitChild(
				this.pat, v);
		return reconstruct(pat);
	}

	@Override
	public void prettyPrint(final CodeWriter w, final PrettyPrinter tr) {
		w.write("call(");
		print(pat, w, tr);
		w.write(")");
	}

	public abc.weaving.aspectinfo.Pointcut makeAIPointcut() {
		if (pat instanceof MethodPattern) {
			return new abc.weaving.aspectinfo.MethodCall(((MethodPattern) pat)
					.makeAIMethodPattern(), position());
		} else if (pat instanceof ConstructorPattern) {
			return new abc.weaving.aspectinfo.ConstructorCall(
					((ConstructorPattern) pat).makeAIConstructorPattern(),
					position());
		} else {
			throw new RuntimeException(
					"Unexpected MethodConstructorPattern type in call pointcut: "
							+ pat);
		}
	}
}
