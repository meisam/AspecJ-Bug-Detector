/* abc - The AspectBench Compiler
 * Copyright (C) 2004 Oege de Moor
 * Copyright (C) 2004 Aske Simon Christensen
 *
 * This compiler is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This compiler is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this compiler, in the file LESSER-GPL;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

package abc.aspectj.ast;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Set;

import polyglot.ast.Node;
import polyglot.ast.Precedence;
import polyglot.util.CodeWriter;
import polyglot.util.Position;
import polyglot.visit.NodeVisitor;
import polyglot.visit.PrettyPrinter;
import abc.aspectj.visit.ContainsNamePattern;
import abc.aspectj.visit.PCNode;
import abc.aspectj.visit.PatternMatcher;

/**
 * a (class+) ClassnamePatternExpr that matches all subclasses.
 * 
 * @author Oege de Moor
 * @author Aske Simon Christensen
 */
public class CPESubName_c extends ClassnamePatternExpr_c implements CPESubName,
		ContainsNamePattern {
	protected NamePattern pat;

	public CPESubName_c(final Position pos, final NamePattern pat) {
		super(pos);
		this.pat = pat;
	}

	protected CPESubName_c reconstruct(final NamePattern pat) {
		if (pat != this.pat) {
			final CPESubName_c n = (CPESubName_c) copy();
			n.pat = pat;
			return n;
		}
		return this;
	}

	@Override
	public Node visitChildren(final NodeVisitor v) {
		final NamePattern pat = (NamePattern) visitChild(this.pat, v);
		return reconstruct(pat);
	}

	@Override
	public Precedence precedence() {
		return Precedence.LITERAL;
	}

	@Override
	public void prettyPrint(final CodeWriter w, final PrettyPrinter tr) {
		print(pat, w, tr);
		w.write("+");
	}

	@Override
	public String toString() {
		return pat + "+";
	}

	public NamePattern getNamePattern() {
		return pat;
	}

	public boolean matches(final PatternMatcher matcher, final PCNode cl) {
		if (matcher.matchesName(pat, cl)) {
			return true;
		}
		final Set tried = new HashSet();
		tried.add(cl);
		final LinkedList worklist = new LinkedList(tried);
		while (!worklist.isEmpty()) {
			final PCNode n = (PCNode) worklist.removeFirst();
			final Iterator pi = n.getParents().iterator();
			while (pi.hasNext()) {
				final PCNode parent = (PCNode) pi.next();
				if (!tried.contains(parent)) {
					if (matcher.matchesName(pat, parent)) {
						return true;
					}
					tried.add(parent);
					worklist.addLast(parent);
				}
			}
		}
		return false;
	}

	public boolean equivalent(final ClassnamePatternExpr otherexp) {
		if (otherexp.getClass() == this.getClass()) {
			return (pat.equivalent(((CPESubName) otherexp).getNamePattern()));
		} else {
			return false;
		}
	}
}
