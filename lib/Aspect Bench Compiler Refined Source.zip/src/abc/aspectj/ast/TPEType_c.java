/* abc - The AspectBench Compiler
 * Copyright (C) 2004 Oege de Moor
 * Copyright (C) 2004 Aske Simon Christensen
 *
 * This compiler is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This compiler is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this compiler, in the file LESSER-GPL;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

package abc.aspectj.ast;

import polyglot.ast.Node;
import polyglot.ast.Precedence;
import polyglot.ast.TypeNode;
import polyglot.types.SemanticException;
import polyglot.util.CodeWriter;
import polyglot.util.Position;
import polyglot.visit.NodeVisitor;
import polyglot.visit.PrettyPrinter;
import abc.aspectj.visit.PCNode;
import abc.aspectj.visit.PatternMatcher;

/**
 * 
 * @author Oege de Moor
 * @author Aske Simon Christensen
 * 
 */
public class TPEType_c extends TypePatternExpr_c implements TPEType {
	protected TypeNode type;

	public TPEType_c(final Position pos, final TypeNode type) {
		super(pos);
		this.type = type;
	}

	public TypeNode type() {
		return type;
	}

	@Override
	public Precedence precedence() {
		return Precedence.UNARY;
	}

	/** Reconstruct the type pattern */
	protected TPEType_c reconstruct(final TypeNode type) {
		if (this.type != type) {
			final TPEType_c n = (TPEType_c) copy();
			n.type = type;
			return n;
		}
		return this;
	}

	/** Visit the children of the type pattern. */
	@Override
	public Node visitChildren(final NodeVisitor v) {
		final TypeNode type = (TypeNode) visitChild(this.type, v);
		return reconstruct(type);
	}

	@Override
	public void prettyPrint(final CodeWriter w, final PrettyPrinter tr) {
		print(type, w, tr);
	}

	@Override
	public String toString() {
		return type.toString();
	}

	public boolean matchesClass(final PatternMatcher matcher, final PCNode cl) {
		return false;
	}

	public boolean matchesClassArray(final PatternMatcher matcher,
			final PCNode cl, final int dim) {
		return false;
	}

	public boolean matchesPrimitive(final PatternMatcher matcher,
			final String prim) {
		return type.toString().equals(prim);
	}

	public boolean matchesPrimitiveArray(final PatternMatcher matcher,
			final String prim, final int dim) {
		return false;
	}

	public ClassnamePatternExpr transformToClassnamePattern(
			final AJNodeFactory nf) throws SemanticException {
		throw new SemanticException("Primitive type in classname pattern");
	}

	public boolean equivalent(final TypePatternExpr t) {
		if (t.getClass() == this.getClass()) {
			if (type.type().equals(((TPEType) t).type().type())) {
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}

}
