/* abc - The AspectBench Compiler
 * Copyright (C) 2004 Oege de Moor
 *
 * This compiler is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This compiler is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this compiler, in the file LESSER-GPL;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

package abc.aspectj.types;

import java.util.Iterator;
import java.util.List;

import polyglot.ext.jl.types.MethodInstance_c;
import polyglot.types.Flags;
import polyglot.types.ReferenceType;
import polyglot.types.Type;
import polyglot.types.TypeSystem;
import polyglot.util.Position;

/**
 * 
 * @author Oege de Moor
 * 
 */
public class AdviceInstance_c extends MethodInstance_c {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected String signature;

	/** Used for deserializing types. */
	protected AdviceInstance_c() {
	}

	public AdviceInstance_c(final TypeSystem ts, final Position pos,
			final ReferenceType container, final Flags flags,
			final Type returnType, final String name, final List formalTypes,
			final List excTypes, final String signature) {
		super(ts, pos, container, flags, returnType, name, formalTypes,
				excTypes);

		this.signature = signature;
	}

	@Override
	public String toString() {
		String s = designator() + " " + flags.translate() + signature();

		if (!excTypes.isEmpty()) {
			s += " throws ";

			for (final Iterator i = excTypes.iterator(); i.hasNext();) {
				final Type t = (Type) i.next();
				s += t.toString();

				if (i.hasNext()) {
					s += ", ";
				}
			}
		}

		return s;
	}

	@Override
	public String signature() {
		return signature;
	}

	@Override
	public String designator() {
		return "advice";
	}
}
