/* abc - The AspectBench Compiler
 * Copyright (C) 2004 oege
 * Copyright (C) 2004 Oege de Moor
 *
 * This compiler is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This compiler is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this compiler, in the file LESSER-GPL;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/*
 * Created on May 26, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package abc.aspectj.extension;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import polyglot.ast.Node;
import polyglot.ext.jl.ast.ClassBody_c;
import polyglot.types.ClassType;
import polyglot.types.ConstructorInstance;
import polyglot.types.FieldInstance;
import polyglot.types.MemberInstance;
import polyglot.types.MethodInstance;
import polyglot.types.SemanticException;
import polyglot.util.Position;
import polyglot.visit.TypeChecker;
import abc.aspectj.ast.AJNodeFactory;
import abc.aspectj.ast.IntertypeMethodDecl_c;
import abc.aspectj.ast.MakesAspectMethods;
import abc.aspectj.types.AJContext;
import abc.aspectj.types.AJTypeSystem;
import abc.aspectj.types.AJTypeSystem_c;
import abc.aspectj.types.InterTypeMemberInstance;
import abc.aspectj.types.InterTypeMethodInstance;
import abc.aspectj.types.PointcutInstance_c;
import abc.aspectj.visit.AspectMethods;

/**
 * @author Oege de Moor
 * 
 */
public class AJClassBody_c extends ClassBody_c implements MakesAspectMethods {

	public AJClassBody_c(final Position pos, final List members) {
		super(pos, members);
	}

	@Override
	protected void duplicateConstructorCheck(final TypeChecker tc)
			throws SemanticException {
		AJClassBody_c.duplicateConstructorCheck(tc.context().currentClass());
	}

	static void duplicateConstructorCheck(final ClassType type)
			throws SemanticException {

		final ArrayList l = new ArrayList(type.constructors());

		for (int i = 0; i < l.size(); i++) {
			final ConstructorInstance ci = (ConstructorInstance) l.get(i);

			for (int j = i + 1; j < l.size(); j++) {
				final ConstructorInstance cj = (ConstructorInstance) l.get(j);

				if (ci.hasFormals(cj.formalTypes())
						&& !AJClassBody_c.ITDoks(ci, cj)) {
					if (ci instanceof InterTypeMemberInstance) {
						throw new SemanticException("Duplicate constructor \""
								+ ci + "\".", ci.position());
					} else {
						throw new SemanticException("Duplicate constructor \""
								+ cj + "\".", cj.position());
					}
				}
			}
		}
	}

	private static boolean ITDoks(final MemberInstance ci,
			final MemberInstance cj) {
		return AJClassBody_c.ITDok(ci, cj) || AJClassBody_c.ITDok(cj, ci);
	}

	private static boolean ITDok(final MemberInstance ci,
			final MemberInstance cj) {
		final AJTypeSystem_c ts = (AJTypeSystem_c) ci.typeSystem();
		return // a private ITD cannot conflict with anything that's already
		// there
		((ci instanceof InterTypeMemberInstance && ci.flags().isPrivate()) && !(cj instanceof InterTypeMemberInstance))
				||
				// ok to zap private members with a non-private ITD
				// this has changed in ajc
				// ((ci instanceof InterTypeMemberInstance &&
				// !ci.flags().isPrivate() &&
				// !(cj instanceof InterTypeMemberInstance) &&
				// cj.flags().isPrivate())) ||
				// ok to have two ITDs that cannot see each other
				((ci instanceof InterTypeMemberInstance
						&& cj instanceof InterTypeMemberInstance
						&& !ts.isAccessible(ci, ((InterTypeMemberInstance) cj)
								.origin()) && !ts.isAccessible(cj,
						((InterTypeMemberInstance) ci).origin()))) ||
				// also ok to have a duplicate in an interface
				(ci instanceof InterTypeMemberInstance
						&& !(cj instanceof InterTypeMemberInstance) && ci
						.container().toClass().flags().isInterface()) ||
				// and subaspects override their super-aspect
				(ci instanceof InterTypeMemberInstance
						&& cj instanceof InterTypeMemberInstance && ((InterTypeMemberInstance) ci)
						.origin().descendsFrom(
								((InterTypeMemberInstance) cj).origin()));
	}

	@Override
	protected void duplicateFieldCheck(final TypeChecker tc)
			throws SemanticException {
		AJClassBody_c.duplicateFieldCheck(tc.context().currentClass());
	}

	static void duplicateFieldCheck(final ClassType type)
			throws SemanticException {
		final ArrayList l = new ArrayList(type.fields());

		for (int i = 0; i < l.size(); i++) {
			final FieldInstance fi = (FieldInstance) l.get(i);

			for (int j = i + 1; j < l.size(); j++) {
				final FieldInstance fj = (FieldInstance) l.get(j);

				if (fi.name().equals(fj.name())
						&& !AJClassBody_c.ITDoks(fi, fj)) {
					if (fi instanceof InterTypeMemberInstance) {
						throw new SemanticException("Duplicate field \"" + fi
								+ "\".", fi.position());
					} else {
						throw new SemanticException("Duplicate field \"" + fj
								+ "\".", fj.position());
					}
				}
			}
		}
	}

	@Override
	protected void duplicateMethodCheck(final TypeChecker tc)
			throws SemanticException {
		AJClassBody_c.duplicateMethodCheck(tc.context().currentClass());
	}

	static void duplicateMethodCheck(final ClassType type)
			throws SemanticException {

		final ArrayList l = new ArrayList(type.methods());

		for (int i = 0; i < l.size(); i++) {
			final MethodInstance mi = (MethodInstance) l.get(i);

			for (int j = i + 1; j < l.size(); j++) {
				final MethodInstance mj = (MethodInstance) l.get(j);

				if (mi.isSameMethod(mj) && !AJClassBody_c.ITDoks(mi, mj)) {
					if (mi instanceof InterTypeMemberInstance) {
						final InterTypeMethodInstance itmi = (InterTypeMethodInstance) mi;
						if (mj instanceof InterTypeMemberInstance) {
							final InterTypeMethodInstance itmj = (InterTypeMethodInstance) mj;
							throw new SemanticException("Duplicate method \""
									+ mi.signature() + "\" introduced by "
									+ "aspects \"" + itmi.origin()
									+ "\" and \"" + itmj.origin()
									+ "\" into class \"" + mi.container()
									+ "\".", mi.position());
						}
						throw new SemanticException("Duplicate method \""
								+ mi.signature() + "\" introduced by "
								+ "aspect \"" + itmi.origin()
								+ "\" into class \"" + mi.container()
								+ "\", which already contains that method.", mi
								.position());
					}
					if (mj instanceof InterTypeMemberInstance) {
						final InterTypeMethodInstance itmj = (InterTypeMethodInstance) mj;
						throw new SemanticException("Duplicate method \""
								+ mj.signature() + "\" introduced by "
								+ "aspect \"" + itmj.origin()
								+ "\" into class \"" + mj.container()
								+ "\", which already contains that method.", mj
								.position());
					} else if (mi instanceof PointcutInstance_c) {
						throw new SemanticException("Duplicate " + mj
								+ " in class \"" + mj.container() + "\".", mj
								.position());
					} else {
						throw new SemanticException("Duplicate method \""
								+ mj.signature() + "\" in class \""
								+ mi.container() + "\".", mj.position());
					}
				}
			}
		}
	}

	@Override
	public Node typeCheck(final TypeChecker tc) throws SemanticException {
		final Node n = super.typeCheck(tc);
		IntertypeMethodDecl_c
				.intertypeMethodChecks(tc.context().currentClass());
		return n;
	}

	public static void checkDuplicates(final ClassType ct)
			throws SemanticException {
		AJClassBody_c.duplicateConstructorCheck(ct);
		AJClassBody_c.duplicateFieldCheck(ct);
		AJClassBody_c.duplicateMethodCheck(ct);
	}

	public void aspectMethodsEnter(final AspectMethods visitor) {
		final AJContext c = (AJContext) visitor.context();
		final ClassType ct = c.currentClassScope();
		if (c.inAdvice()) {
			for (final Iterator mets = ct.methods().iterator(); mets.hasNext();) {
				final MethodInstance mi = (MethodInstance) mets.next();
				visitor.advice().localMethod(mi);
			}
			for (final Iterator cons = ct.constructors().iterator(); cons
					.hasNext();) {
				final ConstructorInstance ci = (ConstructorInstance) cons
						.next();
				visitor.advice().localMethod(ci);
			}
		}
	}

	public Node aspectMethodsLeave(final AspectMethods visitor,
			final AJNodeFactory nf, final AJTypeSystem ts) {
		return this;
	}
}
