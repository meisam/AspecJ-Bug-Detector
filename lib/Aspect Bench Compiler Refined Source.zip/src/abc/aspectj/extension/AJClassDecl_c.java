/* abc - The AspectBench Compiler
 * Copyright (C) 2004 Oege de Moor
 * Copyright (C) 2004 oege
 *
 * This compiler is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This compiler is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this compiler, in the file LESSER-GPL;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/*
 * Created on Jun 10, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package abc.aspectj.extension;

import java.util.Iterator;
import java.util.List;
import java.util.Stack;

import polyglot.ast.ClassBody;
import polyglot.ast.ClassDecl;
import polyglot.ast.MethodDecl;
import polyglot.ast.Node;
import polyglot.ast.TypeNode;
import polyglot.ext.jl.ast.ClassDecl_c;
import polyglot.frontend.Job;
import polyglot.types.ClassType;
import polyglot.types.Context;
import polyglot.types.Flags;
import polyglot.types.ParsedClassType;
import polyglot.types.SemanticException;
import polyglot.types.Type;
import polyglot.util.Position;
import polyglot.visit.AmbiguityRemover;
import polyglot.visit.TypeChecker;
import abc.aspectj.ast.AJNodeFactory;
import abc.aspectj.ast.MakesAspectMethods;
import abc.aspectj.types.AJTypeSystem;
import abc.aspectj.types.AspectType;
import abc.aspectj.visit.AspectMethods;

/**
 * @author oege
 */

public class AJClassDecl_c extends ClassDecl_c implements MakesAspectMethods {

	protected boolean superDisambiguated = false;
	protected boolean hierarchyBuilt = false;

	/**
	 * @param pos
	 * @param flags
	 * @param name
	 * @param superClass
	 * @param interfaces
	 * @param body
	 */
	public AJClassDecl_c(final Position pos, final Flags flags,
			final String name, final TypeNode superClass,
			final List interfaces, final ClassBody body) {
		super(pos, flags, name, superClass, interfaces, body);
	}

	public boolean hierarchyBuilt() {
		return hierarchyBuilt;
	}

	public void setHierarchyBuilt() {
		hierarchyBuilt = true;
	}

	@Override
	public Node disambiguate(final AmbiguityRemover ar)
			throws SemanticException {
		if (ar.kind() == AmbiguityRemover.SIGNATURES) {
			// make sure that the inStaticContext flag of the class is
			// correct
			final Context ctxt = ar.context();
			this.type().inStaticContext(ctxt.inStaticContext());
			addSuperDependencies(this.type(), ar.job());
			return this;
		}
		return super.disambiguate(ar);
	}

	public void addSuperDependencies(final ClassType ct, final Job job)
			throws SemanticException {
		final Stack s = new Stack();
		final Stack w = new Stack();
		final Stack ctl = new Stack();
		ctl.add(ct);
		s.push(ctl);
		w.push(null);
		while (!s.isEmpty()) {

			final Stack l = (Stack) s.pop();
			if (l.isEmpty()) {
				w.pop();
			} else {

				final Type t = (Type) l.pop();
				s.push(l);
				if (w.contains(t)) {
					throw new SemanticException("Type " + t
							+ " cannot circularly implement or extend itself.",
							position());
				}

				if (t.isClass()) {
					final ClassType classt = t.toClass();
					// add a dependency if its a parsed class type.
					if (classt instanceof ParsedClassType) {
						job.extensionInfo().addDependencyToCurrentJob(
								((ParsedClassType) classt).fromSource());
					}

					// add all the interfaces to the stack.
					final Stack newelems = new Stack();
					newelems.addAll(classt.interfaces());

					// add the superType to the stack.
					if (classt.superType() != null) {
						final Type st = classt.superType();
						newelems.add(st);
					}
					s.push(newelems);
					w.push(t);
				}
			}

		}

	}

	@Override
	protected void disambiguateSuperType(final AmbiguityRemover ar)
			throws SemanticException {
		if (superDisambiguated) {
			return;
		}
		superDisambiguated = true;
		super.disambiguateSuperType(ar);
	}

	@Override
	public Node typeCheck(final TypeChecker tc) throws SemanticException {
		final ClassDecl n = (ClassDecl) super.typeCheck(tc);
		if (superClass() != null
				&& (n.type().toClass().superType() instanceof AspectType)
				&& !(n.type() instanceof AspectType)) {
			throw new SemanticException(
					"A normal class cannot extend an aspect", superClass
							.position());
		}
		return n;
	}

	public void aspectMethodsEnter(final AspectMethods visitor) {
		visitor.pushClass();
		visitor.pushContainer(type());
	}

	public Node aspectMethodsLeave(final AspectMethods visitor,
			final AJNodeFactory nf, final AJTypeSystem ts) {

		ClassDecl cd = this;
		final List localMethods = visitor.methods();
		visitor.popClass();
		visitor.popContainer();

		for (final Iterator i = localMethods.iterator(); i.hasNext();) {
			final MethodDecl md = (MethodDecl) i.next();
			cd = this.body(cd.body().addMember(md));
		}

		return cd;
	}
}
