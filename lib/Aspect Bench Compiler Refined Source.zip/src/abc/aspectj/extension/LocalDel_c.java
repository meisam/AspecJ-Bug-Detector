/* abc - The AspectBench Compiler
 * Copyright (C) 2004 Julian Tibble
 * Copyright (C) 2004 Oege de Moor
 *
 * This compiler is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This compiler is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this compiler, in the file LESSER-GPL;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

package abc.aspectj.extension;

import polyglot.ast.Call;
import polyglot.ast.Local;
import polyglot.ast.Node;
import polyglot.ext.jl.ast.JL_c;
import polyglot.types.LocalInstance;
import polyglot.types.SemanticException;
import polyglot.visit.TypeChecker;
import abc.aspectj.ast.AJNodeFactory;
import abc.aspectj.ast.AdviceDecl;
import abc.aspectj.ast.MakesAspectMethods;
import abc.aspectj.ast.PCIf;
import abc.aspectj.types.AJContext;
import abc.aspectj.types.AJTypeSystem;
import abc.aspectj.visit.AspectMethods;
import abc.aspectj.visit.AspectReflectionInspect;
import abc.aspectj.visit.AspectReflectionRewrite;
import abc.aspectj.visit.TransformsAspectReflection;

/**
 * @author Julian Tibble
 * @author Oege de Moor
 * 
 */
public class LocalDel_c extends JL_c implements MakesAspectMethods,
		TransformsAspectReflection {

	@Override
	public Node typeCheck(final TypeChecker tc) throws SemanticException {
		final AJContext ajc = (AJContext) tc.context();
		if (ajc.inCflow() && ajc.inIf()) {
			final Local m = (Local) node();
			if (!m.name().equals("thisJoinPoint")
					&& !ajc.getCflowMustBind().contains(m.name())) {
				throw new SemanticException(
						"Local "
								+ m.name()
								+ " is not bound within enclosing cflow: it cannot be used within if(..)",
						node().position());
			}
		}
		return node().typeCheck(tc);
	}

	public void aspectMethodsEnter(final AspectMethods visitor) {
		// do nothing
	}

	public Node aspectMethodsLeave(final AspectMethods visitor,
			final AJNodeFactory nf, final AJTypeSystem ts) {
		if (visitor.isAdvice()) {
			final Local m = (Local) node();
			final AdviceDecl currentAdvice = visitor.advice();

			// add joinpoint formals where necessary
			currentAdvice.joinpointFormals(m);
		}

		if (visitor.isPCIf()) {
			final Local m = (Local) node();
			final PCIf currentPCIf = visitor.pcif();

			// add joinpoint formals where necessary
			currentPCIf.joinpointFormals(m);
		}

		return node();
	}

	public void enterAspectReflectionInspect(final AspectReflectionInspect v,
			final Node parent) {
		if (!v.inspectingLocals()) {
			return;
		}

		final Local m = (Local) node();

		if (!m.name().equals("thisJoinPoint")) {
			return;
		}

		if (parent instanceof Call) {
			final String name = ((Call) parent).name();

			if (name.equals("getKind") || name.equals("getSignature")
					|| name.equals("getSourceLocation")
					|| name.equals("toShortString")
					|| name.equals("toLongString") || name.equals("toString")) {
				return;
			}
		}
		v.disableTransform();
	}

	public void leaveAspectReflectionInspect(final AspectReflectionInspect v) {
	}

	public void enterAspectReflectionRewrite(final AspectReflectionRewrite v,
			final AJTypeSystem ts) {
	}

	public Node leaveAspectReflectionRewrite(final AspectReflectionRewrite v,
			final AJNodeFactory nf) {
		if (!v.inspectingLocals()) {
			return node();
		}

		final Local m = (Local) node();
		if (m.name().equals("thisJoinPoint")) {
			final LocalInstance li = v.getJPSP();
			if (li != null) {
				return nf.Local(m.position(), "thisJoinPointStaticPart")
						.localInstance(li).type(li.type());
			}
		}
		return node();
	}
}
