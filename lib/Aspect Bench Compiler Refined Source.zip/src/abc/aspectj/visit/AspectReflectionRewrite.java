/* abc - The AspectBench Compiler
 * Copyright (C) 2004 Ganesh Sittampalam
 *
 * This compiler is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This compiler is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this compiler, in the file LESSER-GPL;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

package abc.aspectj.visit;

import java.util.Stack;

import polyglot.ast.JL;
import polyglot.ast.Node;
import polyglot.ast.NodeFactory;
import polyglot.types.LocalInstance;
import polyglot.types.TypeSystem;
import polyglot.visit.NodeVisitor;
import abc.aspectj.ast.AJNodeFactory;
import abc.aspectj.types.AJTypeSystem;

/**
 * Rewrite all instances of thisJoinPoint to thisJoinPointStaticPart in any
 * aspect body where this is appropriate.
 * 
 * @author Ganesh Sittampalam
 */
public class AspectReflectionRewrite extends NodeVisitor {

	private final Stack/* <LocalInstance> */jpsps; /*
													 * The
													 * thisJoinPointStaticPart
													 * LocalInstances, or null
													 * if we are not
													 * transforming them
													 */

	public AJNodeFactory nf;
	public AJTypeSystem ts;

	public AspectReflectionRewrite(final NodeFactory nf, final TypeSystem ts) {
		super();
		this.nf = (AJNodeFactory) nf;
		this.ts = (AJTypeSystem) ts;
		this.jpsps = new Stack();
	}

	public void enterAdvice(final LocalInstance jpsp) {
		jpsps.push(jpsp);
	}

	public void leaveAdvice() {
		jpsps.pop();
	}

	public boolean inspectingLocals() {
		return !jpsps.empty();
	}

	public LocalInstance getJPSP() {
		return ((LocalInstance) jpsps.peek());
	}

	@Override
	public NodeVisitor enter(final Node n) {
		final JL del = n.del();
		if (del instanceof TransformsAspectReflection) {
			((TransformsAspectReflection) del).enterAspectReflectionRewrite(
					this, ts);
		}
		return this;
	}

	@Override
	public Node leave(final Node old, final Node n, final NodeVisitor v) {
		final JL del = n.del();
		if (del instanceof TransformsAspectReflection) {
			return ((TransformsAspectReflection) del)
					.leaveAspectReflectionRewrite(this, nf);
		}
		return n;
	}
}
