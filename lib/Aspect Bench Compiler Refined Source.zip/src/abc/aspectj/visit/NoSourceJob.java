/* abc - The AspectBench Compiler
 * Copyright (C) 2004 Aske Simon Christensen
 *
 * This compiler is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This compiler is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this compiler, in the file LESSER-GPL;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

package abc.aspectj.visit;

import java.util.List;

import polyglot.frontend.ExtensionInfo;
import polyglot.frontend.Job;
import polyglot.frontend.SourceJob;
import polyglot.util.InternalCompilerError;

/**
 * A dummy job used to collect all the run-once passes when running abc with no
 * input source files.
 * 
 * @author Aske Simon Christensen
 */
public class NoSourceJob extends Job {

	public NoSourceJob(final ExtensionInfo lang) {
		super(lang, null, null);
	}

	@Override
	public List getPasses() {
		throw new InternalCompilerError("A no-source job has no passes");
	}

	@Override
	public SourceJob sourceJob() {
		throw new InternalCompilerError(
				"A no-source job has no associated source job");
	}
}
