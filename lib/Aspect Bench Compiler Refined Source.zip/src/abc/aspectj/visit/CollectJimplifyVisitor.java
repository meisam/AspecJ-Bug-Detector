/* abc - The AspectBench Compiler
 * Copyright (C) 2004 Aske Simon Christensen
 *
 * This compiler is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This compiler is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this compiler, in the file LESSER-GPL;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

package abc.aspectj.visit;

import java.io.File;
import java.io.IOException;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;

import polyglot.ast.ClassDecl;
import polyglot.ast.Node;
import polyglot.ast.NodeFactory;
import polyglot.ast.SourceFile;
import polyglot.frontend.Job;
import polyglot.types.SemanticException;
import polyglot.types.TypeSystem;
import polyglot.visit.ErrorHandlingVisitor;
import polyglot.visit.NodeVisitor;

/**
 * Collects the AST roots of all top-level weavable classes, to give to the
 * later {@link Jimplify} pass.
 * 
 * @author Aske Simon Christensen
 */
public class CollectJimplifyVisitor extends ErrorHandlingVisitor {
	protected Collection/* <String> */source_files;
	protected Map class_to_ast;

	protected Node current_ast;

	public CollectJimplifyVisitor(final Job job, final TypeSystem ts,
			final NodeFactory nf, final Collection/* <String> */source_files,
			final Map class_to_ast) {
		super(job, ts, nf);
		this.source_files = source_files;
		this.class_to_ast = class_to_ast;
	}

	@Override
	protected NodeVisitor enterCall(final Node n) throws SemanticException {
		if (n instanceof SourceFile) {
			boolean found = false;
			File nfile = null;
			try {
				nfile = (new File(((SourceFile) n).source().path()))
						.getCanonicalFile();
			} catch (final IOException e) {
			}
			for (final Iterator it = source_files.iterator(); !found
					&& it.hasNext();) {
				final String name = (String) it.next();
				File f = null;
				try {
					f = (new File(name)).getCanonicalFile();
				} catch (final IOException e) {
				}
				found = (f.compareTo(nfile) == 0);
			}
			if (!found) {
				throw new SemanticException(
						"Source file was needed but not given on the commandline",
						n.position());
			}
			current_ast = n;
		}
		if (n instanceof ClassDecl) {
			final String cname = ((ClassDecl) n).type().fullName();
			// System.err.println("Collecting class "+cname);
			class_to_ast.put(cname, current_ast);
			return bypassChildren(n);
		}
		return this;
	}

}
