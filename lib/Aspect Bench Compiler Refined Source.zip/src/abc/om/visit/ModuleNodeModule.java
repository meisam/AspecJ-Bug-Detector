/* abc - The AspectBench Compiler
 * Copyright (C) 2005 Neil Ongkingco
 *
 * This compiler is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This compiler is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this compiler, in the file LESSER-GPL;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/*
 * Created on Jul 29, 2005
 *
 */
package abc.om.visit;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import polyglot.util.Position;
import abc.aspectj.ast.ClassnamePatternExpr;
import abc.aspectj.visit.PCNode;
import abc.om.AbcExtension;
import abc.om.ast.OpenClassMember;
import abc.om.ast.SigMember;
import abc.om.ast.SigMemberAdvertiseDecl;
import abc.om.weaving.aspectinfo.BoolPointcut;
import abc.om.weaving.aspectinfo.OMClassnamePattern;
import abc.om.weaving.aspectinfo.ThisAspectPointcut;
import abc.weaving.aspectinfo.AndPointcut;
import abc.weaving.aspectinfo.Aspect;
import abc.weaving.aspectinfo.ClassnamePattern;
import abc.weaving.aspectinfo.NotPointcut;
import abc.weaving.aspectinfo.OrPointcut;
import abc.weaving.aspectinfo.Pointcut;
import abc.weaving.aspectinfo.Within;

/**
 * Internal representation of modules.
 * 
 * @author Neil Ongkingco
 * 
 */
public class ModuleNodeModule extends ModuleNode implements ModulePrecedence {
	private List /* ModuleNode */members = null;

	private List /* SigMember */sigMembers = null; // TODO: Seems to be unused,
													// check if removal possible

	// pointcut which is the disjuction of the sigMembers;
	private abc.weaving.aspectinfo.Pointcut sigAIPointcut = null;
	private abc.weaving.aspectinfo.Pointcut privateSigAIPointcut = null;

	private MSOpenClassMember openClassMember = null;

	// true if the module is included as a constrained module
	// only valid for modules
	private boolean isConstrained = false;

	// pointcut which is a conjunction of !within(A) where A is a member of the
	// module. Initially, this pointcut contains only the immediate members
	// (class
	// and aspect), and does not include the extPointcuts of its children.
	// Once a call to getExtPointcut occurs, the whole extPointcut is built
	// by traversing the subtree rooted at the module.
	// Note: This is initialized to BoolPointcut(false) in the constructor. This
	// assumes that the extpointcut is a conjunction of !within() terms
	private abc.weaving.aspectinfo.Pointcut extPointcut = null;

	private boolean extPointcutBuilt = false;

	private Aspect dummyAspect = null;

	private boolean isRoot = false;

	public ModuleNodeModule(final String name, final boolean isRoot,
			final Position pos) {
		this.name = name;
		this.pos = pos;
		members = new LinkedList();
		// initializer values for AIPointcuts
		sigAIPointcut = BoolPointcut.construct(false, AbcExtension.generated);
		privateSigAIPointcut = BoolPointcut.construct(false,
				AbcExtension.generated);
		// note: This assumes that extPointcut is a conjunction of !within()
		// terms
		extPointcut = BoolPointcut.construct(true, AbcExtension.generated);
		this.isRoot = isRoot;
	}

	public boolean isRoot() {
		return this.isRoot;
	}

	public void setIsConstrained(final boolean isConstrained) {
		this.isConstrained = isConstrained;
	}

	public boolean isConstrained() {
		return isConstrained;
	}

	public void addMember(final ModuleNode node) {
		// add to list
		members.add(node);
		node.setParent(this); // should already be done in module structure,
								// but do here as well anyway

		// recompute extpointcut
		if (node.isClass()) {
			final Pointcut pc = makeExtPointcut(node);
			if (extPointcut == null) {
				extPointcut = pc;
			} else {
				extPointcut = AndPointcut.construct(extPointcut, pc,
						AbcExtension.generated);
			}
		}
	}

	private Pointcut makeExtPointcut(final ModuleNode node) {
		assert (node.isClass()) : "Parameter is not a class node";

		// create !within(node.name) pointcut
		ClassnamePatternExpr cpe = null;
		if (node.isClass()) {
			cpe = ((ModuleNodeClass) node).getCPE();
		}
		assert (cpe != null) : "Class node CPE not properly initialized";

		final ClassnamePattern namePattern = new OMClassnamePattern(cpe);
		Pointcut pc = new Within(namePattern, AbcExtension.generated);
		pc = NotPointcut.construct(pc, AbcExtension.generated);
		return pc;
	}

	// returns the extPointcut. If it is not yet completely built, it builds
	// the entire subtree rooted at the module;
	// This should not be called until the module tree has been built
	public Pointcut getExtPointcut() {
		assert (isModule()) : "Parameter is not a module node"; // only
																// allowable for
																// modules

		if (!extPointcutBuilt) {
			extPointcutBuilt = true;
			for (final Iterator iter = members.iterator(); iter.hasNext();) {
				final ModuleNode member = (ModuleNode) iter.next();
				if (!member.isModule()) {
					continue;
				}
				final Pointcut member_pc = ((ModuleNodeModule) member)
						.getExtPointcut();
				if (member_pc != null) {
					extPointcut = AndPointcut.construct(extPointcut, member_pc,
							AbcExtension.generated);
				}
			}
		}
		return extPointcut;
	}

	public void addSigMember(final SigMember sigMember) {
		if (sigMembers == null) {
			sigMembers = new LinkedList();
		}
		sigMembers.add(sigMember);

		// update the AIPointcuts
		abc.weaving.aspectinfo.Pointcut newPointcut = sigMember.getAIPointcut();
		// if an advertise member, add the ext pointcut
		if (sigMember instanceof SigMemberAdvertiseDecl) {
			newPointcut = AndPointcut.construct(newPointcut, this
					.getExtPointcut(), AbcExtension.generated);
		}
		if (sigMember.isPrivate()) {
			privateSigAIPointcut = OrPointcut.construct(privateSigAIPointcut,
					newPointcut, AbcExtension.generated);
		} else {
			sigAIPointcut = OrPointcut.construct(sigAIPointcut, newPointcut,
					AbcExtension.generated);
		}
	}

	public void addOpenClassMember(final OpenClassMember ocm) {
		final MSOpenClassMemberBase newMember = new MSOpenClassMemberBase(ocm
				.getFlags(), ocm.getCPE(), ocm.getToClauseCPE());
		if (openClassMember == null) {
			openClassMember = newMember;
			return;
		} else {
			openClassMember = new MSOpenClassMemberOr(openClassMember,
					newMember);
		}

	}

	public Pointcut getSigAIPointcut() {
		return sigAIPointcut;
	}

	public Pointcut getPrivateSigAIPointcut() {
		return privateSigAIPointcut;
	}

	public List getMembers() {
		return members;
	}

	public List getSigMembers() {
		return sigMembers;
	}

	// only for finding modules and aspects
	public boolean containsMember(final String name, final int type) {
		if (members == null) {
			return false;
		}
		for (final Iterator iter = members.iterator(); iter.hasNext();) {
			final ModuleNode member = (ModuleNode) iter.next();
			if (name.compareTo(member.name()) == 0 && member.type() == type) {
				return true;
			}
		}
		return false;
	}

	// only for finding modules and aspects
	public boolean containsMember(final ModuleNode n) {
		return containsMember(n.name(), n.type());
	}

	// for classes, also for aspect PCNodes
	public boolean containsMember(final PCNode node) {
		if (members == null) {
			return false;
		}
		for (final Iterator iter = members.iterator(); iter.hasNext();) {
			final ModuleNode member = (ModuleNode) iter.next();
			// check if the CPE matches the node
			if (member.isClass()) {
				final ModuleNodeClass memberClass = (ModuleNodeClass) member;
				if (memberClass.getCPE().matches(node)) {
					return true;
				}
			}
		}
		return false;
	}

	// Gets the names of the aspects that belong to this module and its children
	// Should only be called on modules
	public Set /* <String> */getAspectNames() {
		assert (this.isModule()) : "getAspectNames invoked on non-module node";
		final Set ret = new HashSet();
		for (final Iterator iter = members.iterator(); iter.hasNext();) {
			final ModuleNode member = (ModuleNode) iter.next();
			if (member.isAspect()) {
				ret.add(member.name());
			}
			if (member.isModule()) {
				final ModuleNodeModule memberModule = (ModuleNodeModule) member;
				ret.addAll(memberModule.getAspectNames());
			}
		}
		return ret;
	}

	public void normalizeSigPointcut() {
		Pointcut newPc = this.sigAIPointcut;
		if (newPc != null) {
			// Only need to normalize the sigAIPointcut
			newPc = Pointcut.normalize(newPc, new LinkedList(),
					getDummyAspect());
			this.sigAIPointcut = newPc;
		}
	}

	public Aspect getDummyAspect() {
		return dummyAspect;
	}

	public void setDummyAspect(final Aspect dummyAspect) {
		this.dummyAspect = dummyAspect;
	}

	// returns thisAspect(A), thisAspect(B), ...where A,B... are friends of the
	// module
	public Pointcut getThisAspectPointcut() {
		Pointcut ret = BoolPointcut.construct(false, AbcExtension.generated);
		for (final Iterator iter = members.iterator(); iter.hasNext();) {
			final ModuleNode currMember = (ModuleNode) iter.next();

			// if not an aspect member, proceed to next
			if (!(currMember instanceof ModuleNodeAspect)) {
				continue;
			}

			final ModuleNodeAspect aspectMember = (ModuleNodeAspect) currMember;
			final Pointcut newTerm = ThisAspectPointcut.construct(
					new OMClassnamePattern(aspectMember.getCPE()),
					AbcExtension.generated);
			ret = OrPointcut.construct(ret, newTerm, AbcExtension.generated);
		}
		return ret;
	}

	public MSOpenClassMember getOpenClassMembers() {
		if (this.openClassMember == null) {
			this.openClassMember = new MSOpenClassMemberBase();
		}
		return this.openClassMember;
	}

	public void setOpenClassMembers(final MSOpenClassMember ocm) {
		this.openClassMember = ocm;
	}

	@Override
	public boolean isAspect() {
		return false;
	}

	@Override
	public boolean isClass() {
		return false;
	}

	@Override
	public boolean isModule() {
		return true;
	}

	@Override
	public int type() {
		return ModuleNode.TYPE_MODULE;
	}
}
