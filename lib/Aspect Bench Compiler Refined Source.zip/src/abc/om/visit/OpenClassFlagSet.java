/* abc - The AspectBench Compiler
 * Copyright (C) 2005 Neil Ongkingco
 *
 * This compiler is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This compiler is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this compiler, in the file LESSER-GPL;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

package abc.om.visit;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import polyglot.util.CodeWriter;
import polyglot.visit.PrettyPrinter;
import abc.aspectj.ast.ClassnamePatternExpr;
import abc.om.ast.OpenClassMemberFlag;
import abc.om.ast.OpenClassMemberFlagField;
import abc.om.ast.OpenClassMemberFlagMethod;
import abc.om.ast.OpenClassMemberFlagParent;

public class OpenClassFlagSet {

	public static class OCFType {
		public OCFType() {
		};
	}

	public static final OCFType FIELD = new OCFType();
	public static final OCFType PARENT = new OCFType();
	public static final OCFType METHOD = new OCFType();

	protected ClassnamePatternExpr parentCPE = null;

	// do not allow null mappings
	protected Map /* <OCFType, MSOpenClassFlag> */flagMap = new HashMap();

	public OpenClassFlagSet() {
	}

	public OpenClassFlagSet(final List /* OpenClassMemberFlag */memberFlags) {
		for (final Iterator i = memberFlags.iterator(); i.hasNext();) {
			final OpenClassMemberFlag currFlag = (OpenClassMemberFlag) i.next();
			if (currFlag instanceof OpenClassMemberFlagField) {
				flagMap.put(OpenClassFlagSet.FIELD, new MSOpenClassFlagField(
						currFlag));
			} else if (currFlag instanceof OpenClassMemberFlagMethod) {
				flagMap.put(OpenClassFlagSet.METHOD, new MSOpenClassFlagMethod(
						currFlag));
			} else if (currFlag instanceof OpenClassMemberFlagParent) {
				flagMap.put(OpenClassFlagSet.PARENT, new MSOpenClassFlagParent(
						currFlag));
			}
		}
	}

	public boolean isAllowed(final OCFType type,
			final MSOpenClassContext context) {
		final MSOpenClassFlag flag = (MSOpenClassFlag) flagMap.get(type);
		if (flag == null) {
			return false;
		}
		return flag.isAllowed(context);
	}

	@Override
	public String toString() {
		String result = "(";
		for (final Iterator i = flagMap.keySet().iterator(); i.hasNext();) {
			final OCFType currType = (OCFType) i.next();
			final MSOpenClassFlag currFlag = (MSOpenClassFlag) flagMap
					.get(currType);
			result += currFlag.toString() + " ";
		}
		result += ")";
		return result;
	}

	public void prettyPrint(final CodeWriter w, final PrettyPrinter pp) {
		w.write("(");
		for (final Iterator i = flagMap.keySet().iterator(); i.hasNext();) {
			final OCFType currType = (OCFType) i.next();
			final MSOpenClassFlag currFlag = (MSOpenClassFlag) flagMap
					.get(currType);
			currFlag.prettyPrint(w, pp);
			w.write(" ");
		}
		w.write(")");
	}
}
