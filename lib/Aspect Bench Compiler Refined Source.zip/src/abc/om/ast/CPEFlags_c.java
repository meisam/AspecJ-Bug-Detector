/* abc - The AspectBench Compiler
 * Copyright (C) 2006
 *
 * This compiler is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This compiler is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this compiler, in the file LESSER-GPL;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */
package abc.om.ast;

import polyglot.ast.Node;
import polyglot.ast.Precedence;
import polyglot.types.ClassType;
import polyglot.types.Flags;
import polyglot.util.CodeWriter;
import polyglot.util.Position;
import polyglot.visit.NodeVisitor;
import polyglot.visit.PrettyPrinter;
import abc.aspectj.ast.ClassnamePatternExpr;
import abc.aspectj.ast.ClassnamePatternExpr_c;
import abc.aspectj.visit.PCNode;
import abc.aspectj.visit.PCStructure;
import abc.aspectj.visit.PatternMatcher;

/**
 * @author Neil Ongkingco
 * 
 */
public class CPEFlags_c extends ClassnamePatternExpr_c implements CPEFlags {
	protected Flags flags;

	protected ClassnamePatternExpr cpe;

	public CPEFlags_c(final Flags flags, final ClassnamePatternExpr cpe,
			final Position pos) {
		super(pos);
		this.flags = flags;
		this.cpe = cpe;
	}

	public ClassnamePatternExpr getCpe() {
		return this.cpe;
	}

	public Flags getFlags() {
		return this.flags;
	}

	protected CPEFlags_c reconstruct(final ClassnamePatternExpr cpe) {
		if (cpe != this.cpe) {
			final CPEFlags_c n = (CPEFlags_c) copy();
			n.cpe = cpe;
			return n;
		}
		return this;
	}

	@Override
	public Node visitChildren(final NodeVisitor v) {
		final ClassnamePatternExpr cpe = (ClassnamePatternExpr) visitChild(
				this.cpe, v);
		return reconstruct(cpe);
	}

	@Override
	public Precedence precedence() {
		return Precedence.UNARY;
	}

	@Override
	public void prettyPrint(final CodeWriter w, final PrettyPrinter tr) {
		w.write(flags.toString());
		printSubExpr(cpe, true, w, tr);
	}

	@Override
	public String toString() {
		return flags.toString() + cpe;
	}

	// TODO: This does not yet work in the back end, later passes clean out the
	// flags if aspect classes. This means that statements such as
	// advertise to !(privileged *): call(* foo())
	// are allowed by the language, but do not conform to the expected
	// semantics.
	public boolean matches(final PatternMatcher matcher, final PCNode cl) {
		// check if cl matches the flags
		final ClassType ct = PCStructure.v().getClassType(cl);
		// assert (ct != null) : "ClassType not found. Possible PCStructure
		// corruption";
		if (!CPEFlags_c.equalFlags(flags, ct.flags())) {
			return false;
		}
		return cpe.matches(matcher, cl);
	}

	public boolean equivalent(final ClassnamePatternExpr otherexp) {
		if (otherexp.getClass() == this.getClass()) {
			final CPEFlags otherCPEFlags = (CPEFlags) otherexp;
			return CPEFlags_c.equalFlags(flags, otherCPEFlags.getFlags())
					&& (cpe.equivalent(otherCPEFlags.getCpe()));
		} else {
			return false;
		}
	}

	private static boolean equalFlags(final Flags a, final Flags b) {
		return a.contains(b) && b.contains(a);
	}

}
