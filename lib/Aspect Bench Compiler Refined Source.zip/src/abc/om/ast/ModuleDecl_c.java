/* abc - The AspectBench Compiler
 * Copyright (C) 2005 Neil Ongkingco
 *
 * This compiler is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This compiler is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this compiler, in the file LESSER-GPL;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/*
 * Created on May 13, 2005
 *
 */
package abc.om.ast;

import polyglot.ast.Node;
import polyglot.ext.jl.ast.Node_c;
import polyglot.types.Flags;
import polyglot.types.Named;
import polyglot.types.TypeObject;
import polyglot.types.TypeSystem;
import polyglot.util.CodeWriter;
import polyglot.util.Position;
import polyglot.visit.NodeVisitor;
import polyglot.visit.PrettyPrinter;
import abc.aspectj.types.AJFlags;

/**
 * Represents the entire module declarations. Contains the module name and the
 * module body.
 * 
 * @author Neil Ongkingco
 * 
 */
public class ModuleDecl_c extends Node_c implements ModuleDecl {
	private ModuleBody body;

	private final String name;

	private final Position namePos;

	private boolean isRoot = false;

	public ModuleDecl_c(final Position pos, final String name,
			final ModuleBody body, final Position namePos, final boolean isRoot) {
		super(pos);
		this.name = name;
		this.body = body;
		this.namePos = namePos;
		this.isRoot = isRoot;
	}

	public Flags flags() {
		return new AJFlags();
	}

	public String name() {
		return name;
	}

	public Position namePos() {
		return this.namePos;
	}

	public boolean isRoot() {
		return isRoot;
	}

	/* Required by Polyglot 1.3.2 */
	public Named declaration() {
		return new Named() {
			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			public String name() {
				return name;
			}

			public String fullName() {
				return namePos.file();
			}

			public TypeSystem typeSystem() {
				return null;
			}

			public Object copy() {
				return null;
			}

			public boolean isCanonical() {
				return false;
			}

			public boolean equalsImpl(final TypeObject t) {
				return false;
			}

			public Position position() {
				return namePos();
			}
		};
	}

	@Override
	public void prettyPrint(final CodeWriter w, final PrettyPrinter pp) {
		w.write("module " + name);
		w.newline();
		body.prettyPrint(w, pp);
	}

	public ModuleDecl_c reconstruct(final ModuleBody body) {
		if (body != this.body) {
			final ModuleDecl_c n = (ModuleDecl_c) copy();
			n.body = body;
			return n;
		}
		return this;
	}

	@Override
	public Node visitChildren(final NodeVisitor v) {
		// Nothing changes
		final ModuleBody body = (ModuleBody) visitChild(this.body, v);

		return reconstruct(body);
	}
}
