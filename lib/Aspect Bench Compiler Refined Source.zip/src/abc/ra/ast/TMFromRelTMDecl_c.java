/* abc - The AspectBench Compiler
 * Copyright (C) 2007 Eric Bodden
 * Copyright (C) 2007 Reehan Shaikh
 *
 * This compiler is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This compiler is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this compiler, in the file LESSER-GPL;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */
package abc.ra.ast;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import polyglot.ast.Block;
import polyglot.ast.Formal;
import polyglot.ast.MethodDecl;
import polyglot.types.CodeInstance;
import polyglot.types.ConstructorInstance;
import polyglot.types.Flags;
import polyglot.types.MethodInstance;
import polyglot.util.Position;
import polyglot.util.TypedList;
import abc.aspectj.ast.Around;
import abc.ra.ExtensionInfo;
import abc.ra.visit.AroundReplacer;
import abc.ra.visit.RegexShuffle;
import abc.ra.visit.SymbolCollector;
import abc.ra.weaving.aspectinfo.RATraceMatch;
import abc.tm.ast.Regex;
import abc.tm.ast.SymbolDecl;
import abc.tm.ast.SymbolKind;
import abc.tm.ast.TMAdviceDecl;
import abc.tm.ast.TMDecl;
import abc.tm.ast.TMDecl_c;
import abc.tm.ast.TMModsAndType;
import abc.tm.ast.TMNodeFactory;
import abc.tm.weaving.aspectinfo.TMGlobalAspectInfo;
import abc.tm.weaving.aspectinfo.TraceMatch;
import abc.weaving.aspectinfo.AbcFactory;
import abc.weaving.aspectinfo.Aspect;
import abc.weaving.aspectinfo.GlobalAspectInfo;
import abc.weaving.aspectinfo.MethodCategory;
import abc.weaving.aspectinfo.MethodSig;

/**
 * A tracematch generated from a relational tracematch. This adds associate and
 * release symbols and rewrites the pattern. A regular expression <i>r</i>
 * becomes transformed to <i>associate r</i>. Also, formals of the relational
 * aspect are added and a state variable is generated.
 * 
 * @author Eric Bodden
 */
public class TMFromRelTMDecl_c extends TMDecl_c implements TMDecl {

	/** Suffix for internal state variables. */
	public static final String INTERNAL_STATE_VAR_SUFFIX = "$relaspect$internal$state";

	private static final Position POS = Position.compilerGenerated();

	public TMFromRelTMDecl_c(final Position pos,
			final TMModsAndType mods_and_type, final String tracematch_name,
			final List formals, final List throwTypes, final List symbols,
			final List frequent_symbols, final Regex regex, final Block body,
			final RelAspectDecl container, final RelTMDecl_c originator,
			final RANodeFactory nf) {
		super(pos, body.position(), TMFromRelTMDecl_c.newModsAndType(
				mods_and_type, nf), tracematch_name, TMFromRelTMDecl_c
				.newFormals(formals, tracematch_name, container, nf),
				throwTypes, TMFromRelTMDecl_c.newSymbols(symbols,
						tracematch_name, container, nf), frequent_symbols,
				TMFromRelTMDecl_c.newRegex(regex, symbols, nf), body);
	}

	private static TMModsAndType newModsAndType(
			final TMModsAndType mods_and_type, final TMNodeFactory nf) {
		return nf.TMModsAndType(
				mods_and_type.getFlags().clear(
						ExtensionInfo.RELATIONAL_MODIFIER), // clear
															// "relational"
															// modifier
				mods_and_type.isPerThread(),
				mods_and_type.beforeOrAroundSpec(), mods_and_type.afterSpec(),
				mods_and_type.isAround(), mods_and_type.getReturnType());
	}

	private static List<SymbolDecl> newSymbols(final List symbols,
			final String tracematch_name, final RelAspectDecl container,
			final RANodeFactory nf) {
		final List<SymbolDecl> newSymbols = new ArrayList<SymbolDecl>(symbols);

		for (final SymbolDecl symbolDecl : (List<SymbolDecl>) symbols) {
			if (symbolDecl.kind().equals(SymbolKind.AROUND)) {
				final SymbolDecl beforeSym = nf.SymbolDecl(symbolDecl
						.position(), symbolDecl.name()
						+ AroundReplacer.BEFORE_SYMBOL_SUFFIX, nf
						.BeforeSymbol(symbolDecl.position()), symbolDecl
						.getPointcut());
				newSymbols.add(beforeSym);
			}
		}

		newSymbols.add(nf.StartSymbolDecl(container.position(), "start"));
		newSymbols.add(nf.AssociateSymbolDecl(container.position(),
				"associate", tracematch_name, true, container));
		newSymbols.add(nf.AssociateSymbolDecl(container.position(),
				"associateAgain", tracematch_name, false, container));
		newSymbols.add(nf.ReleaseSymbolDecl(container.position(), "release",
				tracematch_name, container));

		return newSymbols;
	}

	/**
	 * (start | release) associate (associateAgain* ~ r)+ ... where ~ is the
	 * shuffle operator
	 */
	private static Regex newRegex(final Regex originalRegex,
			final List symbols, final TMNodeFactory nf) {
		// find all around-symbols

		final Set<String> aroundSymbols = new HashSet<String>();
		for (final SymbolDecl symbolDecl : (List<SymbolDecl>) symbols) {
			if (symbolDecl.kind().equals(SymbolKind.AROUND)) {
				aroundSymbols.add(symbolDecl.name());
			}
		}

		// construct a disjunction of all symbols occuring in the original
		// regular expression,
		// replacing around-symbol names by their before-symbol names
		final Regex noAroundOriginalRegex = (Regex) originalRegex
				.visit(new AroundReplacer(aroundSymbols, nf));
		SymbolCollector symbolCollector = new SymbolCollector();
		noAroundOriginalRegex.visit(symbolCollector);
		final Set<String> noAroundOriginalRegexSymbolNames = symbolCollector
				.getSymbolNames();
		final Regex posDisjunction = TMFromRelTMDecl_c.disjunctionOf(
				noAroundOriginalRegexSymbolNames, nf);

		// construct a disjunction of all symbols of the original tracematch not
		// occuring in that tracematch's regex,
		// (i.e. all its skip-symbols)
		final Set<String> symbolNames = new HashSet<String>();
		for (final SymbolDecl symbol : (List<SymbolDecl>) symbols) {
			symbolNames.add(symbol.name());
		}
		symbolCollector = new SymbolCollector();
		originalRegex.visit(symbolCollector);
		final Set<String> originalRegexSymbolNames = symbolCollector
				.getSymbolNames();
		final Set<String> skipSymbols = new HashSet<String>(symbolNames);
		skipSymbols.removeAll(originalRegexSymbolNames);
		Regex negDisjunction = null;
		if (!skipSymbols.isEmpty()) {
			negDisjunction = TMFromRelTMDecl_c.disjunctionOf(skipSymbols, nf);
		}

		// create copy of original regex with asssociateAgain* shuffled into it
		final Regex aaStar = nf.RegexStar(TMFromRelTMDecl_c.POS, nf
				.RegexSymbol(TMFromRelTMDecl_c.POS, "associateAgain"));
		final Regex shuffeledRegex = (Regex) originalRegex
				.visit(new RegexShuffle(aaStar, nf));

		// create a copy of that regex with around-symbols replaced
		final Regex noAroundShuffledRegex = (Regex) shuffeledRegex
				.visit(new AroundReplacer(aroundSymbols, nf));

		// if there is a negDisjunct (i.e. we had skip-symbols) then fit it
		// in...
		Regex disj = null;
		if (negDisjunction == null) {
			disj = nf.RegexSymbol(TMFromRelTMDecl_c.POS, "release");
		} else {
			disj = nf.RegexAlternation(TMFromRelTMDecl_c.POS, nf.RegexSymbol(
					TMFromRelTMDecl_c.POS, "release"), negDisjunction);
		}

		final Regex newRegex = nf.RegexConjunction(TMFromRelTMDecl_c.POS, nf
				.RegexAlternation(TMFromRelTMDecl_c.POS, nf.RegexSymbol(
						TMFromRelTMDecl_c.POS, "start"), disj), nf
				.RegexConjunction(TMFromRelTMDecl_c.POS, nf.RegexStar(
						TMFromRelTMDecl_c.POS, posDisjunction), nf
						.RegexConjunction(TMFromRelTMDecl_c.POS,
								nf.RegexSymbol(TMFromRelTMDecl_c.POS,
										"associate"), nf.RegexConjunction(
										TMFromRelTMDecl_c.POS, nf.RegexStar(
												TMFromRelTMDecl_c.POS,
												noAroundShuffledRegex),
										shuffeledRegex))));
		return newRegex;
	}

	private static Regex disjunctionOf(final Set<String> symbolNames,
			final TMNodeFactory nf) {
		final Set<String> copy = new HashSet<String>(symbolNames);
		final Iterator<String> iterator = copy.iterator();
		final String first = iterator.next();
		iterator.remove();
		final Regex regexSymbol = nf.RegexSymbol(Position.COMPILER_GENERATED,
				first);
		if (copy.isEmpty()) {
			return regexSymbol;
		} else {
			return nf.RegexAlternation(Position.COMPILER_GENERATED,
					regexSymbol, TMFromRelTMDecl_c.disjunctionOf(copy, nf));
		}
	}

	private static List newFormals(final List formals,
			final String tracematch_name, final RelAspectDecl container,
			final TMNodeFactory nf) {
		List traceMatchFormals = new ArrayList(formals);
		traceMatchFormals.addAll(container.formals());
		final String formalName = TMFromRelTMDecl_c
				.stateVariableName(tracematch_name);
		final polyglot.ast.Formal state = nf.Formal(TMFromRelTMDecl_c.POS,
				Flags.NONE, nf.AmbTypeNode(TMFromRelTMDecl_c.POS, container
						.name()), formalName);
		traceMatchFormals.add(state);
		traceMatchFormals = TypedList.copyAndCheck(traceMatchFormals,
				Formal.class, true);
		return traceMatchFormals;
	}

	/**
	 * Generates the unique state variable name for a tracematch.
	 */
	public static String stateVariableName(final String tracematch_name) {
		return tracematch_name + TMFromRelTMDecl_c.INTERNAL_STATE_VAR_SUFFIX;
	}

	/**
	 * Mostly copied from {@link TMDecl}{@link #update(GlobalAspectInfo, Aspect)}.
	 * Just returns a {@link RATraceMatch} instead of a {@link TraceMatch}.
	 */
	@Override
	public void update(final GlobalAspectInfo gai, final Aspect current_aspect) {
		//
		// create aspectinfo advice declarations
		//

		final int jp_vars = thisJoinPointVariables();

		// list of what the formals will be for the body-advice
		// after the tracematch formals are removed.
		final List transformed_formals = bodyAdviceFormals();
		for (int i = formals.size() - jp_vars; i < formals.size(); i++) {
			transformed_formals.add(formals.get(i));
		}

		int lastpos = transformed_formals.size();
		int jp = -1, jpsp = -1, ejp = -1;

		if (hasEnclosingJoinPointStaticPart) {
			ejp = --lastpos;
		}
		if (hasJoinPoint) {
			jp = --lastpos;
		}
		if (hasJoinPointStaticPart) {
			jpsp = --lastpos;
		}

		before_around_spec.setReturnType(returnType());
		if (after_spec != null) {
			after_spec.setReturnType(returnType());
		}

		final List<MethodSig> methods = new ArrayList<MethodSig>();
		for (final Iterator procs = methodsInAdvice.iterator(); procs.hasNext();) {
			final CodeInstance ci = (CodeInstance) procs.next();

			if (ci instanceof MethodInstance) {
				methods.add(AbcFactory.MethodSig((MethodInstance) ci));
			}
			if (ci instanceof ConstructorInstance) {
				methods.add(AbcFactory.MethodSig((ConstructorInstance) ci));
			}
		}

		// create a signature for this method after transformation
		// in the backend (i.e. with only around tracematch formals)
		final MethodSig sig = AbcFactory.MethodSig(this
				.formals(transformed_formals));

		if (before_around_pc != null) {
			final abc.weaving.aspectinfo.AdviceDecl before_ad = new abc.tm.weaving.aspectinfo.TMAdviceDecl(
					before_around_spec.makeAIAdviceSpec(), before_around_pc
							.makeAIPointcut(), sig, current_aspect, jp, jpsp,
					ejp, methods, position(), name(), position(),
					TMAdviceDecl.BODY);

			gai.addAdviceDecl(before_ad);
		}

		if (after_pc != null) {
			final abc.weaving.aspectinfo.AdviceDecl after_ad = new abc.tm.weaving.aspectinfo.TMAdviceDecl(
					after_spec.makeAIAdviceSpec(), after_pc.makeAIPointcut(),
					sig, current_aspect, jp, jpsp, ejp, methods, position(),
					tracematch_name, position(), TMAdviceDecl.BODY);

			gai.addAdviceDecl(after_ad);
		}

		MethodCategory.register(sig, MethodCategory.ADVICE_BODY);

		String proceed_name = null;

		if (isAround) {
			final MethodDecl proceed = ((Around) before_around_spec).proceed();
			proceed_name = proceed.name();
			MethodCategory.register(proceed, MethodCategory.PROCEED);
		}

		//
		// Create aspectinfo tracematch
		//
		final List tm_formals = weavingFormals(formals, true);
		final List body_formals = weavingFormals(transformed_formals, false);

		// create TraceMatch
		// begin of change
		final TraceMatch tm = new RATraceMatch(tracematch_name, tm_formals,
				body_formals, regex.makeSM(), isPerThread, orderedSymToVars(),
				frequent_symbols, sym_to_advice_name, synch_advice,
				some_advice, proceed_name, current_aspect, position(),
				TMFromRelTMDecl_c.stateVariableName(tracematch_name));
		// end of change
		((TMGlobalAspectInfo) gai).addTraceMatch(tm);
	}

}
