/* abc - The AspectBench Compiler
 * Copyright (C) 2008 Eric Bodden
 *
 * This compiler is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This compiler is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this compiler, in the file LESSER-GPL;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

package abc.ra.ast;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import polyglot.types.Flags;
import polyglot.util.Position;
import abc.aspectj.ast.FormalPattern;
import abc.aspectj.ast.ModifierPattern;
import abc.aspectj.ast.Pointcut;
import abc.tm.ast.SymbolDecl;
import abc.tm.ast.SymbolDecl_c;
import abc.tm.ast.SymbolKind;
import abc.tm.ast.TMNodeFactory;

public class StartSymbolDecl_c extends SymbolDecl_c implements SymbolDecl {

	private static final Position POS = Position.compilerGenerated();

	public StartSymbolDecl_c(final Position pos, final String name,
			final TMNodeFactory nf) {
		super(pos, name, StartSymbolDecl_c.createKind(nf), StartSymbolDecl_c
				.createPC(nf));
	}

	/**
	 * Creates pointcut <code>execution(* *.main(String[]))</code>
	 */
	private static Pointcut createPC(final TMNodeFactory nf) {
		final List<ModifierPattern> mods = new LinkedList<ModifierPattern>();
		mods.add(nf.ModifierPattern(StartSymbolDecl_c.POS, Flags.PUBLIC, true));
		mods.add(nf.ModifierPattern(StartSymbolDecl_c.POS, Flags.STATIC, true));

		final List<FormalPattern> formals = new LinkedList<FormalPattern>();
		formals.add(nf.TypeFormalPattern(StartSymbolDecl_c.POS, nf.TPEArray(
				StartSymbolDecl_c.POS, nf.TPERefTypePat(StartSymbolDecl_c.POS,
						nf.RTPName(StartSymbolDecl_c.POS, nf.SimpleNamePattern(
								StartSymbolDecl_c.POS, "String"))), 1)));
		return nf.PCExecution(StartSymbolDecl_c.POS, nf.MethodPattern(
				StartSymbolDecl_c.POS, mods, nf
						.TPEUniversal(StartSymbolDecl_c.POS), nf
						.ClassTypeDotId(StartSymbolDecl_c.POS, nf
								.CPEUniversal(StartSymbolDecl_c.POS), nf
								.SimpleNamePattern(StartSymbolDecl_c.POS,
										"main")), formals, Collections
						.emptyList()));
	}

	private static SymbolKind createKind(final TMNodeFactory nf) {
		return nf.BeforeSymbol(StartSymbolDecl_c.POS);
	}

}
