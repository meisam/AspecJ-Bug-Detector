/* abc - The AspectBench Compiler
 * Copyright (C) 2007 Eric Bodden
 * Copyright (C) 2007 Reehan Shaikh
 *
 * This compiler is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This compiler is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this compiler, in the file LESSER-GPL;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */
package abc.ra.ast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import polyglot.ast.TypeNode;
import polyglot.types.Flags;
import polyglot.util.Position;
import abc.aspectj.ast.AdviceDecl;
import abc.aspectj.ast.AdviceSpec;
import abc.aspectj.ast.AmbTypeOrLocal;
import abc.aspectj.ast.ClassTypeDotId;
import abc.aspectj.ast.ClassnamePatternExpr;
import abc.aspectj.ast.DotDotFormalPattern;
import abc.aspectj.ast.MethodConstructorPattern;
import abc.aspectj.ast.PCBinary;
import abc.aspectj.ast.Pointcut;
import abc.aspectj.ast.SimpleNamePattern;
import abc.aspectj.ast.TypePatternExpr;
import abc.tm.ast.SymbolDecl_c;
import abc.tm.ast.SymbolKind;
import abc.tm.ast.TMNodeFactory;

/**
 * Declaration of an <i>associate</i> symbol for the translation of a
 * relational advice. Matches on
 * <code>call(* RelationalAspectName.associate(T1,...,Tn))</code>.
 * 
 * @author Eric Bodden
 */
public class AssociateSymbolDecl_c extends SymbolDecl_c implements
		AssociateSymbolDecl {

	private static final Position POS = Position.compilerGenerated();

	public AssociateSymbolDecl_c(final Position pos, final String name,
			final String tracematch_name,
			final boolean bindAspectInstanceInReturn,
			final RelAspectDecl container, final TMNodeFactory nf) {
		super(pos, name, AssociateSymbolDecl_c.createKind(nf, tracematch_name,
				bindAspectInstanceInReturn), AssociateSymbolDecl_c
				.createPointcut(container, nf));
	}

	/**
	 * Creates a pointcut
	 * <code>call(* RelationalAspectName.associate(..))</code>.
	 * 
	 * @param container
	 *            the relational aspect owning this symbol
	 * @param nf
	 *            current node factory
	 * @return the generated pointcut
	 */
	private static Pointcut createPointcut(final RelAspectDecl container,
			final TMNodeFactory nf) {
		// return type
		final TypePatternExpr tpe = nf.TPEUniversal(AssociateSymbolDecl_c.POS);

		final List<AmbTypeOrLocal> argsRefs = new ArrayList<AmbTypeOrLocal>();
		final Iterator i = container.formals().iterator();
		while (i.hasNext()) {
			final polyglot.ast.Formal f = (polyglot.ast.Formal) i.next();
			final AmbTypeOrLocal n = nf.AmbTypeOrLocal(
					AssociateSymbolDecl_c.POS, nf.AmbTypeNode(
							AssociateSymbolDecl_c.POS, f.name()));
			argsRefs.add(n);
		}

		final ClassnamePatternExpr cnpe = nf.CPEName(AssociateSymbolDecl_c.POS,
				nf.SimpleNamePattern(AssociateSymbolDecl_c.POS, container
						.name()));
		final DotDotFormalPattern ddfp = nf
				.DotDotFormalPattern(AssociateSymbolDecl_c.POS);
		final List<DotDotFormalPattern> ddf = new LinkedList<DotDotFormalPattern>();
		ddf.add(ddfp);
		final SimpleNamePattern snp = nf.SimpleNamePattern(
				AssociateSymbolDecl_c.POS, "associate");
		// AspectName.associate(..)
		final ClassTypeDotId ctdi = nf.ClassTypeDotId(
				AssociateSymbolDecl_c.POS, cnpe, snp);
		final MethodConstructorPattern mcp = nf.MethodPattern(
				AssociateSymbolDecl_c.POS, Collections.EMPTY_LIST, tpe, ctdi,
				ddf, Collections.EMPTY_LIST);
		// Left pointcut for binary pointcut associate
		final Pointcut ascPL = nf.PCCall(AssociateSymbolDecl_c.POS, mcp);
		// Right pointcut for binary pointcut associate
		final Pointcut ascPR = nf.PCArgs(AssociateSymbolDecl_c.POS, argsRefs);
		// Binary pointcut with && operator for associate
		return nf.PCBinary(AssociateSymbolDecl_c.POS, ascPL, PCBinary.COND_AND,
				ascPR);
	}

	/**
	 * Generates a symbol advice with a custom warning. This is because in the
	 * case that the associate-symbol never matches, the warning should be
	 * saying that the relational aspect is never associated rather than that
	 * the symbol never matches.
	 */
	@Override
	public AdviceDecl generateSymbolAdvice(final TMNodeFactory nf,
			final List formals, final TypeNode voidn, final String tm_id,
			final Position tm_pos) {
		// Generate AdviceSpec
		final AdviceSpec spec = kind.generateAdviceSpec(nf, formals, voidn);

		// Generate an empty `throws' list
		final List tlist = new LinkedList();

		// Generate the TMAdviceDecl
		return ((RANodeFactory) nf).CustomWarningPerSymbolAdviceDecl(
				position(), Flags.NONE, spec, tlist, pc, body(nf, name, voidn),
				tm_id, this, tm_pos,
				CustomWarningPerSymbolAdviceDecl.REL_ASPECT);
	}

	/**
	 * Creates an <code>after returning($tmName$stateVarName)</code> or
	 * <code>after returning</code> advice kind
	 * 
	 * @param nf
	 *            node factory
	 * @param tracematch_name
	 *            name of the owning tracematch
	 * @param bindAspectInstanceInReturn
	 *            whether <code>$tmName$stateVarName</code> should be bound
	 * @return
	 */
	private static SymbolKind createKind(final TMNodeFactory nf,
			final String tracematch_name,
			final boolean bindAspectInstanceInReturn) {
		if (bindAspectInstanceInReturn) {
			return nf.AfterReturningSymbol(AssociateSymbolDecl_c.POS, nf.Local(
					AssociateSymbolDecl_c.POS, AssociateSymbolDecl_c
							.stateVariableName(tracematch_name)));
		} else {
			return nf.AfterReturningSymbol(AssociateSymbolDecl_c.POS);
		}
	}

	private static String stateVariableName(final String tracematch_name) {
		return TMFromRelTMDecl_c.stateVariableName(tracematch_name);
	}
}
