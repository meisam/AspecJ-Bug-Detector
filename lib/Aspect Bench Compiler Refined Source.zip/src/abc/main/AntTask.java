/* abc - The AspectBench Compiler
 * Copyright (C) 2004 Ondrej Lhotak
 *
 * This compiler is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This compiler is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this compiler, in the file LESSER-GPL;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

package abc.main;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.taskdefs.MatchingTask;
import org.apache.tools.ant.types.Path;
import org.apache.tools.ant.types.Reference;

/**
 * Ant abc task.
 * 
 * @author Ondrej Lhotak
 */
public class AntTask extends MatchingTask {
	public static final boolean DEBUG = false;

	public void setHelp(final boolean arg) {
		if (arg) {
			addArg("-help");
		}
	}

	public void setVersion(final boolean arg) {
		if (arg) {
			addArg("-version");
		}
	}

	public void setSourceroots(final Path path) {
		if (sourceroots == null) {
			sourceroots = new Path(getProject());
		}
		sourceroots = appendToPath(sourceroots, path);
	}

	public void setSourcepath(final Path path) {
		if (sourceroots == null) {
			sourceroots = new Path(getProject());
		}
		sourceroots = appendToPath(sourceroots, path);
		System.err.println("Warning: Sourcepath is unsupported, appending "
				+ path + " to sourceroots.");
	}

	public Path createSourceroots() {
		if (sourceroots == null) {
			sourceroots = new Path(getProject());
		}
		return sourceroots.createPath();
	}

	public void setInjars(final Path path) {
		if (injars == null) {
			injars = new Path(getProject());
		}
		injars = appendToPath(injars, path);
	}

	public void setInPath(final Path path) {
		if (inpath == null) {
			inpath = new Path(getProject());
		}
		inpath = appendToPath(inpath, path);
	}

	public Path createInjars() {
		if (injars == null) {
			injars = new Path(getProject());
		}
		return injars.createPath();
	}

	public void setClasspath(final Path path) {
		if (classpath == null) {
			classpath = new Path(getProject());
		}
		classpath = appendToPath(classpath, path);
	}

	public Path createClasspath() {
		if (classpath == null) {
			classpath = new Path(getProject());
		}
		return classpath.createPath();
	}

	public void setClasspathRef(final Reference ref) {
		createClasspath().setRefid(ref);
	}

	public void setDestdir(final File arg) {
		addArg("-d", arg.getAbsolutePath());
	}

	public void setO(final String arg) {
		addArg("-O" + arg);
	}

	public void setTime(final boolean arg) {
		if (arg) {
			addArg("-time");
		}
	}

	public void setXlint(final String arg) {
		addArg("-Xlint:" + arg);
	}

	public void setCompliance(final String arg) {
		addArg(arg);
	}

	public void setTarget(final String arg) {
		addArg("-target", arg);
	}

	public void setSource(final String arg) {
		addArg("-source", arg);
	}

	public void setNowarn(final boolean arg) {
		if (arg) {
			addArg("-nowarn");
		}
	}

	public void setWarn(final String arg) {
		addArg("-warn:" + arg);
	}

	public void setDebug(final boolean arg) {
		if (arg) {
			addArg("-g");
		}
	}

	public void setArgfiles(final Path arg) {
		if (argfiles == null) {
			argfiles = new Path(getProject());
		}
		argfiles = appendToPath(argfiles, arg);
	}

	public Path createArgfiles() {
		if (argfiles == null) {
			argfiles = new Path(getProject());
		}
		return argfiles.createPath();
	}

	public void setArgs(final String args) {
		final String[] list = args.split("[ \t]+");
		for (int i = 0; i < list.length; i++) {
			if (list[i].trim().length() > 0) {
				addArg(list[i].trim());
			}
		}
	}

	public void setOutjar(final File arg) {
		addArg("-outjar", arg.getAbsolutePath());
	}

	public void setSrcdir(final Path arg) {
		if (src == null) {
			src = new Path(getProject());
		}
		src = appendToPath(src, arg);
	}

	public Path createSrcdir() {
		return createSrc();
	}

	public Path createSrc() {
		if (src == null) {
			src = new Path(getProject());
		}
		return src.createPath();
	}

	private final List soots = new ArrayList();

	public Object createSoot() {
		final Object soot = new soot.AntTask();
		soots.add(soot);
		return soot;
	}

	public void setIncremental(final boolean arg) {
		if (arg) {
			throw new BuildException(
					"abc does not support incremental compilation of aspects.");
		}
	}

	public void setSourceRootCopyFilter(final String arg) {
		System.err
				.println("Warning: Ignoring unsupported option SourceRootCopyFilter.");
	}

	public void setDebuglevel(final String arg) {
		System.err.println("Warning: Ignoring unsupported option debuglevel.");
	}

	private final ArrayList args = new ArrayList();

	private void addArg(final String s) {
		args.add(s);
	}

	private void addArg(final String s, final String s2) {
		args.add(s);
		args.add(s2);
	}

	private Path sourceroots = null;
	private Path injars = null;
	private Path inpath = null;
	private Path classpath = null;
	private Path argfiles = null;
	private Path src = null;

	private Path appendToPath(final Path old, final Path newPath) {
		if (old == null) {
			return newPath;
		}
		old.append(newPath);
		return old;
	}

	@Override
	public void execute() throws BuildException {
		Debug.v().traceAntTask = true;
		// Debug.v().printWeavableClasses = true;
		try {
			if (sourceroots != null) {
				addPath("-sourceroots", sourceroots);
				if (Debug.v().traceAntTask) {
					System.err.println("sourceroots: " + sourceroots);
				}
			}
			if (injars != null) {
				addPath("-injars", injars);
				if (Debug.v().traceAntTask) {
					System.err.println("injars: " + injars);
				}
			}
			if (inpath != null) {
				addPath("-inpath", inpath);
				if (Debug.v().traceAntTask) {
					System.err.println("inpath: " + inpath);
				}
			}
			if (classpath != null) {
				addPath("-classpath", classpath);
				if (Debug.v().traceAntTask) {
					System.err.println("classpath: " + classpath);
				}
			}
			if (argfiles != null) {
				addArgfiles();
			}
			if (src != null) {
				addSrc();
			}
			for (final Iterator sootIt = soots.iterator(); sootIt.hasNext();) {
				final soot.AntTask soot = (soot.AntTask) sootIt.next();
				addArg("+soot");
				for (final Iterator argIt = soot.args().iterator(); argIt
						.hasNext();) {
					final String arg = (String) argIt.next();
					addArg(arg);
				}
				addArg("-soot");
			}
			if (AntTask.DEBUG) {
				System.out.println(args);
			}

			final Main main = new Main((String[]) args.toArray(new String[0]));
			main.run();
			Main.v().reset();
		} catch (final CompilerAbortedException e) {
			e.printStackTrace();
			throw new BuildException(e);
		} catch (final IllegalArgumentException e) {
			e.printStackTrace();
			System.out.println("Illegal arguments: " + e.getMessage());
			System.exit(1);
		} catch (final CompilerFailedException e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
			System.exit(5);
		} catch (final Exception e) {
			e.printStackTrace();
			throw new BuildException(e);
		}
		// Reset static state (necessary if the ant task is used several times
		// in the same ant run)
		abc.main.Main.resetStatic();
	}

	public void addPath(final String option, final Path path) {
		if (path.size() == 0) {
			return;
		}
		addArg(option);
		addArg(path.toString());
	}

	public void addArgfiles() {
		final String[] af = argfiles.list();
		if (Debug.v().traceAntTask) {
			System.err.print("argfiles: ");
		}

		for (int i = 0; i < af.length; i++) {
			addArg("@" + getProject().resolveFile(af[i]).getAbsolutePath());
			if (Debug.v().traceAntTask) {
				System.err.print("@"
						+ getProject().resolveFile(af[i]).getAbsolutePath()
						+ " ");
			}
		}
		if (Debug.v().traceAntTask) {
			System.err.println("");
		}
	}

	public void addSrc() {
		final String[] srcs = src.list();
		if (Debug.v().traceAntTask) {
			System.err.print("sources: ");
		}
		for (int i = 0; i < srcs.length; i++) {
			final File dir = getProject().resolveFile(srcs[i]);
			final String[] files = getDirectoryScanner(dir).getIncludedFiles();
			for (int j = 0; j < files.length; j++) {
				final File f = new File(dir, files[j]);
				if (files[j].endsWith(".java") || files[j].endsWith(".aj")) {
					addArg(f.getAbsolutePath());
					if (Debug.v().traceAntTask) {
						System.err.print(f.getAbsolutePath() + " ");
					}
				}
			}
		}
		if (Debug.v().traceAntTask) {
			System.err.println("");
		}
	}
}
