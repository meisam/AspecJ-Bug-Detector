/* abc - The AspectBench Compiler
 * Copyright (C) 2004 Laurie Hendren
 *
 * This compiler is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This compiler is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this compiler, in the file LESSER-GPL;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

package abc.main;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;

import polyglot.frontend.Pass;
import polyglot.frontend.Stats;

/**
 * Provide timing for Abc.
 * 
 * @author Laurie Hendren
 * @date May 24, 2004
 * 
 * This class provides basic timing infrastructure for abc. It has three main
 * parts, one for timing phases in abc, one for capturing and displaying times
 * from polyglot, and one for collecting the time spent in Soot Resolving.
 * 
 * To time the abc phases, an AbcTimer.start() call must be placed where timing
 * should start. Then AFTER each phase, use a AbcTimer.mark("Phasename"), to say
 * that this phase has ended. The time allocated to that phase will be from the
 * end of the previously marked phase to the time of executing this mark.
 * 
 * To get the polyglot timings a call to AbcTimer.storePolyglotStats and
 * AbcTimer.storePolyglotPasses must be put into the polyglot code. These give
 * the AbcTimer references to a list of Polyglot passes and a reference to the
 * Stats object containing the timing for each pass.
 * 
 * To collect the time for soot resolving, each call in the compiler to the soot
 * resolver must call abcTimer.addToSootResolve(long), with the time used for
 * that resolve as the param.
 * 
 * Timings may be printed out using AbcTimer.report(), which will print the
 * different sorts of timings, depending on the settings of the abcTimer,
 * polyglotTimer and sootResolverTimer flags in main.Debug.java.
 */

public class AbcTimer {

	private static long laststopped;

	private static long total;

	private static long sootresolve_total = 0;

	private static LinkedList history = new LinkedList();

	private static Stats polyglot_stats;

	private static ArrayList polyglot_passes = null;

	private static Thread reportThread;

	/** reset all static vars, for rerunning abc */
	public static void reset() {
		AbcTimer.sootresolve_total = 0;
		AbcTimer.total = 0;
		AbcTimer.history = new LinkedList();
		AbcTimer.polyglot_stats = null;
		AbcTimer.polyglot_passes = null;
	}

	/** store the polyglot passes so we can get times out in correct order */
	public static void storePolyglotPasses(final ArrayList l) {
		if (AbcTimer.polyglot_passes == null) {
			AbcTimer.polyglot_passes = l;
		}
	}

	/** keep a reference to the polyglot stats */
	public static void storePolyglotStats(final Stats stats) {
		AbcTimer.polyglot_stats = stats;
	}

	/** keep a total of all time spent in Soot resolving */
	public static void addToSootResolve(final long t) {
		AbcTimer.sootresolve_total += t;
	}

	/** Initialize the timer */
	public static void start() {
		AbcTimer.laststopped = System.currentTimeMillis();
	}

	/**
	 * Add a new phase to the history, name is phasename, time is time since
	 * last mark.
	 */
	public static void mark(final String phasename) {
		final long now = System.currentTimeMillis();
		final long phasetime = now - AbcTimer.laststopped;
		AbcTimer.history.add(new TimerPhase(phasename, phasetime));
		if (Debug.v().timerTrace) {
			System.err.println("Finished " + phasename + " in " + phasetime
					+ " millisec.");
		}
		AbcTimer.total += phasetime;
		AbcTimer.laststopped = now;
	}

	/**
	 * Compute percentage of total, make a string with two sig digits
	 */
	private static String percent(final long passtime) {
		final double percent = passtime * 100.0 / AbcTimer.total;
		final DecimalFormat percfmt = new DecimalFormat("00.000");
		return ("[ " + percfmt.format(percent) + "% ] ");
	}

	/**
	 * Spawns a thread printing the report any few milliseconds.
	 * 
	 * @param delayBetweenReports
	 *            the delay in milliseconds
	 * @author Eric Bodden
	 */
	public static void startReportInOwnThread(final long delayBetweenReports) {
		final Runnable r = new Runnable() {
			public void run() {
				while (true) {
					AbcTimer.report();
					long currentPhaseTime = System.currentTimeMillis()
							- AbcTimer.laststopped;
					System.err.println("Time elapsed since last phase:"
							+ currentPhaseTime);
					System.err
							.println("================================================");
					try {
						synchronized (this) {
							wait(delayBetweenReports);
						}
					} catch (InterruptedException e) {
					}
				}
			}
		};

		AbcTimer.reportThread = new Thread(r);
		AbcTimer.reportThread.start();
	}

	/**
	 * Stops the report thread if it is running.
	 * 
	 * @author Eric Bodden
	 */
	public static void stopReportInOwnThread() {
		if (AbcTimer.reportThread != null) {
			AbcTimer.reportThread.interrupt();
		}
	}

	/**
	 * Print out report of all phases timed so far. Debug.v().abcTimer must be
	 * set to true for report to be printed.
	 */
	public synchronized static void report() {
		if (Debug.v().abcTimer) {
			System.err
					.println("================================================");
			System.err.println("Breakdown of abc phases  (total: "
					+ AbcTimer.total + " millisec.)");
			System.err
					.println("------------------------------------------------");
			for (final Iterator i = AbcTimer.history.iterator(); i.hasNext();) {
				final TimerPhase next = (TimerPhase) i.next();
				final String name = next.name;
				final long time = next.time;
				System.err
						.println(AbcTimer.percent(time) + name + ":  " + time);
			}
			System.err
					.println("================================================");
		}
		if (Debug.v().polyglotTimer) {
			if (AbcTimer.polyglot_passes != null) {
				System.err
						.println("================================================");
				System.err.println("Breakdown for polyglot phases: ");
				System.err.println("-----------------------------  ");
				// Iterate through polyglot phases.
				long total = 0;
				for (final Iterator i = AbcTimer.polyglot_passes.iterator(); i
						.hasNext();) {
					final Pass pass = (Pass) i.next();
					final Pass.ID id = pass.id();
					final String name = pass.name();
					final long inclusive_time = AbcTimer.polyglot_stats
							.passTime(id, true);
					total += inclusive_time;
					// final long exclusive_time =
					AbcTimer.polyglot_stats.passTime(id, false);
					System.err.println(AbcTimer.percent(inclusive_time) + name
							+ ":  " + inclusive_time);
				}
				System.err
						.println(AbcTimer.percent(total) + "ALL  :  " + total);
				System.err
						.println("================================================");
			}
		}
		if (Debug.v().sootResolverTimer) {
			System.err
					.println("================================================");
			System.err.println("Time spent in Soot resolver: "
					+ AbcTimer.sootresolve_total);
			System.err
					.println("================================================");
		}
	}

} // AbcTimer

class TimerPhase {
	String name;
	long time;

	TimerPhase(final String name, final long time) {
		this.name = name;
		this.time = time;
	}

	@Override
	public String toString() {
		return (name + ": " + time + "\n");
	}

} // TimerPhase
