/*
 *  $Id: AbstractGraphTest.java,v 1.3 2005/10/03 15:30:14 rconner Exp $
 *
 *  Copyright (C) 1994-2005 by Phoenix Software Technologists,
 *  Inc. and others.  All rights reserved.
 *
 *  THIS PROGRAM AND DOCUMENTATION IS PROVIDED UNDER THE TERMS OF THE
 *  COMMON PUBLIC LICENSE ("AGREEMENT") WHICH ACCOMPANIES IT.  ANY
 *  USE, REPRODUCTION OR DISTRIBUTION OF THE PROGRAM CONSTITUTES
 *  RECIPIENT'S ACCEPTANCE OF THE AGREEMENT.
 *
 *  The license text can also be found at
 *    http://opensource.org/licenses/cpl.php
 */

package com.phoenixst.plexus;

import java.io.*;
import java.util.*;

import org.apache.commons.collections.*;

import com.phoenixst.collections.OrderedPair;
import com.phoenixst.junit.AbstractCloneableTestCase;


/**
 *  A {@link Graph} tester.
 *
 *  @version    $Revision: 1.3 $
 *  @author     Ray A. Conner
 *
 *  @since      1.0
 */
public abstract class AbstractGraphTest extends AbstractCloneableTestCase
{

    protected static final String SHOULD_THROW_MESSAGE = "Should throw an Exception.";

    protected static final String SHOULD_THROW_NO_SUCH_ELEMENT_MESSAGE = "Should throw a NoSuchElementException.";

    protected static final String SHOULD_THROW_ILLEGAL_ARGUMENT_MESSAGE = "Should throw IllegalArgumentException.";

    /**
     *  Everything but directed in.
     */
    protected static final int DIR_MASK = GraphUtils.UNDIRECTED_MASK | GraphUtils.DIRECTED_OUT_MASK;

    /**
     *  The <code>Graph</code> to be tested.
     */
    protected Graph g;

    /**
     *  Contains all nodes accessed by the graph's
     *  <code>nodes( null ).iterator()</code> method.
     */
    private Set nodes = null;

    /**
     *  Contains all edges accessed by the graph's
     *  <code>edges( null ).iterator()</code> method.
     */
    private Set realEdges = null;

    /**
     *  Contains <code>SimpleObjectEdges</code> corresponding to all
     *  edges accessed by the graph's <code>edges( null ).iterator()</code>
     *  method.
     */
    private Set testEdges = null;


    /**
     *
     */
    protected Object[] presentNodes;

    /**
     *
     */
    protected Object[] notPresentNodes;

    /**
     *
     */
    protected Graph.Edge[] presentEdges;

    /**
     *
     */
    protected Graph.Edge[] notPresentEdges;


    ////////////////////////////////////////
    // Constructor
    ////////////////////////////////////////


    protected AbstractGraphTest()
    {
        super();
    }


    ////////////////////////////////////////
    // Fixture method
    ////////////////////////////////////////


    protected void setUp( Graph graph )
    {
        g = graph;

        nodes = new HashSet();
        Iterator nodeIter = g.nodes( null ).iterator();
        while( nodeIter.hasNext() ) {
            nodes.add( nodeIter.next() );
        }

        realEdges = new HashSet();
        testEdges = new HashSet();
        Iterator edgeIter = g.edges( null ).iterator();
        while( edgeIter.hasNext() ) {
            Graph.Edge edge = (Graph.Edge) edgeIter.next();
            realEdges.add( edge );
            testEdges.add( new SimpleObjectEdge( g,
                                                 edge.getUserObject(),
                                                 edge.getTail(), edge.getHead(),
                                                 edge.isDirected() ) );
        }

        presentNodes = new Object[] {};
        notPresentNodes = new Object[] {};
        presentEdges = new Graph.Edge[] {};
        notPresentEdges = new Graph.Edge[] {};
    }


    ////////////////////////////////////////
    // Protected helper methods and stuff
    ////////////////////////////////////////


    protected boolean isSelfEdge( Graph.Edge edge )
    {
        Object tail = edge.getTail();
        Object head = edge.getHead();
        return (tail == null) ? head == null : tail.equals( head );
    }


    protected void createPresentNodeRanges( int limit )
    {
        presentNodes = new Object[ limit ];
        for( int i = 0; i < limit; i++ ) {
            presentNodes[i] = new Integer( i );
        }
        notPresentNodes = new Object[] { null,
                                         new Object(),
                                         new Integer( -1 ),
                                         new Integer( limit ) };
    }


    protected void createPresentNodeRanges( int limitA, int limitB )
    {
        presentNodes = new Object[ limitA * limitB ];
        for( int i = 0; i < limitA; i++ ) {
            for( int j = 0; j < limitB; j++ ) {
                presentNodes[i * limitB + j] = new OrderedIntPair( i, j );
            }
        }

        notPresentNodes = new Object[] { null,
                                         new Object(),
                                         new OrderedIntPair( -1, 0 ),
                                         new OrderedIntPair( 0, -1 ),
                                         new OrderedIntPair( limitA, 0 ),
                                         new OrderedIntPair( limitA - 1, -1 ),
                                         new OrderedIntPair( 0, limitB ),
                                         new OrderedIntPair( -1, limitB - 1 ),
                                         new OrderedIntPair( limitA - 1, limitB ),
                                         new OrderedIntPair( limitA, limitB - 1 ) };
    }


    protected void createEdgeArrays( int limit, Predicate pred )
    {
        Set goodEdges = new HashSet();
        Set badEdges = new HashSet();

        for( int tailIndex = 0; tailIndex < limit; tailIndex++ ) {
            Object tail = new Integer( tailIndex );
            for( int headIndex = 0; headIndex < limit; headIndex++ ) {
                Object head = new Integer( headIndex );
                Graph.Edge edge = new SimpleObjectEdge( g, null, tail, head, false );
                if( pred.evaluate( edge ) ) {
                    goodEdges.add( edge );
                } else {
                    badEdges.add( edge );
                }
                edge = new SimpleObjectEdge( g, null, tail, head, true );
                if( pred.evaluate( edge ) ) {
                    goodEdges.add( edge );
                } else {
                    badEdges.add( edge );
                }
            }
        }

        presentEdges = createEdgeArray( goodEdges );
        notPresentEdges = createEdgeArray( badEdges );
    }


    protected void createEdgeArrays( int limitA, int limitB, Predicate pred )
    {
        Set goodEdges = new HashSet();
        Set badEdges = new HashSet();

        for( int tailA = 0; tailA < limitA; tailA++ ) {
            for( int tailB = 0; tailB < limitB; tailB++ ) {
                Object tail = new OrderedIntPair( tailA, tailB );
                for( int headA = 0; headA < limitA; headA++ ) {
                    for( int headB = 0; headB < limitB; headB++ ) {
                        Object head = new OrderedIntPair( headA, headB );
                        Graph.Edge edge = new SimpleObjectEdge( g, null, tail, head, false );
                        if( pred.evaluate( edge ) ) {
                            goodEdges.add( edge );
                        } else {
                            badEdges.add( edge );
                        }
                        edge = new SimpleObjectEdge( g, null, tail, head, true );
                        if( pred.evaluate( edge ) ) {
                            goodEdges.add( edge );
                        } else {
                            badEdges.add( edge );
                        }
                    }
                }
            }
        }

        presentEdges = createEdgeArray( goodEdges );
        notPresentEdges = createEdgeArray( badEdges );
    }


    protected Graph.Edge[] createEdgeArray( Collection edges )
    {
        Graph.Edge[] edgeArray = new Graph.Edge[ edges.size() ];
        edges.toArray( edgeArray );
        return edgeArray;
    }


    protected void testEdge( Graph.Edge edge, Object tail, Object head )
    {
        Object edgeTail = edge.getTail();
        Object edgeHead = edge.getHead();

        // Check that the edge endpoints are in the graph.
        assertTrue( g.containsNode( edgeTail ) );
        assertTrue( g.containsNode( edgeHead ) );
        assertTrue( nodes.contains( edgeTail ) );
        assertTrue( nodes.contains( edgeHead ) );

        // Check that the edge, actually goes from tail to head.
        if( edge.isDirected() ) {
            assertEquals( tail, edgeTail );
            assertEquals( head, edgeHead );
        } else {
            if( (tail == null) ? (edgeTail == null) : tail.equals( edgeTail ) ) {
                assertEquals( head, edgeHead );
            } else {
                assertEquals( tail, edgeHead );
                assertEquals( head, edgeTail );
            }
        }

        // Check that the edge is accessed by the edge iterator.
        assertTrue( realEdges.contains( edge ) );
        assertTrue( testEdges.contains( new SimpleObjectEdge( g,
                                                              edge.getUserObject(),
                                                              tail, head,
                                                              edge.isDirected() ) ) );

        // Check that getOtherEndpoint() works.
        assertEquals( tail, edge.getOtherEndpoint( head ) );
        assertEquals( head, edge.getOtherEndpoint( tail ) );

        for( int i = 0; i < notPresentNodes.length; i++ ) {
            try {
                edge.getOtherEndpoint( notPresentNodes[i] );
                fail( SHOULD_THROW_ILLEGAL_ARGUMENT_MESSAGE );
            } catch( IllegalArgumentException e ) {
                // Do nothing
            }
        }
    }


    protected void testNotPresentNodes( Closure closure )
    {
        // Check that using nodes not present in the graph throws an
        // exception.
        for( int i = 0; i < notPresentNodes.length; i++ ) {
            try {
                closure.execute( notPresentNodes[i] );
                fail( SHOULD_THROW_MESSAGE );
            } catch( ClassCastException e ) {
                // Do nothing
            } catch( IllegalArgumentException e ) {
                // Do nothing
            } catch( NoSuchNodeException e ) {
                // Do nothing
            } catch( NullPointerException e ) {
                // Do nothing
            }
        }
    }


    protected void testNotPresentNodes( BinaryClosure bClosure )
    {
        // Check that using nodes not present in the graph throws an
        // exception.
        for( int i = 0; i < notPresentNodes.length; i++ ) {
            for( int j = 0; j < presentNodes.length; j++ ) {
                try {
                    bClosure.execute( notPresentNodes[i], presentNodes[j] );
                    fail( SHOULD_THROW_MESSAGE );
                } catch( ClassCastException e ) {
                    // Do nothing
                } catch( IllegalArgumentException e ) {
                    // Do nothing
                } catch( NoSuchNodeException e ) {
                    // Do nothing
                }
                try {
                    bClosure.execute( presentNodes[j], notPresentNodes[i] );
                    fail( SHOULD_THROW_MESSAGE );
                } catch( ClassCastException e ) {
                    // Do nothing
                } catch( IllegalArgumentException e ) {
                    // Do nothing
                } catch( NoSuchNodeException e ) {
                    // Do nothing
                }
            }
            for( int j = 0; j < notPresentNodes.length; j++ ) {
                try {
                    bClosure.execute( notPresentNodes[i], notPresentNodes[j] );
                    fail( SHOULD_THROW_MESSAGE );
                } catch( ClassCastException e ) {
                    // Do nothing
                } catch( IllegalArgumentException e ) {
                    // Do nothing
                } catch( NoSuchNodeException e ) {
                    // Do nothing
                }
            }
        }
    }


    ////////////////////////////////////////
    // Public test methods
    ////////////////////////////////////////


    public void testNodeSize()
    {
        assertEquals( nodes.size(), g.nodes( null ).size() );
    }


    public void testEdgeSize()
    {
        assertEquals( realEdges.size(), g.edges( null ).size() );
    }


    public void testDegree()
    {
        // Check that the degree of a node is the same as the number
        // of edges accessed by the traverser.

        Iterator nodeIter = g.nodes( null ).iterator();
        while( nodeIter.hasNext() ) {
            Object node = nodeIter.next();
            int count;
            Traverser t = g.traverser( node, null );
            for( count = 0; t.hasNext(); count++ ) {
                Object adjNode = t.next();
                if( (node == null) ? (adjNode == null) : node.equals( adjNode ) ) {
                    count++;
                }
            }
            assertEquals( count, g.degree( node ) );
        }

        testNotPresentNodes( new Closure()
            { public void execute( Object object ) { g.degree( object ); } } );
    }


    public void testOutDegree()
    {
        // Check that the out-degree of a node is the same as the
        // number of edges accessed by the out-traverser.
        Iterator nodeIter = g.nodes( null ).iterator();
        while( nodeIter.hasNext() ) {
            Object node = nodeIter.next();
            int count;
            Traverser t = g.traverser( node, GraphUtils.OUT_TRAVERSER_PREDICATE );
            for( count = 0; t.hasNext(); count++ ) {
                t.next();
            }
            assertEquals( count, g.degree( node, GraphUtils.OUT_TRAVERSER_PREDICATE ) );
        }

        testNotPresentNodes( new Closure()
            { public void execute( Object object ) { g.degree( object, GraphUtils.OUT_TRAVERSER_PREDICATE ); } } );
    }


    public void testInDegree()
    {
        // Check that the in-degree of a node is the same as the
        // number of edges accessed by the in-traverser.
        Iterator nodeIter = g.nodes( null ).iterator();
        while( nodeIter.hasNext() ) {
            Object node = nodeIter.next();
            int count;
            Traverser t = g.traverser( node, GraphUtils.IN_TRAVERSER_PREDICATE );
            for( count = 0; t.hasNext(); count++ ) {
                t.next();
            }
            assertEquals( count, g.degree( node, GraphUtils.IN_TRAVERSER_PREDICATE ) );
        }

        testNotPresentNodes( new Closure()
            { public void execute( Object object ) { g.degree( object, GraphUtils.IN_TRAVERSER_PREDICATE ); } } );
    }


    public void testContainsNode()
    {
        // Check that every node accessed by the node iterator is
        // present in the graph.
        Iterator nodeIter = g.nodes( null ).iterator();
        while( nodeIter.hasNext() ) {
            assertTrue( g.containsNode( nodeIter.next() ) );
        }

        // Check for supposedly present and not present nodes.
        for( int i = 0; i < presentNodes.length; i++ ) {
            assertTrue( g.containsNode( presentNodes[i] ) );
        }
        for( int i = 0; i < notPresentNodes.length; i++ ) {
            assertFalse( g.containsNode( notPresentNodes[i] ) );
        }
    }


    public void testContainsEdge()
    {
        // Check that every edge accessed by the edge iterator is
        // present in the graph.
        Iterator edgeIter = g.edges( null ).iterator();
        while( edgeIter.hasNext() ) {
            assertTrue( g.containsEdge( (Graph.Edge) edgeIter.next() ) );
        }
    }


    public void testGetEdge()
    {
        // Check an edge for each pair of nodes.
        Iterator tailIter = g.nodes( null ).iterator();
        while( tailIter.hasNext() ) {
            Object tail = tailIter.next();
            Iterator headIter = g.nodes( null ).iterator();
            while( headIter.hasNext() ) {
                Object head = headIter.next();
                Predicate edgePred = EdgePredicateFactory.createEqualsNodes( tail, head, DIR_MASK );
                Graph.Edge edge = g.getEdge( edgePred );
                if( edge != null ) {
                    testEdge( edge, tail, head );
                }
            }
        }

        // Check for supposedly present and not present edges.
        for( int i = 0; i < presentEdges.length; i++ ) {
            Graph.Edge edge = presentEdges[i];
            Predicate edgePred = EdgePredicateFactory.create( edge );
            assertNotNull( g.getEdge( edgePred ) );
        }
        for( int i = 0; i < notPresentEdges.length; i++ ) {
            Graph.Edge edge = notPresentEdges[i];
            Predicate edgePred = EdgePredicateFactory.create( edge );
            assertNull( g.getEdge( edgePred ) );
        }
    }


    public void testNodeIterator()
    {
        for( int i = 0; i < presentNodes.length; i++ ) {
            assertTrue( nodes.contains( presentNodes[i] ) );
        }
        for( int i = 0; i < notPresentNodes.length; i++ ) {
            assertFalse( nodes.contains( notPresentNodes[i] ) );
        }

        Iterator nodeIter = g.nodes( null ).iterator();
        int count;
        for( count = 0; nodeIter.hasNext(); count++ ) {
            nodeIter.next();
        }
        try {
            nodeIter.next();
            fail( SHOULD_THROW_NO_SUCH_ELEMENT_MESSAGE );
        } catch( NoSuchElementException e ) {
            // Do nothing
        }

        assertEquals( count, nodes.size() );
    }


    public void testEdgeIterator()
    {
        for( int i = 0; i < presentEdges.length; i++ ) {
            Graph.Edge edge = presentEdges[i];
            assertTrue( testEdges.contains( new SimpleObjectEdge( g,
                                                                  edge.getUserObject(),
                                                                  edge.getTail(), edge.getHead(),
                                                                  edge.isDirected() ) ) );

        }
        for( int i = 0; i < notPresentEdges.length; i++ ) {
            Graph.Edge edge = notPresentEdges[i];
            assertFalse( testEdges.contains( new SimpleObjectEdge( g,
                                                                   edge.getUserObject(),
                                                                   edge.getTail(), edge.getHead(),
                                                                   edge.isDirected() ) ) );
        }

        Iterator edgeIter = g.edges( null ).iterator();
        int count;
        for( count = 0; edgeIter.hasNext(); count++ ) {
            Graph.Edge edge = (Graph.Edge) edgeIter.next();
            testEdge( edge, edge.getTail(), edge.getHead() );
        }
        try {
            edgeIter.next();
            fail( SHOULD_THROW_NO_SUCH_ELEMENT_MESSAGE );
        } catch( NoSuchElementException e ) {
            // Do nothing
        }

        assertEquals( count, realEdges.size() );
    }


    public void testEdgeIterator2()
    {
        int totalCount = 0;
        int selfCount = 0;
        Iterator tailIter = g.nodes( null ).iterator();
        while( tailIter.hasNext() ) {
            Object tail = tailIter.next();
            Iterator headIter = g.nodes( null ).iterator();
            while( headIter.hasNext() ) {
                Object head = headIter.next();
                Predicate edgePred = EdgePredicateFactory.createEqualsNodes( tail, head, DIR_MASK );
                Iterator edgeIter = g.edges( edgePred ).iterator();
                if( edgeIter.hasNext() ) {
                    assertNotNull( g.getEdge( edgePred ) );
                } else {
                    assertNull( g.getEdge( edgePred ) );
                }
                while( edgeIter.hasNext() ) {
                    Graph.Edge edge = (Graph.Edge) edgeIter.next();
                    if( isSelfEdge( edge ) ) {
                        selfCount++;
                    }
                    testEdge( edge, tail, head );
                    totalCount++;
                    if( edge.isDirected() ) {
                        // Make sure we get it twice since all
                        // undirected edges will be.
                        totalCount++;
                    }
                }
                try {
                    edgeIter.next();
                    fail( SHOULD_THROW_NO_SUCH_ELEMENT_MESSAGE );
                } catch( NoSuchElementException e ) {
                    // Do nothing
                }
            }
        }

        assertEquals( totalCount + selfCount, 2 * realEdges.size() );

        // Check for supposedly present and not present edges.
        for( int i = 0; i < presentEdges.length; i++ ) {
            Graph.Edge edge = presentEdges[i];
            Predicate edgePred = EdgePredicateFactory.create( edge );
            Iterator edgeIter = g.edges( edgePred ).iterator();
            assertTrue( edgeIter.hasNext() );
            assertNotNull( edgeIter.next() );
        }
        for( int i = 0; i < notPresentEdges.length; i++ ) {
            Graph.Edge edge = notPresentEdges[i];
            Predicate edgePred = EdgePredicateFactory.create( edge );
            Iterator edgeIter = g.edges( edgePred ).iterator();
            assertFalse( edgeIter.hasNext() );
        }
    }


    public void testTraverser()
    {
        int totalCount = 0;
        int selfCount = 0;
        HashSet edges = new HashSet();
        Iterator nodeIter = g.nodes( null ).iterator();
        while( nodeIter.hasNext() ) {
            Object node = nodeIter.next();
            Traverser t = g.traverser( node, null );

            edges.clear();
            int count;
            for( count = 0; t.hasNext(); count++, totalCount++ ) {

                Object adjNode = t.next();

                // Check that the adjacent node is in the graph.
                assertTrue( g.containsNode( adjNode ) );
                assertTrue( nodes.contains( adjNode ) );

                Graph.Edge edge = t.getEdge();
                if( isSelfEdge( edge ) ) {
                    selfCount++;
                }
                edges.add( edge );
                Object tail = edge.getTail();
                if( (node == null) ? (tail == null) : node.equals( tail ) ) {
                    testEdge( edge, node, adjNode );
                } else {
                    testEdge( edge, adjNode, node );
                }
            }
            try {
                t.next();
                fail( SHOULD_THROW_NO_SUCH_ELEMENT_MESSAGE );
            } catch( NoSuchElementException e ) {
                // Do nothing
            }

            // Check that each edge accessed by the traverser is unique.
            assertEquals( count, edges.size() );
        }

        assertEquals( totalCount + selfCount, 2 * realEdges.size() );

        testNotPresentNodes( new Closure()
            { public void execute( Object object ) { g.traverser( object, null ); } } );
    }


    public void testOutTraverser()
    {
        HashSet edges = new HashSet();
        Iterator nodeIter = g.nodes( null ).iterator();
        while( nodeIter.hasNext() ) {
            Object node = nodeIter.next();
            Traverser t = g.traverser( node, GraphUtils.OUT_TRAVERSER_PREDICATE );

            edges.clear();
            int count;
            for( count = 0; t.hasNext(); count++ ) {

                Object adjNode = t.next();

                // Check that the adjacent node is in the graph.
                assertTrue( g.containsNode( adjNode ) );
                assertTrue( nodes.contains( adjNode ) );

                Graph.Edge edge = t.getEdge();
                edges.add( edge );
                testEdge( edge, node, adjNode );
            }
            try {
                t.next();
                fail( SHOULD_THROW_NO_SUCH_ELEMENT_MESSAGE );
            } catch( NoSuchElementException e ) {
                // Do nothing
            }

            // Check that each edge accessed by the traverser is unique.
            assertEquals( count, edges.size() );
        }

        testNotPresentNodes( new Closure()
            { public void execute( Object object ) { g.traverser( object, GraphUtils.OUT_TRAVERSER_PREDICATE ); } } );
    }


    public void testInTraverser()
    {
        HashSet edges = new HashSet();
        Iterator nodeIter = g.nodes( null ).iterator();
        while( nodeIter.hasNext() ) {
            Object node = nodeIter.next();
            Traverser t = g.traverser( node, GraphUtils.IN_TRAVERSER_PREDICATE );

            edges.clear();
            int count;
            for( count = 0; t.hasNext(); count++ ) {

                Object adjNode = t.next();

                // Check that the adjacent node is in the graph.
                assertTrue( g.containsNode( adjNode ) );
                assertTrue( nodes.contains( adjNode ) );

                Graph.Edge edge = t.getEdge();
                edges.add( edge );
                testEdge( edge, adjNode, node );
            }
            try {
                t.next();
                fail( SHOULD_THROW_NO_SUCH_ELEMENT_MESSAGE );
            } catch( NoSuchElementException e ) {
                // Do nothing
            }

            // Check that each edge accessed by the traverser is unique.
            assertEquals( count, edges.size() );
        }

        testNotPresentNodes( new Closure()
            { public void execute( Object object ) { g.traverser( object, GraphUtils.IN_TRAVERSER_PREDICATE ); } } );
    }


    public void testSerialization()
        throws IOException
    {
        ByteArrayOutputStream bos = new ByteArrayOutputStream( 2048 );
        ObjectOutputStream out = new ObjectOutputStream( bos );
        out.writeObject( g );
        bos.toByteArray();
        out.close();
    }


    ////////////////////////////////////////
    // Protected classes and interfaces
    ////////////////////////////////////////


    protected interface BinaryClosure
    {
        public void execute( Object a, Object b );
    }


    protected static class OrderedIntPair extends OrderedPair
    {
        private static final long serialVersionUID = 1L;

        public OrderedIntPair( int first, int second )
        {
            super( new Integer( first ), new Integer( second ) );
        }
    }

}
