/*
 *  $Id: StaticGraphTest.java,v 1.11 2005/10/03 15:30:14 rconner Exp $
 *
 *  Copyright (C) 1994-2005 by Phoenix Software Technologists,
 *  Inc. and others.  All rights reserved.
 *
 *  THIS PROGRAM AND DOCUMENTATION IS PROVIDED UNDER THE TERMS OF THE
 *  COMMON PUBLIC LICENSE ("AGREEMENT") WHICH ACCOMPANIES IT.  ANY
 *  USE, REPRODUCTION OR DISTRIBUTION OF THE PROGRAM CONSTITUTES
 *  RECIPIENT'S ACCEPTANCE OF THE AGREEMENT.
 *
 *  The license text can also be found at
 *    http://opensource.org/licenses/cpl.php
 */

package com.phoenixst.plexus;

import junit.framework.Test;


/**
 *  A {@link Graph} tester which uses a single static graph, mostly
 *  for ease of use when testing with beanshell.
 *
 *  @version    $Revision: 1.11 $
 *  @author     Ray A. Conner
 *
 *  @since      1.0
 */
public class StaticGraphTest
{

    private static Graph staticGraph = null;


    private StaticGraphTest()
    {
        super();
    }


    public static Graph getGraph()
    {
        return staticGraph;
    }


    public static void setGraph( Graph graph )
    {
        staticGraph = graph;
    }


    public static Test suite()
    {
        String suiteName;
        if( staticGraph instanceof DefaultGraph ) {
            suiteName = "";
        } else {
            suiteName = staticGraph.toString();
        }
        return DefaultGraphTest.suite( staticGraph, suiteName );
    }

}
