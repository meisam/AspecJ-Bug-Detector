/*
 *  $Id: SimpleObjectEdge.java,v 1.13 2005/10/03 15:30:14 rconner Exp $
 *
 *  Copyright (C) 1994-2005 by Phoenix Software Technologists,
 *  Inc. and others.  All rights reserved.
 *
 *  THIS PROGRAM AND DOCUMENTATION IS PROVIDED UNDER THE TERMS OF THE
 *  COMMON PUBLIC LICENSE ("AGREEMENT") WHICH ACCOMPANIES IT.  ANY
 *  USE, REPRODUCTION OR DISTRIBUTION OF THE PROGRAM CONSTITUTES
 *  RECIPIENT'S ACCEPTANCE OF THE AGREEMENT.
 *
 *  The license text can also be found at
 *    http://opensource.org/licenses/cpl.php
 */

package com.phoenixst.plexus;

import com.phoenixst.plexus.util.DefaultObjectEdge;


/**
 *  An <code>Edge</code> which defines {@link #equals(Object) equals(
 *  Object )} differently for testing purposes.  Because of how {@link
 *  #equals(Object) equals( Object )} is defined, instances of this
 *  class may only be used by multigraphs when the endpoints and
 *  contained user-defined object are sufficient to distinguish
 *  distinct edges.
 *
 *  @version    $Revision: 1.13 $
 *  @author     Ray A. Conner
 *
 *  @since      1.0
 */
public class SimpleObjectEdge extends DefaultObjectEdge
{

    private static final long serialVersionUID = 2L;

    /**
     *  The graph which created this <code>Edge</code>.
     *
     *  @serial
     */
    private final Graph graph;


    ////////////////////////////////////////
    // Constructor
    ////////////////////////////////////////


    /**
     *  Creates a new <code>SimpleObjectEdge</code>.
     */
    public SimpleObjectEdge( Graph graph,
                             Object object,
                             Object tail, Object head,
                             boolean directed )
    {
        super( object, tail, head, directed );
        this.graph = graph;
    }


    ////////////////////////////////////////
    // Other methods
    ////////////////////////////////////////


    /**
     *  Two <code>SimpleObjectEdges</code> are equal if they have the
     *  same directedness, are from the exact same graph (using
     *  <code>==</code>), have equal endpoints, and contain the same
     *  user-defined object.
     */
    public boolean equals( Object object )
    {
        if( !(object instanceof SimpleObjectEdge) ) {
            return false;
        }
        SimpleObjectEdge edge = (SimpleObjectEdge) object;
        if( isDirected() ) {
            return edge.isDirected()
                && graph == edge.graph
                && GraphUtils.equals( getUserObject(), edge.getUserObject() )
                && GraphUtils.equals( getTail(), edge.getTail() )
                && GraphUtils.equals( getHead(), edge.getHead() );
        }
        return !edge.isDirected()
            && graph == edge.graph
            && GraphUtils.equals( getUserObject(), edge.getUserObject() )
            && ( (GraphUtils.equals( getTail(), edge.getTail() ) && GraphUtils.equals( getHead(), edge.getHead() ))
                || (GraphUtils.equals( getTail(), edge.getHead() ) && GraphUtils.equals( getHead(), edge.getTail() )) );
    }


    public int hashCode()
    {
        Object tail = getTail();
        Object head = getHead();
        Object object = getUserObject();
        return ((tail == null) ? 0 : tail.hashCode())
            ^ ((head == null) ? 0 : head.hashCode())
            ^ ((object == null) ? 0 : object.hashCode());
    }

}
