/*
 *  $Id: GraphPrinter.java,v 1.16 2005/10/03 15:30:14 rconner Exp $
 *
 *  Copyright (C) 1994-2005 by Phoenix Software Technologists,
 *  Inc. and others.  All rights reserved.
 *
 *  THIS PROGRAM AND DOCUMENTATION IS PROVIDED UNDER THE TERMS OF THE
 *  COMMON PUBLIC LICENSE ("AGREEMENT") WHICH ACCOMPANIES IT.  ANY
 *  USE, REPRODUCTION OR DISTRIBUTION OF THE PROGRAM CONSTITUTES
 *  RECIPIENT'S ACCEPTANCE OF THE AGREEMENT.
 *
 *  The license text can also be found at
 *    http://opensource.org/licenses/cpl.php
 */

package com.phoenixst.plexus;

import java.io.PrintStream;
import java.util.Iterator;

import com.phoenixst.plexus.examples.*;


/**
 *  A {@link Graph} printing utility.
 *
 *  @version    $Revision: 1.16 $
 *  @author     Ray A. Conner
 *
 *  @since      1.0
 */
public class GraphPrinter
{

    private GraphPrinter()
    {
        super();
    }

    public static void printNode( PrintStream out, Graph graph, Object node )
    {
        out.println( "Node " + node );

        out.println( "  Adj = " + graph.degree( node ) );
        Traverser t = graph.traverser( node, null );
        while( t.hasNext() ) {
            Object adj = t.next();
            Graph.Edge edge = t.getEdge();
            if( edge.isDirected() ) {
                if( GraphUtils.equals( node, edge.getTail() ) ) {
                    out.println( "    " + node + " -- " + edge.getUserObject() + " -> " + adj );
                } else {
                    out.println( "    " + node + " <- " + edge.getUserObject() + " -- " + adj );
                }
            } else {
                out.println( "    " + node + " -- " + edge.getUserObject() + " -- " + adj );
            }
        }
    }


    public static void printEdge( PrintStream out, Graph.Edge edge )
    {
        Object object = edge.getUserObject();
        Object tail = edge.getTail();
        Object head = edge.getHead();
        if( edge.isDirected() ) {
            out.println( "  " + tail + " -- " + object + " -> " + head );
        } else {
            out.println( "  " + tail + " -- " + object + " -- " + head );
        }
    }


    public static void printGraph( PrintStream out, String msg, Graph graph )
    {
        out.println( "\n" + msg );
        out.println( "Graph = " + graph );
        out.println( "#nodes = " + graph.nodes( null ).size() );
        out.println( "#edges = " + graph.edges( null ).size() );

        out.println( "\nNodes:" );
        for( Iterator i = graph.nodes( null ).iterator(); i.hasNext(); ) {
            printNode( out, graph, i.next() );
        }

        out.println( "\nEdges:" );
        for( Iterator i = graph.edges( null ).iterator(); i.hasNext(); ) {
            printEdge( out, (Graph.Edge) i.next() );
        }
    }


    public static void printGraph( String msg, Graph graph )
    {
        printGraph( System.out, msg, graph );
    }


    public static void printStandardGraphs()
    {
        printGraph( "", new EmptyGraph( 4 ) );
        printGraph( "EmptyGraph", new DefaultGraph( new EmptyGraph( 4 ) ) );

        printGraph( "", new Path( 4 ) );
        printGraph( "Path", new DefaultGraph( new Path( 4 ) ) );

        printGraph( "", new Cycle( 4 ) );
        printGraph( "Cycle", new DefaultGraph( new Cycle( 4 ) ) );

        printGraph( "", new CompleteGraph( 4 ) );
        printGraph( "CompleteGraph", new DefaultGraph( new CompleteGraph( 4 ) ) );

        printGraph( "", new CompleteTree( 2, 3 ) );
        printGraph( "CompleteTree", new DefaultGraph( new CompleteTree( 2, 3 ) ) );

        printGraph( "", new CompleteBipartiteGraph( 3, 2 ) );
        printGraph( "CompleteBipartiteGraph", new DefaultGraph( new CompleteBipartiteGraph( 3, 2 ) ) );

        printGraph( "", new Star( 5 ) );
        printGraph( "Star", new DefaultGraph( new Star( 5 ) ) );

        printGraph( "", new Wheel( 5 ) );
        printGraph( "Wheel", new DefaultGraph( new Wheel( 5 ) ) );

        printGraph( "", new PlanarMesh( 3, 3 ) );
        printGraph( "PlanarMesh", new DefaultGraph( new PlanarMesh( 3, 3 ) ) );

        printGraph( "", new Prism( 3, 3 ) );
        printGraph( "Prism", new DefaultGraph( new Prism( 3, 3 ) ) );

        printGraph( "", new ToroidalMesh( 3, 3 ) );
        printGraph( "ToroidalMesh", new DefaultGraph( new ToroidalMesh( 3, 3 ) ) );

        printGraph( "Petersen", PetersenGraph.INSTANCE );
    }


    public static void main( String[] args )
    {
        printStandardGraphs();
    }

}
