/*
 *  $Id: DefaultGraphTest.java,v 1.14 2005/10/03 15:30:14 rconner Exp $
 *
 *  Copyright (C) 1994-2005 by Phoenix Software Technologists,
 *  Inc. and others.  All rights reserved.
 *
 *  THIS PROGRAM AND DOCUMENTATION IS PROVIDED UNDER THE TERMS OF THE
 *  COMMON PUBLIC LICENSE ("AGREEMENT") WHICH ACCOMPANIES IT.  ANY
 *  USE, REPRODUCTION OR DISTRIBUTION OF THE PROGRAM CONSTITUTES
 *  RECIPIENT'S ACCEPTANCE OF THE AGREEMENT.
 *
 *  The license text can also be found at
 *    http://opensource.org/licenses/cpl.php
 */

package com.phoenixst.plexus;

import java.util.*;

import junit.framework.*;


/**
 *  A {@link DefaultGraph} tester.
 *
 *  @version    $Revision: 1.14 $
 *  @author     Ray A. Conner
 *
 *  @since      1.0
 */
public class DefaultGraphTest extends AbstractGraphTest
{

    protected Graph graph;


    public DefaultGraphTest( Graph graph )
    {
        super();
        this.graph = graph;
    }


    protected void setUp()
        throws Exception
    {
        super.setUp();
        Graph defaultGraph = new DefaultGraph();

        Set goodNodes = new HashSet();
        Set goodEdges = new HashSet();
        Set testEdges = new HashSet();
        Set badEdges = new HashSet();

        // Assumption is that the graph being copied works just fine.

        Iterator nodeIter = graph.nodes( null ).iterator();
        while( nodeIter.hasNext() ) {
            Object node = nodeIter.next();
            defaultGraph.addNode( node );
            goodNodes.add( node );
        }

        Iterator edgeIter = graph.edges( null ).iterator();
        while( edgeIter.hasNext() ) {
            Graph.Edge edge = (Graph.Edge) edgeIter.next();
            Object userObject = edge.getUserObject();
            Object tail = edge.getTail();
            Object head = edge.getHead();
            boolean isDirected = edge.isDirected();
            Graph.Edge testEdge = new SimpleObjectEdge( g, null, tail, head, isDirected );
            if( testEdges.add( testEdge ) ) {
                defaultGraph.addEdge( userObject, tail, head, isDirected );
                goodEdges.add( new SimpleObjectEdge( g, userObject, tail, head, isDirected ) );
            }
        }

        Iterator tailIter = graph.nodes( null ).iterator();
        while( tailIter.hasNext() ) {
            Object tail = tailIter.next();
            Iterator headIter = graph.nodes( null ).iterator();
            while( headIter.hasNext() ) {
                Object head = headIter.next();
                Graph.Edge edge = new SimpleObjectEdge( g, null, tail, head, true );
                if( !testEdges.contains( edge ) ) {
                    badEdges.add( edge );
                }
                edge = new SimpleObjectEdge( g, null, tail, head, false );
                if( !testEdges.contains( edge ) ) {
                    badEdges.add( edge );
                }
            }
        }

        setUp( defaultGraph );

        presentNodes = goodNodes.toArray();
        notPresentNodes = new Object[] { new Object() };

        presentEdges = createEdgeArray( goodEdges );
        notPresentEdges = createEdgeArray( badEdges );
    }


    public static Test suite( Graph graph )
    {
        return suite( graph, graph.toString() );
    }


    public static Test suite( Graph graph, String graphName )
    {
        String suiteName = "Default[" + graphName + "] Tests";
        TestSuite suite = new TestSuite( suiteName );
        suite.addTest( new DefaultGraphTest( graph ).getInstanceSuite( suiteName ) );
        return suite;
    }

}
