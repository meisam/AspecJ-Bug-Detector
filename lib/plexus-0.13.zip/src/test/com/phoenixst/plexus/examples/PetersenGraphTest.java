/*
 *  $Id: PetersenGraphTest.java,v 1.19 2005/10/03 15:27:29 rconner Exp $
 *
 *  Copyright (C) 1994-2005 by Phoenix Software Technologists,
 *  Inc. and others.  All rights reserved.
 *
 *  THIS PROGRAM AND DOCUMENTATION IS PROVIDED UNDER THE TERMS OF THE
 *  COMMON PUBLIC LICENSE ("AGREEMENT") WHICH ACCOMPANIES IT.  ANY
 *  USE, REPRODUCTION OR DISTRIBUTION OF THE PROGRAM CONSTITUTES
 *  RECIPIENT'S ACCEPTANCE OF THE AGREEMENT.
 *
 *  The license text can also be found at
 *    http://opensource.org/licenses/cpl.php
 */

package com.phoenixst.plexus.examples;

import junit.framework.*;

import org.apache.commons.collections.Predicate;

import com.phoenixst.plexus.*;


/**
 *  A {@link PetersenGraph} tester.
 *
 *  @version    $Revision: 1.19 $
 *  @author     Ray A. Conner
 *
 *  @since      1.0
 */
public class PetersenGraphTest extends AbstractGraphTest
{

    private static final Predicate TEST_PREDICATE = new Predicate()
        {
            // Assumes tail < head
            private boolean evaluate( int tail, int head )
            {
                int diff = head - tail;
                if( tail < 5 ) {
                    return ( head < 5 )
                        ? diff == 1 || diff == 4
                        :  diff == 5;
                }
                return diff == 2 || diff == 3;
            }

            public boolean evaluate( Object object )
            {
                Graph.Edge edge = (Graph.Edge) object;
                if( edge.isDirected() ) {
                    return false;
                }
                int tail = ((Integer) edge.getTail()).intValue();
                int head = ((Integer) edge.getHead()).intValue();
                if( tail < head ) {
                    return evaluate( tail, head );
                } else if( tail > head ) {
                    return evaluate( head, tail );
                } else {
                    return false;
                }
            }
        };


    public PetersenGraphTest()
    {
        super();
    }


    protected void setUp()
        throws Exception
    {
        super.setUp();
        setUp( PetersenGraph.INSTANCE );
        createPresentNodeRanges( 10 );
        createEdgeArrays( 10, TEST_PREDICATE );
    }


    public static Test suite()
    {
        return new TestSuite( PetersenGraphTest.class, "PetersenGraph Tests" );
    }


    public static void main( String[] args )
    {
        junit.textui.TestRunner.run( suite() );
    }

}
