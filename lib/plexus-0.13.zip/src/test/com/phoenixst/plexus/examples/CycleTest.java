/*
 *  $Id: CycleTest.java,v 1.18 2005/10/03 15:27:29 rconner Exp $
 *
 *  Copyright (C) 1994-2005 by Phoenix Software Technologists,
 *  Inc. and others.  All rights reserved.
 *
 *  THIS PROGRAM AND DOCUMENTATION IS PROVIDED UNDER THE TERMS OF THE
 *  COMMON PUBLIC LICENSE ("AGREEMENT") WHICH ACCOMPANIES IT.  ANY
 *  USE, REPRODUCTION OR DISTRIBUTION OF THE PROGRAM CONSTITUTES
 *  RECIPIENT'S ACCEPTANCE OF THE AGREEMENT.
 *
 *  The license text can also be found at
 *    http://opensource.org/licenses/cpl.php
 */

package com.phoenixst.plexus.examples;

import junit.framework.*;

import org.apache.commons.collections.Predicate;

import com.phoenixst.plexus.*;


/**
 *  A {@link Cycle} tester.
 *
 *  @version    $Revision: 1.18 $
 *  @author     Ray A. Conner
 *
 *  @since      1.0
 */
public class CycleTest extends AbstractGraphTest
{

    private static class TestPredicate
        implements Predicate
    {
        private final int n;

        TestPredicate( int n )
        {
            super();
            this.n = n;
        }

        public boolean evaluate( Object object )
        {
            Graph.Edge edge = (Graph.Edge) object;
            if( !edge.isDirected() ) {
                return false;
            }
            int tail = ((Integer) edge.getTail()).intValue();
            int head = ((Integer) edge.getHead()).intValue();
            return (tail + 1 == head)
                || (tail == n - 1 && head == 0);
        }
    }


    private int n;


    public CycleTest( int n )
    {
        super();
        this.n = n;
    }


    protected void setUp()
        throws Exception
    {
        super.setUp();
        setUp( new Cycle( n ) );
        createPresentNodeRanges( n );
        createEdgeArrays( n, new TestPredicate( n ) );
    }


    private static Test suite( int n )
    {
        return new CycleTest( n ).getInstanceSuite( "Cycle[" + n + "]" );
    }


    public static Test suite()
    {
        TestSuite suite = new TestSuite( "Cycle Tests" );
        suite.addTest( suite( 3 ) );
        suite.addTest( suite( 5 ) );
        return suite;
    }


    public static void main( String[] args )
    {
        junit.textui.TestRunner.run( suite() );
    }

}
