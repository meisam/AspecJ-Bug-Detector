/*
 *  $Id: PathTest.java,v 1.17 2005/10/03 15:27:29 rconner Exp $
 *
 *  Copyright (C) 1994-2005 by Phoenix Software Technologists,
 *  Inc. and others.  All rights reserved.
 *
 *  THIS PROGRAM AND DOCUMENTATION IS PROVIDED UNDER THE TERMS OF THE
 *  COMMON PUBLIC LICENSE ("AGREEMENT") WHICH ACCOMPANIES IT.  ANY
 *  USE, REPRODUCTION OR DISTRIBUTION OF THE PROGRAM CONSTITUTES
 *  RECIPIENT'S ACCEPTANCE OF THE AGREEMENT.
 *
 *  The license text can also be found at
 *    http://opensource.org/licenses/cpl.php
 */

package com.phoenixst.plexus.examples;

import junit.framework.*;

import org.apache.commons.collections.Predicate;

import com.phoenixst.plexus.*;


/**
 *  A {@link Path} tester.
 *
 *  @version    $Revision: 1.17 $
 *  @author     Ray A. Conner
 *
 *  @since      1.0
 */
public class PathTest extends AbstractGraphTest
{

    private static final Predicate TEST_PREDICATE = new Predicate()
        {
            public boolean evaluate( Object object )
            {
                Graph.Edge edge = (Graph.Edge) object;
                if( !edge.isDirected() ) {
                    return false;
                }
                int tail = ((Integer) edge.getTail()).intValue();
                int head = ((Integer) edge.getHead()).intValue();
                return tail + 1 == head;
            }
        };


    private final int n;


    public PathTest( int n )
    {
        super();
        this.n = n;
    }


    protected void setUp()
        throws Exception
    {
        super.setUp();
        setUp( new Path( n ) );
        createPresentNodeRanges( n );
        createEdgeArrays( n, TEST_PREDICATE );
    }


    private static Test suite( int n )
    {
        return new PathTest( n ).getInstanceSuite( "Path[" + n + "]" );
    }


    public static Test suite()
    {
        TestSuite suite = new TestSuite( "Path Tests" );
        suite.addTest( suite( 2 ) );
        suite.addTest( suite( 3 ) );
        suite.addTest( suite( 5 ) );
        return suite;
    }


    public static void main( String[] args )
    {
        junit.textui.TestRunner.run( suite() );
    }

}
