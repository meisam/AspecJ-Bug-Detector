/*
 *  $Id: CompleteTreeTest.java,v 1.19 2005/10/03 15:27:29 rconner Exp $
 *
 *  Copyright (C) 1994-2005 by Phoenix Software Technologists,
 *  Inc. and others.  All rights reserved.
 *
 *  THIS PROGRAM AND DOCUMENTATION IS PROVIDED UNDER THE TERMS OF THE
 *  COMMON PUBLIC LICENSE ("AGREEMENT") WHICH ACCOMPANIES IT.  ANY
 *  USE, REPRODUCTION OR DISTRIBUTION OF THE PROGRAM CONSTITUTES
 *  RECIPIENT'S ACCEPTANCE OF THE AGREEMENT.
 *
 *  The license text can also be found at
 *    http://opensource.org/licenses/cpl.php
 */

package com.phoenixst.plexus.examples;

import junit.framework.*;

import org.apache.commons.collections.Predicate;

import com.phoenixst.plexus.*;


/**
 *  A {@link CompleteTree} tester.
 *
 *  @version    $Revision: 1.19 $
 *  @author     Ray A. Conner
 *
 *  @since      1.0
 */
public class CompleteTreeTest extends AbstractGraphTest
{

    private static class TestPredicate
        implements Predicate
    {
        private final int numChildren;

        TestPredicate( int numChildren )
        {
            super();
            this.numChildren = numChildren;
        }

        public boolean evaluate( Object object )
        {
            Graph.Edge edge = (Graph.Edge) object;
            if( !edge.isDirected() ) {
                return false;
            }
            int tail = ((Integer) edge.getTail()).intValue();
            int head = ((Integer) edge.getHead()).intValue();
            return tail < head && tail == (head - 1) / numChildren;
        }
    }


    private int height;
    private int numChildren;


    public CompleteTreeTest( int height, int numChildren )
    {
        super();
        this.height = height;
        this.numChildren = numChildren;
    }


    protected void setUp()
        throws Exception
    {
        super.setUp();
        setUp( new CompleteTree( height, numChildren ) );

        int n;
        if( numChildren == 1 ) {
            n = height + 1;
        } else {
            n = 1;
            for( int i = 0; i < height; i++ ) {
                n *= numChildren;
            }
            n = (n * numChildren - 1) / (numChildren - 1);
        }

        createPresentNodeRanges( n );
        createEdgeArrays( n, new TestPredicate( numChildren ) );
    }


    private static Test suite( int height, int numChildren )
    {
        return new CompleteTreeTest( height, numChildren ).getInstanceSuite( "Tree[" + height + "," + numChildren + "]" );
    }


    public static Test suite()
    {
        TestSuite suite = new TestSuite( "CompleteTree Tests" );
        suite.addTest( suite( 0, 1 ) );
        suite.addTest( suite( 0, 10 ) );
        suite.addTest( suite( 1, 1 ) );
        suite.addTest( suite( 1, 5 ) );
        suite.addTest( suite( 5, 1 ) );
        suite.addTest( suite( 2, 3 ) );
        return suite;
    }


    public static void main( String[] args )
    {
        junit.textui.TestRunner.run( suite() );
    }

}
