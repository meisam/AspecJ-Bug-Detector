/*
 *  $Id: PlanarMeshTest.java,v 1.17 2005/10/03 15:27:29 rconner Exp $
 *
 *  Copyright (C) 1994-2005 by Phoenix Software Technologists,
 *  Inc. and others.  All rights reserved.
 *
 *  THIS PROGRAM AND DOCUMENTATION IS PROVIDED UNDER THE TERMS OF THE
 *  COMMON PUBLIC LICENSE ("AGREEMENT") WHICH ACCOMPANIES IT.  ANY
 *  USE, REPRODUCTION OR DISTRIBUTION OF THE PROGRAM CONSTITUTES
 *  RECIPIENT'S ACCEPTANCE OF THE AGREEMENT.
 *
 *  The license text can also be found at
 *    http://opensource.org/licenses/cpl.php
 */

package com.phoenixst.plexus.examples;

import java.util.List;

import junit.framework.*;

import org.apache.commons.collections.Predicate;

import com.phoenixst.plexus.*;


/**
 *  A {@link PlanarMesh} tester.
 *
 *  @version    $Revision: 1.17 $
 *  @author     Ray A. Conner
 *
 *  @since      1.0
 */
public class PlanarMeshTest extends AbstractGraphTest
{

    private static final Predicate TEST_PREDICATE = new Predicate()
        {
            public boolean evaluate( Object object )
            {
                Graph.Edge edge = (Graph.Edge) object;
                if( !edge.isDirected() ) {
                    return false;
                }
                List tail = (List) edge.getTail();
                List head = (List) edge.getHead();
                int tailA = ((Integer) tail.get( 0 )).intValue();
                int tailB = ((Integer) tail.get( 1 )).intValue();
                int headA = ((Integer) head.get( 0 )).intValue();
                int headB = ((Integer) head.get( 1 )).intValue();
                return ( (tailA == headA) && (tailB + 1 == headB) )
                    || ( (tailB == headB) && (tailA + 1 == headA) );
            }
        };


    private final int m;
    private final int n;


    public PlanarMeshTest( int m, int n )
    {
        super();
        this.m = m;
        this.n = n;
    }


    protected void setUp()
        throws Exception
    {
        super.setUp();
        setUp( new PlanarMesh( m, n ) );
        createPresentNodeRanges( m, n );
        createEdgeArrays( m, n, TEST_PREDICATE );
    }


    private static Test suite( int m, int n )
    {
        return new PlanarMeshTest( m, n ).getInstanceSuite( "Plane[" + m + "," + n + "]" );
    }


    public static Test suite()
    {
        TestSuite suite = new TestSuite( "PlanarMesh Tests" );
        suite.addTest( suite( 2, 2 ) );
        suite.addTest( suite( 2, 5 ) );
        suite.addTest( suite( 5, 2 ) );
        suite.addTest( suite( 5, 5 ) );
        return suite;
    }


    public static void main( String[] args )
    {
        junit.textui.TestRunner.run( suite() );
    }

}
