/*
 *  $Id: EmptyGraphTest.java,v 1.16 2005/10/03 15:27:29 rconner Exp $
 *
 *  Copyright (C) 1994-2005 by Phoenix Software Technologists,
 *  Inc. and others.  All rights reserved.
 *
 *  THIS PROGRAM AND DOCUMENTATION IS PROVIDED UNDER THE TERMS OF THE
 *  COMMON PUBLIC LICENSE ("AGREEMENT") WHICH ACCOMPANIES IT.  ANY
 *  USE, REPRODUCTION OR DISTRIBUTION OF THE PROGRAM CONSTITUTES
 *  RECIPIENT'S ACCEPTANCE OF THE AGREEMENT.
 *
 *  The license text can also be found at
 *    http://opensource.org/licenses/cpl.php
 */

package com.phoenixst.plexus.examples;

import junit.framework.*;

import org.apache.commons.collections.Predicate;

import com.phoenixst.plexus.AbstractGraphTest;


/**
 *  An {@link EmptyGraph} tester.
 *
 *  @version    $Revision: 1.16 $
 *  @author     Ray A. Conner
 *
 *  @since      1.0
 */
public class EmptyGraphTest extends AbstractGraphTest
{

    private static final Predicate TEST_PREDICATE = new Predicate()
        {
            public boolean evaluate( Object object )
            {
                return false;
            }
        };


    private final int n;


    public EmptyGraphTest( int n )
    {
        super();
        this.n = n;
    }


    protected void setUp()
        throws Exception
    {
        super.setUp();
        setUp( new EmptyGraph( n ) );
        createPresentNodeRanges( n );
        createEdgeArrays( n, TEST_PREDICATE );
    }


    private static Test suite( int n )
    {
        return new EmptyGraphTest( n ).getInstanceSuite( "Empty[" + n + "]" );
    }


    public static Test suite()
    {
        TestSuite suite = new TestSuite( "EmptyGraph Tests" );
        suite.addTest( suite( 0 ) );
        suite.addTest( suite( 1 ) );
        suite.addTest( suite( 5 ) );
        return suite;
    }


    public static void main( String[] args )
    {
        junit.textui.TestRunner.run( suite() );
    }

}
