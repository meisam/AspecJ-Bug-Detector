/*
 *  $Id: AllTests.java,v 1.9 2005/10/03 15:27:29 rconner Exp $
 *
 *  Copyright (C) 1994-2005 by Phoenix Software Technologists,
 *  Inc. and others.  All rights reserved.
 *
 *  THIS PROGRAM AND DOCUMENTATION IS PROVIDED UNDER THE TERMS OF THE
 *  COMMON PUBLIC LICENSE ("AGREEMENT") WHICH ACCOMPANIES IT.  ANY
 *  USE, REPRODUCTION OR DISTRIBUTION OF THE PROGRAM CONSTITUTES
 *  RECIPIENT'S ACCEPTANCE OF THE AGREEMENT.
 *
 *  The license text can also be found at
 *    http://opensource.org/licenses/cpl.php
 */

package com.phoenixst.plexus.examples;

import junit.framework.*;


/**
 *  Test suite for all tests in this package.
 *
 *  @version    $Revision: 1.9 $
 *  @author     Ray A. Conner
 *
 *  @since      1.0
 */
public class AllTests
{

    private AllTests()
    {
        super();
    }

    public static Test suite()
    {
        TestSuite suite = new TestSuite( "Graph Example Tests" );

        suite.addTest( EmptyGraphTest.suite() );
        suite.addTest( CompleteGraphTest.suite() );
        suite.addTest( PathTest.suite() );
        suite.addTest( CycleTest.suite() );
        suite.addTest( CompleteTreeTest.suite() );

        suite.addTest( CompleteBipartiteGraphTest.suite() );
        suite.addTest( StarTest.suite() );
        suite.addTest( WheelTest.suite() );

        suite.addTest( PlanarMeshTest.suite() );
        suite.addTest( PrismTest.suite() );
        suite.addTest( ToroidalMeshTest.suite() );

        suite.addTest( PetersenGraphTest.suite() );

        suite.addTest( DefaultGraphExamplesTest.suite() );

        return suite;
    }

    public static void main( String[] args )
    {
        junit.textui.TestRunner.run( suite() );
    }

}
