/*
 *  $Id: CompleteBipartiteGraphTest.java,v 1.19 2005/10/03 15:27:29 rconner Exp $
 *
 *  Copyright (C) 1994-2005 by Phoenix Software Technologists,
 *  Inc. and others.  All rights reserved.
 *
 *  THIS PROGRAM AND DOCUMENTATION IS PROVIDED UNDER THE TERMS OF THE
 *  COMMON PUBLIC LICENSE ("AGREEMENT") WHICH ACCOMPANIES IT.  ANY
 *  USE, REPRODUCTION OR DISTRIBUTION OF THE PROGRAM CONSTITUTES
 *  RECIPIENT'S ACCEPTANCE OF THE AGREEMENT.
 *
 *  The license text can also be found at
 *    http://opensource.org/licenses/cpl.php
 */

package com.phoenixst.plexus.examples;

import junit.framework.*;

import org.apache.commons.collections.Predicate;

import com.phoenixst.plexus.*;


/**
 *  A {@link CompleteBipartiteGraph} tester.
 *
 *  @version    $Revision: 1.19 $
 *  @author     Ray A. Conner
 *
 *  @since      1.0
 */
public class CompleteBipartiteGraphTest extends AbstractGraphTest
{

    private static class TestPredicate
        implements Predicate
    {
        private final int m;

        TestPredicate( int m )
        {
            super();
            this.m = m;
        }

        public boolean evaluate( Object object )
        {
            Graph.Edge edge = (Graph.Edge) object;
            if( !edge.isDirected() ) {
                return false;
            }
            int tail = ((Integer) edge.getTail()).intValue();
            int head = ((Integer) edge.getHead()).intValue();
            return (tail < m && m <= head);
        }
    }


    private int m;
    private int n;


    public CompleteBipartiteGraphTest( int m, int n )
    {
        super();
        this.m = m;
        this.n = n;
    }


    protected void setUp()
        throws Exception
    {
        super.setUp();
        setUp( new CompleteBipartiteGraph( m, n ) );
        createPresentNodeRanges( m + n );
        createEdgeArrays( m + n, new TestPredicate( m ) );
    }


    private static Test suite( int m, int n )
    {
        return new CompleteBipartiteGraphTest( m, n ).getInstanceSuite( "Bipartite[" + m + "," + n + "]" );
    }


    public static Test suite()
    {
        TestSuite suite = new TestSuite( "CompleteBipartiteGraph Tests" );
        suite.addTest( suite( 0, 0 ) );
        suite.addTest( suite( 0, 1 ) );
        suite.addTest( suite( 1, 0 ) );
        suite.addTest( suite( 0, 5 ) );
        suite.addTest( suite( 5, 0 ) );
        suite.addTest( suite( 1, 5 ) );
        suite.addTest( suite( 5, 1 ) );
        suite.addTest( suite( 2, 3 ) );
        return suite;
    }


    public static void main( String[] args )
    {
        junit.textui.TestRunner.run( suite() );
    }

}
