/*
 *  $Id: DefaultGraphExamplesTest.java,v 1.8 2005/10/03 15:27:29 rconner Exp $
 *
 *  Copyright (C) 1994-2005 by Phoenix Software Technologists,
 *  Inc. and others.  All rights reserved.
 *
 *  THIS PROGRAM AND DOCUMENTATION IS PROVIDED UNDER THE TERMS OF THE
 *  COMMON PUBLIC LICENSE ("AGREEMENT") WHICH ACCOMPANIES IT.  ANY
 *  USE, REPRODUCTION OR DISTRIBUTION OF THE PROGRAM CONSTITUTES
 *  RECIPIENT'S ACCEPTANCE OF THE AGREEMENT.
 *
 *  The license text can also be found at
 *    http://opensource.org/licenses/cpl.php
 */

package com.phoenixst.plexus.examples;

import junit.framework.*;

import com.phoenixst.plexus.DefaultGraphTest;


/**
 *  A {@link com.phoenixst.plexus.DefaultGraph} tester for copies
 *  of examples graphs, at least the immutable operations.
 *
 *  @version    $Revision: 1.8 $
 *  @author     Ray A. Conner
 *
 *  @since      1.0
 */
public class DefaultGraphExamplesTest
{

    private DefaultGraphExamplesTest()
    {
        super();
    }

    public static Test emptySuite()
    {
        TestSuite suite = new TestSuite( "Default-Empty Tests" );
        suite.addTest( DefaultGraphTest.suite( new EmptyGraph( 0 ), "Empty[0]" ) );
        suite.addTest( DefaultGraphTest.suite( new EmptyGraph( 1 ), "Empty[1]" ) );
        suite.addTest( DefaultGraphTest.suite( new EmptyGraph( 5 ), "Empty[5]" ) );
        return suite;
    }


    public static Test completeSuite()
    {
        TestSuite suite = new TestSuite( "Default-CompleteGraph Tests" );
        suite.addTest( DefaultGraphTest.suite( new CompleteGraph( 1 ), "Complete[1]" ) );
        suite.addTest( DefaultGraphTest.suite( new CompleteGraph( 2 ), "Complete[2]" ) );
        suite.addTest( DefaultGraphTest.suite( new CompleteGraph( 3 ), "Complete[3]" ) );
        suite.addTest( DefaultGraphTest.suite( new CompleteGraph( 5 ), "Complete[5]" ) );
        return suite;
    }


    public static Test treeSuite()
    {
        TestSuite suite = new TestSuite( "Default-Tree Tests" );
        suite.addTest( DefaultGraphTest.suite( new CompleteTree( 0, 1 ), "Tree[0,1]" ) );
        suite.addTest( DefaultGraphTest.suite( new CompleteTree( 0, 10 ), "Tree[0,10]" ) );
        suite.addTest( DefaultGraphTest.suite( new CompleteTree( 1, 1 ), "Tree[1,1]" ) );
        suite.addTest( DefaultGraphTest.suite( new CompleteTree( 1, 5 ), "Tree[1,5]" ) );
        suite.addTest( DefaultGraphTest.suite( new CompleteTree( 5, 1 ), "Tree[5,1]" ) );
        suite.addTest( DefaultGraphTest.suite( new CompleteTree( 2, 3 ), "Tree[2,3]" ) );
        return suite;
    }


    public static Test wheelSuite()
    {
        TestSuite suite = new TestSuite( "Default-Wheel Tests" );
        suite.addTest( DefaultGraphTest.suite( new Wheel( 3 ), "Wheel[3]" ) );
        suite.addTest( DefaultGraphTest.suite( new Wheel( 5 ), "Wheel[5]" ) );
        return suite;
    }


    public static Test prismSuite()
    {
        TestSuite suite = new TestSuite( "Default-Prism Tests" );
        suite.addTest( DefaultGraphTest.suite( new Prism( 3, 2 ), "Prism[3,2]" ) );
        suite.addTest( DefaultGraphTest.suite( new Prism( 3, 5 ), "Prism[3,5]" ) );
        suite.addTest( DefaultGraphTest.suite( new Prism( 5, 2 ), "Prism[5,2]" ) );
        suite.addTest( DefaultGraphTest.suite( new Prism( 5, 5 ), "Prism[5,5]" ) );
        return suite;
    }


    public static Test suite()
    {
        TestSuite suite = new TestSuite( "DefaultGraph Example Tests" );
        suite.addTest( emptySuite() );
        suite.addTest( completeSuite() );
        suite.addTest( treeSuite() );
        suite.addTest( wheelSuite() );
        suite.addTest( prismSuite() );
        return suite;
    }


    public static void main( String[] args )
    {
        junit.textui.TestRunner.run( suite() );
    }

}
