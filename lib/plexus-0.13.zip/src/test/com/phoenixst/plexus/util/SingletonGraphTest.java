/*
 *  $Id: SingletonGraphTest.java,v 1.7 2005/10/03 15:30:14 rconner Exp $
 *
 *  Copyright (C) 1994-2005 by Phoenix Software Technologists,
 *  Inc. and others.  All rights reserved.
 *
 *  THIS PROGRAM AND DOCUMENTATION IS PROVIDED UNDER THE TERMS OF THE
 *  COMMON PUBLIC LICENSE ("AGREEMENT") WHICH ACCOMPANIES IT.  ANY
 *  USE, REPRODUCTION OR DISTRIBUTION OF THE PROGRAM CONSTITUTES
 *  RECIPIENT'S ACCEPTANCE OF THE AGREEMENT.
 *
 *  The license text can also be found at
 *    http://opensource.org/licenses/cpl.php
 */

package com.phoenixst.plexus.util;

import junit.framework.*;

import com.phoenixst.plexus.*;


/**
 *  A {@link SingletonGraph} tester.
 *
 *  @version    $Revision: 1.7 $
 *  @author     Ray A. Conner
 *
 *  @since      1.0
 */
public class SingletonGraphTest extends AbstractGraphTest
{

    private final Object node;


    public SingletonGraphTest( Object node )
    {
        super();
        this.node = node;
    }


    protected void setUp()
        throws Exception
    {
        super.setUp();
        setUp( new SingletonGraph( node ) );
        presentNodes = new Object[] { node };
        if( node == null ) {
            notPresentNodes = new Object[] { new Object() };
        } else {
            notPresentNodes = new Object[] { null, new Object() };
        }
        notPresentEdges = new Graph.Edge[] { new SimpleObjectEdge( g, null, node, node, false ),
                                             new SimpleObjectEdge( g, null, node, node, true ) };
    }


    private static Test suite( Object node )
    {
        return new SingletonGraphTest( node ).getInstanceSuite( "Singleton[" + node + "]" );
    }


    public static Test suite()
    {
        TestSuite suite = new TestSuite( "SingletonGraph Tests" );
        suite.addTest( suite( null ) );
        suite.addTest( suite( new Integer( 5 ) ) );
        return suite;
    }


    public static void main( String[] args )
    {
        junit.textui.TestRunner.run( suite() );
    }

}
