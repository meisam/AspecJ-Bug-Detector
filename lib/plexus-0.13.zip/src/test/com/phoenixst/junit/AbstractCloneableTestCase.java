/*
 *  $Id: AbstractCloneableTestCase.java,v 1.2 2005/10/03 15:25:38 rconner Exp $
 *
 *  Copyright (C) 1994-2005 by Phoenix Software Technologists,
 *  Inc. and others.  All rights reserved.
 *
 *  THIS PROGRAM AND DOCUMENTATION IS PROVIDED UNDER THE TERMS OF THE
 *  COMMON PUBLIC LICENSE ("AGREEMENT") WHICH ACCOMPANIES IT.  ANY
 *  USE, REPRODUCTION OR DISTRIBUTION OF THE PROGRAM CONSTITUTES
 *  RECIPIENT'S ACCEPTANCE OF THE AGREEMENT.
 *
 *  The license text can also be found at
 *    http://opensource.org/licenses/cpl.php
 */

package com.phoenixst.junit;

import java.lang.reflect.*;

import junit.framework.*;


/**
 *  A <code>TestCase</code> for which instances are
 *  <code>Cloneable</code>.  This class has been copied from the test
 *  code in the Melange project (http://melange.sourceforge.net).
 *
 *  @version    $Revision: 1.2 $
 *  @author     Ray A. Conner
 *
 *  @since      1.0
 */
public abstract class AbstractCloneableTestCase extends TestCase
    implements Cloneable
{

    /**
     *  Used by toString(), so that output for different suite
     *  instances can be distinct.  Class is not sufficiently
     *  unambiguous.
     */
    private String suiteName;


    ////////////////////////////////////////
    // Constructors
    ////////////////////////////////////////


    /**
     *  Create a new <code>CloneableTestCase</code>.
     */
    public AbstractCloneableTestCase()
    {
        super();
    }


    /**
     *  Create a new <code>CloneableTestCase</code> with the specified
     *  method name.
     */
    public AbstractCloneableTestCase( String name )
    {
        super( name );
    }


    ////////////////////////////////////////
    // Clone operation
    ////////////////////////////////////////


    public Object clone()
        throws CloneNotSupportedException
    {
        return super.clone();
    }


    ////////////////////////////////////////
    // Test suite creation
    ////////////////////////////////////////


    /**
     *  Returns whether or not the specified method is a test method.
     */
    private static final boolean isTestMethod( Method method )
    {
        return Modifier.isPublic( method.getModifiers() )
            && method.getName().startsWith( "test" )
            && method.getParameterTypes().length == 0
            && method.getReturnType().equals( Void.TYPE );
    }


    /**
     *  Create a new <code>TestSuite</code> by cloning a new instance
     *  of this object for each test method.
     */
    public TestSuite getInstanceSuite()
    {
        return getInstanceSuite( null );
    }


    /**
     *  Create a new <code>TestSuite</code> with the specified name by
     *  cloning a new instance of this object for each test method.
     */
    public TestSuite getInstanceSuite( String name )
    {
        TestSuite suite = new TestSuite( name );
        String cloneSuiteName = suite.toString();
        Method[] methods = getClass().getMethods();
        for( int i = 0; i < methods.length; i++ ) {
            if( isTestMethod( methods[i] ) ) {
                try {
                    AbstractCloneableTestCase test = (AbstractCloneableTestCase) clone();
                    test.setName( methods[i].getName() );
                    test.suiteName = cloneSuiteName;
                    suite.addTest( test );
                } catch( CloneNotSupportedException e ) {
                    // just return an empty suite
                }
            }
        }
        return suite;
    }


    ////////////////////////////////////////
    // toString()
    ////////////////////////////////////////


    public String toString()
    {
        if( suiteName == null ) {
            return super.toString();
        }
        return suiteName + ":" + super.toString();
    }

}
