package polyglot.ext.coffer.types;

import polyglot.types.*;
import polyglot.visit.*;
import polyglot.util.*;

/** Key used in an instantiation. */
public interface InstKey extends Key
{
}
