package polyglot.ext.coffer.types;

import polyglot.ext.param.types.*;
import java.util.List;

public interface CofferSubstType extends CofferClassType, SubstType {
}
