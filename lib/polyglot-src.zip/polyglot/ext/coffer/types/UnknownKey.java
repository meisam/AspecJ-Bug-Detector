package polyglot.ext.coffer.types;

import polyglot.types.*;
import polyglot.visit.*;
import polyglot.util.*;

public interface UnknownKey extends Key
{
}
