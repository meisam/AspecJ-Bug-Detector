package polyglot.ext.coffer.types;

import polyglot.types.*;
import polyglot.visit.*;
import polyglot.util.*;

public interface Key extends TypeObject
{
    String name();
}
