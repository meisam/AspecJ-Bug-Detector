package polyglot.ext.coffer.types;

import polyglot.types.*;
import polyglot.ext.param.types.*;

public interface CofferClassType extends ClassType, InstType {
    Key key();
}
