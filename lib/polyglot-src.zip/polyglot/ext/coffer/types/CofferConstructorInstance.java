package polyglot.ext.coffer.types;

import polyglot.types.*;
import java.util.*;

/** Coffer constructor instance. 
 */
public interface CofferConstructorInstance extends ConstructorInstance, CofferProcedureInstance
{
}
