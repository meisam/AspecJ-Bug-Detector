class Except4 extends Exception {
  void m() throws Except4 { }
}
