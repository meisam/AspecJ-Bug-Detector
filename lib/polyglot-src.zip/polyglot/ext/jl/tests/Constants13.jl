class Constants13 {
  public static final int   MIN_VALUE = 0x80000000;
}

