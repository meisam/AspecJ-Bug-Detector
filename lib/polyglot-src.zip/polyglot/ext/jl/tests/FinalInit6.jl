public class FinalInit6 {
    final int i;
    FinalInit6() {
	this.i = 4;
    }
}
