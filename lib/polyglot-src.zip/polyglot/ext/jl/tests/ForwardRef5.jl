class ForwardRef5 {
    ForwardRef5() { k = 2; }
    int j = 1;
    int i = j;
    int k;
}
