
class Constants4 {
    void foo(int i) {
        switch (i) {
            case 0:
            case ((~0xffffffffffffffffL == -0xffffffffffffffffL-1) ? 1 : 0):
        }
    }
}
