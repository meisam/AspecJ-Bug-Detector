public class NoInit8 {
  int m3() {
    int x;
    return x; // BAD
  }
}

