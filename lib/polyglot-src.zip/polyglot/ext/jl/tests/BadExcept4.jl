class BadExcept4 {
  void m() throws BadExcept4 { }
}
