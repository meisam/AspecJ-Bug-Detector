final class C0
{
  private class C1
  {
    class C2
    {
      public class C3
      {
      }
    }
  }
  interface I0
  {
    public static class C4
    {
    }
    private abstract C1 m0 ();
  }
}
