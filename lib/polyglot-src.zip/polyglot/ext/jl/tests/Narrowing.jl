class Narrowing {
        byte b1 = '1';
        byte b2 = 1;
        byte b3 = (short) 1;
        char c = 1;
        short s = 1;
}
