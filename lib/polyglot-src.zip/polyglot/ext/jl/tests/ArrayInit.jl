class ArrayInit {
  char[] x = new char[] { 0 };
  char[] y = { 0 };
}
