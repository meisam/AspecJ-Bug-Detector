class Dep1 {
  void m() {
    Dep2 d2 = new Dep2(1);
    Dep3 d3 = new Dep3(0);
  }
}
