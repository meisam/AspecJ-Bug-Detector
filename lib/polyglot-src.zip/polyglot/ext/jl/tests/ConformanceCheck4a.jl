class E extends ConformanceCheck4.D {
    // public void m() { }
}
