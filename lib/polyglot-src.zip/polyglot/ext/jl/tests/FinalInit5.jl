public class FinalInit5 {
    // field decl after the constructor
    FinalInit5() {
	i = 2;
    }

   final int i;

}
