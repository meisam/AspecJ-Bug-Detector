public class Inner11 {
    public void bar() {
        class BBB {
            BBB x;
        }
    }
}


