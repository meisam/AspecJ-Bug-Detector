public class FinalInit2 {
    final int i = 4;
    FinalInit2() { 
    }
}
