
class Constants2 {
    void foo(int i) {
        switch (i) {
            case 0:
            case (((float)(double)0x8000ff7ffffL == (float)0x8000ff00000L) ? 1 : 0):
        }
    }
}
