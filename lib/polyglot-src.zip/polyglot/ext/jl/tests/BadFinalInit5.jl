public class BadFinalInit5 {
    final int i;
    BadFinalInit5() {
	// bad: no initialization of i
    }
}
