class CircularInheritance1 implements CircularInheritance1.Foo {
  interface Foo {
    int A = 42;
  }  
}


