public class Test {
	String s;
	public static void main(String[] args) {
		System.out.println("Test");
	}
	void foo(String s) {
		String s = "Hi, Mom";
		while (true) {
			String s = "Hi, Dad";
		}
	}
}
