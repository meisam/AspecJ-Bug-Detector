class Dep3 extends Dep2 {
  Dep3(int x) {
    super(x);
  }
}
