class Local {
  public int m(int x) {
    return x;
  }
}
