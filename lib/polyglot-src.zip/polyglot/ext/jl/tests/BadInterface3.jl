interface I0 {
  I0 m0();
}
class C0 implements I0
{
  public I0 m0() {
    new I0().m0();
      return null;
  }
}
