class Errors2 {
  void m(foo x) {
      bar y;
  }
}
