public class NoReturn7 {
  int m7() {
    try {
      return 7;
    } catch (Exception e) {}
  } // BAD
}
