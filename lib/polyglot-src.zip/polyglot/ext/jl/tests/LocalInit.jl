class LocalInit {
  void m() {
    int i = (i = 1) + i;
  }
}
