final class C0
{
  public static C0.C0 m0 ()
  {
    C0.this.m0 ();
    return this;
  }
}
interface I0
{
}
