// From jacks
class InitializerType1 {
  void m() {
        short s = 1;
        int[] ia = new int[] { s, '1' };
  }
}
