// Test that we can import from java.util and java.lang.
// This is really to exercise the test that the package java exists.
import java.util.List;
import java.lang.String;
class Import { }
