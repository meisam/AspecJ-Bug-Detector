class C0
{
  public abstract C0 m0 ();
}
