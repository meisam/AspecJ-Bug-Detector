// Interfaces can override clone, which is protected in Object, to be public.
interface InterfaceOverride {
    Object clone();
}
