class Equality {
  int a, b, c, d;
  public boolean m() {
    return (a == b) != (c == d);
  }
}
