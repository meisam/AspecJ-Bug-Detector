public class Init3 {
  int m3() {
    int x;
    for (x = 0; x < 10; x++) {
      x++;
    }
    return x; // OK
  }
}
