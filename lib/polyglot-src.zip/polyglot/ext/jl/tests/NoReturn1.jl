public class NoReturn1 {
  int m1() {
  } // BAD
}
