class Dep2 {
  Dep2(int x) {
  }
}
