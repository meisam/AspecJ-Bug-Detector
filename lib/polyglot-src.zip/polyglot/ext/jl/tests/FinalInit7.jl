class FinalInit7 {
    static final int val;
    static final String str;
    static {
        val = 0;
        str = null;
    }
}
