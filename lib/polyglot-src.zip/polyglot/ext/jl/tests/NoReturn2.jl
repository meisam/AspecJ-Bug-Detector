public class NoReturn6 {
  int m6() {
    int i = 5;
    switch (i) {
    case 3:
      return 4;
    case 4:
      return 6;
    }    
  } // BAD
}
