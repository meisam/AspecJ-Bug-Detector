class C {
    void foo() {
	final int i;
	class D {
	    void bar() {
		int i;
	    a: do { break a; } while (i < 10);
	    }
	}
    }
}
