public class BoolTest {
  public static void main(String[] args) {
    if (false || false) {
      System.out.println(false);
    }
  }
}
