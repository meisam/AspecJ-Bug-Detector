public abstract class Inner9 {
    abstract class goo { }
}

class Foo_c extends Inner9 {
    class goo_c extends goo { }
}
