/*
 * This class defines a number of useful constants...
 */
public class Constants
{
  String \u0062 = "Tab \t newline \n unicode \u0370 octal \100\76 \r";
  char c = '\t';
  char d = '\101';
  char e = '\u0363';

}
