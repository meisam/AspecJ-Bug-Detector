class Constants6 {
    public static void main(String[] args) {
        final byte b = Byte.MIN_VALUE;
        final short s = b;
        switch (args.length) {
            case 0:
            case (((short)b == s) ? 1 : 0):
        }
    }
}
