class BadInner7 { 
  class C {
    class BadInner7 { }
  }
}
