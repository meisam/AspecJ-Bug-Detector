package packA;
// used with packB.ConformanceCheck8B
public abstract class ConformanceCheck8 {
    abstract void defineMethod();
}
