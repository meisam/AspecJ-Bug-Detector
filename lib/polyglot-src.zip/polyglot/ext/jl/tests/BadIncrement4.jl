class BadIncrement1 {
  int m() {
    ++m();

    return 0;
  }
}
