class ConformanceCheck4 {
  private static interface I { void m(); }
  public static abstract class D implements I { }
}
