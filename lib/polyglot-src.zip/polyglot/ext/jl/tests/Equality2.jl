class Equality2 {
  boolean b = null == null;
}
