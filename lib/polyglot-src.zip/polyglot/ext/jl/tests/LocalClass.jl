public class LocalClass {
    public static void main(String[] argv) {
          class Local { int x; }
    }
}

