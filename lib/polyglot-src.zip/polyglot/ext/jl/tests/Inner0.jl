public class Inner0 {
    class B { }
    void foo() { B b = new B(); }
}
