class ForInit {
        void m() {
          for (int i = 0, j = i; ; ) ;
        }
}
