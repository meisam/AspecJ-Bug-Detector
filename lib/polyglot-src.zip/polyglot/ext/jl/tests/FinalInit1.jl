public class FinalInit1 {
    void foo() {
	final int i;
	// no initialization, but also no use. OK.
    }
}
