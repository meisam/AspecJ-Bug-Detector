public class NoReturn3 {
  int m3() {
    while (true) {
      if (1==1) {
	break;
      }
    }
  } // BAD
}
