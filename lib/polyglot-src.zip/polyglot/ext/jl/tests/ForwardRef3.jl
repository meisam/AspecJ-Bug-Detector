class ForwardRef3 {
  static final int y = 3; 
  static final int x = y;
}
