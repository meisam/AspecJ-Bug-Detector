class Empty {}
