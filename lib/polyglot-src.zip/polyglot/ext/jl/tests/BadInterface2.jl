class C0 implements NotDefined
{
  protected NotDefined m0 ()
  {
    new NotDefined ().m0 ();
      return null;
  }
}
