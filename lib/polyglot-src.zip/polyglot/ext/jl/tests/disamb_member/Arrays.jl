class Arrays { 
  static class ArrayAsList extends AbstractList { }
}

