class AbstractList
{
  int modCount;
}        


    
