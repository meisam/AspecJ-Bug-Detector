class ArrayList extends AbstractList
{
  int size;

  void foo() {
    modCount++;
  }

}

