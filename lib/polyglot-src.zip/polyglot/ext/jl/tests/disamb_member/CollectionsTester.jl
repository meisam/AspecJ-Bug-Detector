class CollectionsTester {
  void test() { 
    new Arrays();
    new ArrayList();
  }   
}
