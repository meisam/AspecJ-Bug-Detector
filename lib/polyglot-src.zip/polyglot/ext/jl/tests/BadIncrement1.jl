class BadIncrement1 {
  int m() {
    1++;

    return 0;
  }
}
