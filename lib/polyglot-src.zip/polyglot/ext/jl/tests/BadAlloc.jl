class C0
{
  public interface I0
  {
    public static final I0 f0 = new I0 ();
  }
}
