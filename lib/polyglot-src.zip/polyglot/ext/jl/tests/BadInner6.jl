final class C0
{
}
class C1
{
}
class C2
{
  final I0 m0 ()
  {
    this.m0 ();
    return I0.this;
  }
  public interface I0
  {
  }
}
