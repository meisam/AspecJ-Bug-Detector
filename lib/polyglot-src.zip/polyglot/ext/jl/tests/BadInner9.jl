class Outer {
      // inner classes cannot have static members
      class Inner { static class Inner2 { } }
}
