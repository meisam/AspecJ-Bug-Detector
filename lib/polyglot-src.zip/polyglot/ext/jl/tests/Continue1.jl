public class Continue1 {
  public static void main(String args[])
    { int x;
      L1: { x = 1;
            continue;
          }
    }
}



