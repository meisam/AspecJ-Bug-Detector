class BadForwardRef2 {
    static int i = j + 2; 
    static int j = 4;
}
