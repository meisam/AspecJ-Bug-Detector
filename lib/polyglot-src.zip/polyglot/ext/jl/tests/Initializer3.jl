public class Initializer3 {
    { 
	int x; // OK, initializer finishes normally
    }  
}
