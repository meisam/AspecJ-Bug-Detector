package package1;

public class ProtectedCtor {
    protected ProtectedCtor() { }
}
