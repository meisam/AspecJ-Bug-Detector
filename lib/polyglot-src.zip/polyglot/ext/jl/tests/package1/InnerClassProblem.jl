package package1;

public class InnerClassProblem {
    
    public static void main (String [] args) {
        
    }

    public class Problem{
        int x = 9;
    }
}
