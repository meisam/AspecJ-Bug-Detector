class Field {
  int x;
  public int m() {
    return x;
  }
}
