final class C0
{
  public class C1 extends C0
  {
  }
}
