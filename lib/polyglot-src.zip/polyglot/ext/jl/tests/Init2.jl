public class Init2 {
  void m2() {
    int x;
    if ((x = 1) > 0) {
    }
    x++; // OK
  }
}

