class DoubleFlags {
  private private void foo() { }
  static static void bar() { }
  public public void baz() { }
}
