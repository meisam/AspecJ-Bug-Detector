interface I0
{
  public static class C0
  {
  }
  protected abstract I0 m0 ();
}
