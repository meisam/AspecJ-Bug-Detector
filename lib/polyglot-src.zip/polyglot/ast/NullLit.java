package polyglot.ast;

/**
 * The Java literal <code>null</code>.
 */
public interface NullLit extends Lit 
{
}
