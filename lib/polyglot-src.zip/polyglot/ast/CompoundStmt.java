package polyglot.ast;

import java.util.*;

/**
 * Any statement with sub-statements.
 */
public interface CompoundStmt extends Stmt 
{    
}
