package polyglot.ast;

/**
 * <code>Empty</code> is the class for a empty statement (i.e., <code>;</code>).
 */
public interface Empty extends Stmt
{
}
