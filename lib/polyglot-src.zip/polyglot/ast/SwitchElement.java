package polyglot.ast;

/**
 * A <code>SwitchElement</code> is statement inside a switch.
 */
public interface SwitchElement extends Stmt
{
}
